"""Routage racine du projet GCVM."""

from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("", include("apps.accounts.urls")),
    path("administration/", include("apps.administration.urls")),
    path("etudiant/", include("apps.etudiant.urls")),
    path("themes/", include("apps.themes.urls")),
    path("encadrement/", include("apps.supervision.urls")),
    path("memoire/", include("apps.memories.urls")),
    path("notifications/", include("apps.notifications.urls")),
    path("encadreur/", include("apps.encadreur.urls")),
    path("etudes/", include("apps.etudes.urls")),
    path("academique/", include("apps.academique.urls")),
    path("jury/", include("apps.jury.urls")),
    path("soutenances/", include("apps.defenses.urls")),
    path("bibliotheque/", include("apps.archives.urls")),
    path("django-admin/", admin.site.urls),
]

# Les fichiers déposés ne sont volontairement PAS servis par
# django.conf.urls.static : un mémoire ou un guide interne ne doit pas être
# accessible par une URL devinée. Chaque téléchargement passe par une vue qui
# vérifie d'abord qui le demande (apps/memories/views.py, apps/etudiant/views.py).
