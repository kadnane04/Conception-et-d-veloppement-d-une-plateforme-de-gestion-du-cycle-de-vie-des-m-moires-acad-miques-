"""
Configuration du projet GCVM — module Administrateur.

Base de données : SQLite en développement. Le basculement vers PostgreSQL se
fait par le seul fichier .env, sans toucher au code : l'ORM de Django écrit le
même code pour les deux moteurs.
"""

from pathlib import Path
import os

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent

load_dotenv(BASE_DIR / ".env")


def env(cle, defaut=""):
    return os.environ.get(cle, defaut)


def env_bool(cle, defaut=False):
    valeur = env(cle, str(defaut)).strip().lower()
    return valeur in {"1", "true", "oui", "yes", "on"}


# --------------------------------------------------------------------------
# Sécurité
# --------------------------------------------------------------------------
# La clé de développement n'est utilisée que si .env n'en fournit pas. Aucune
# clé réelle ne figure dans le code : voir .env.example.
SECRET_KEY = env("SECRET_KEY") or "dev-uniquement-remplacez-moi-dans-le-fichier-env"

DEBUG = env_bool("DEBUG", True)

ALLOWED_HOSTS = [h.strip() for h in env("ALLOWED_HOSTS", "127.0.0.1,localhost").split(",") if h.strip()]

CSRF_TRUSTED_ORIGINS = [o.strip() for o in env("CSRF_TRUSTED_ORIGINS", "").split(",") if o.strip()]


# --------------------------------------------------------------------------
# Applications
# --------------------------------------------------------------------------
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # Modules développés
    "apps.accounts",
    "apps.administration",
    "apps.etudiant",
    "apps.themes",
    "apps.supervision",
    "apps.memories",
    "apps.notifications",
    "apps.defenses",
    "apps.archives",
    # Espaces des autres acteurs (phase 3)
    "apps.encadreur",
    "apps.etudes",
    "apps.academique",
    "apps.jury",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "apps.accounts.middleware.DernierAccesMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "apps.accounts.context_processors.contexte_plateforme",
                "apps.accounts.context_processors.compteurs_menu",
                "apps.notifications.context_processors.notifications",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"


# --------------------------------------------------------------------------
# Base de données
# --------------------------------------------------------------------------
if env("DB_ENGINE", "sqlite").lower().startswith("postgres"):
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": env("DB_NAME", "gcvm"),
            "USER": env("DB_USER", "gcvm"),
            "PASSWORD": env("DB_PASSWORD", ""),
            "HOST": env("DB_HOST", "localhost"),
            "PORT": env("DB_PORT", "5432"),
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
            "OPTIONS": {"timeout": 20},
        }
    }

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


# --------------------------------------------------------------------------
# Authentification
# --------------------------------------------------------------------------
AUTH_USER_MODEL = "accounts.Utilisateur"

AUTHENTICATION_BACKENDS = ["apps.accounts.backends.BackendEmail"]

LOGIN_URL = "comptes:connexion"
LOGIN_REDIRECT_URL = "comptes:redirection"
LOGOUT_REDIRECT_URL = "comptes:connexion"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
     "OPTIONS": {"min_length": 8}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# Les mots de passe sont hachés par Django (PBKDF2-SHA256 par défaut).
# Aucun mot de passe n'est jamais stocké en clair.

SESSION_COOKIE_AGE = 60 * 60 * 8          # 8 heures
SESSION_EXPIRE_AT_BROWSER_CLOSE = False
SESSION_SAVE_EVERY_REQUEST = True

PASSWORD_RESET_TIMEOUT = 60 * 60 * 24     # le lien de réinitialisation vaut 24 h


# --------------------------------------------------------------------------
# Messagerie
# --------------------------------------------------------------------------
# En développement, les emails (dont le lien de réinitialisation) s'affichent
# dans la console qui exécute runserver. Renseigner EMAIL_HOST dans .env
# suffit à basculer vers un envoi réel.
if env("EMAIL_HOST"):
    EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
    EMAIL_HOST = env("EMAIL_HOST")
    EMAIL_PORT = int(env("EMAIL_PORT", "587"))
    EMAIL_HOST_USER = env("EMAIL_HOST_USER", "")
    EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD", "")
    EMAIL_USE_TLS = env_bool("EMAIL_USE_TLS", True)
else:
    # Backend console enrichi : affiche le lien de réinitialisation en clair
    # plutôt que noyé dans l'encodage quoted-printable du message brut.
    EMAIL_BACKEND = "apps.accounts.mail.BackendConsoleLisible"

DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", "plateforme@lbs.com")


# --------------------------------------------------------------------------
# Internationalisation
# --------------------------------------------------------------------------
LANGUAGE_CODE = "fr-fr"
TIME_ZONE = env("TIME_ZONE", "Africa/Lome")
USE_I18N = True
USE_TZ = True


# --------------------------------------------------------------------------
# Fichiers statiques et médias
# --------------------------------------------------------------------------
STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"

MEDIA_URL = "media/"
MEDIA_ROOT = BASE_DIR / "media"

MESSAGE_STORAGE = "django.contrib.messages.storage.session.SessionStorage"


# --------------------------------------------------------------------------
# Paramètres propres à la plateforme
# --------------------------------------------------------------------------
GCVM = {
    "NOM_ETABLISSEMENT": env("NOM_ETABLISSEMENT", "Lomé Business School"),
    "SIGLE": env("SIGLE", "LBS"),
    "ELEMENTS_PAR_PAGE": int(env("ELEMENTS_PAR_PAGE", "12")),
    # Dépôt des mémoires
    "TAILLE_MAX_DEPOT_MO": int(env("TAILLE_MAX_DEPOT_MO", "50")),
    "EXTENSIONS_AUTORISEES": [e.strip().lower() for e in
                              env("EXTENSIONS_AUTORISEES", "pdf").split(",") if e.strip()],
    "EXTENSIONS_GUIDE": [e.strip().lower() for e in
                         env("EXTENSIONS_GUIDE", "pdf,docx").split(",") if e.strip()],
    # Soutenances
    "NB_MIN_MEMBRES_JURY": int(env("NB_MIN_MEMBRES_JURY", "3")),
    "DUREE_SOUTENANCE_MIN": int(env("DUREE_SOUTENANCE_MIN", "60")),
    # Au-dessus de ce score, deux titres de thème sont signalés comme proches.
    # 0.72 a été retenu après essais : en dessous, trop de faux positifs ;
    # au-dessus, les reformulations passent au travers.
    "SEUIL_SIMILARITE_THEME": float(env("SEUIL_SIMILARITE_THEME", "0.72")),
    # Compte administrateur initial, créé au premier `migrate`.
    "ADMIN_INITIAL_EMAIL": env("ADMIN_INITIAL_EMAIL", "admin@lbs.com"),
    "ADMIN_INITIAL_MOT_DE_PASSE": env("ADMIN_INITIAL_MOT_DE_PASSE", "admin1234567890"),
}


# --------------------------------------------------------------------------
# Durcissement en production uniquement
# --------------------------------------------------------------------------
if not DEBUG:
    SECURE_SSL_REDIRECT = env_bool("SECURE_SSL_REDIRECT", True)
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    SECURE_REFERRER_POLICY = "same-origin"
    X_FRAME_OPTIONS = "DENY"
