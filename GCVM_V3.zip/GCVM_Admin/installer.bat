@echo off
REM ============================================================
REM  Plateforme GCVM - Module Administrateur
REM  Installation automatique (Windows)
REM ============================================================
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo   Installation de la plateforme GCVM...
echo.

python --version >nul 2>&1
if errorlevel 1 (
  echo   [ERREUR] Python est introuvable.
  echo   Installez Python depuis python.org en cochant "Add Python to PATH".
  pause
  exit /b 1
)

if not exist venv (
  echo   [1/4] Creation de l'environnement virtuel...
  python -m venv venv
) else (
  echo   [1/4] Environnement virtuel deja present.
)

echo   [2/4] Installation des dependances...
call venv\Scripts\activate
python -m pip install --upgrade pip --quiet
pip install -r requirements.txt
if errorlevel 1 (
  echo   [ERREUR] L'installation des dependances a echoue.
  pause
  exit /b 1
)

if not exist .env (
  echo   [3/4] Creation du fichier .env...
  copy .env.example .env >nul
) else (
  echo   [3/4] Fichier .env deja present.
)

echo   [4/4] Preparation de la base de donnees...
python manage.py migrate

echo.
echo   ============================================================
echo    Installation terminee.
echo.
echo    Lancez la plateforme avec : demarrer.bat
echo    Puis ouvrez               : http://127.0.0.1:8000/
echo.
echo    Compte administrateur : admin@lbs.com / admin1234567890
echo   ============================================================
echo.
pause
