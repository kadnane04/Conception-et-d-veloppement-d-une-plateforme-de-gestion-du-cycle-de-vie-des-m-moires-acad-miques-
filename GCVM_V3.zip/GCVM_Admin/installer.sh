#!/usr/bin/env bash
# Plateforme GCVM — Module Administrateur : installation (Linux / macOS)
set -e
cd "$(dirname "$0")"

echo
echo "  Installation de la plateforme GCVM..."
echo

[ -d venv ] || { echo "  [1/4] Création de l'environnement virtuel..."; python3 -m venv venv; }
echo "  [2/4] Installation des dépendances..."
./venv/bin/python -m pip install --upgrade pip --quiet
./venv/bin/pip install -r requirements.txt

[ -f .env ] || { echo "  [3/4] Création du fichier .env..."; cp .env.example .env; }
echo "  [4/4] Préparation de la base de données..."
./venv/bin/python manage.py migrate

cat <<'FIN'

  ============================================================
   Installation terminée.

   Lancez la plateforme avec : ./demarrer.sh
   Puis ouvrez               : http://127.0.0.1:8000/

   Compte administrateur : admin@lbs.com / admin1234567890
  ============================================================

FIN
