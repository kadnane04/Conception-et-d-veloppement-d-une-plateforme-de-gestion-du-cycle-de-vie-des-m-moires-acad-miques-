#!/usr/bin/env python
"""Utilitaire en ligne de commande du projet GCVM."""

import os
import sys


def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Django est introuvable. Avez-vous activé l'environnement virtuel ?\n"
            "  Windows      : venv\\Scripts\\activate\n"
            "  Linux/macOS  : source venv/bin/activate\n"
            "Puis : pip install -r requirements.txt"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
