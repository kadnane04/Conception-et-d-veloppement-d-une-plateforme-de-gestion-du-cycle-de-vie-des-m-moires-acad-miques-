/* Interactions de la plateforme GCVM.
   Volontairement minimal : Bootstrap couvre le reste. */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {

    /* --- Menu latéral en écran étroit ----------------------------------- */
    var bouton = document.getElementById("bouton-menu");
    var laterale = document.getElementById("barre-laterale");
    if (bouton && laterale) {
      bouton.addEventListener("click", function () {
        laterale.classList.toggle("ouverte");
        basculerVoile(laterale.classList.contains("ouverte"));
      });
    }

    function basculerVoile(afficher) {
      var voile = document.getElementById("voile");
      if (afficher && !voile) {
        voile = document.createElement("div");
        voile.id = "voile";
        voile.className = "voile";
        voile.addEventListener("click", function () {
          laterale.classList.remove("ouverte");
          basculerVoile(false);
        });
        document.body.appendChild(voile);
      } else if (!afficher && voile) {
        voile.remove();
      }
    }

    /* --- Menus d'actions --------------------------------------------------
       Bootstrap câble normalement les menus tout seul, par attribut. On les
       initialise tout de même explicitement : si un autre script échoue avant
       lui, l'attribut ne suffit plus.

       Et si Bootstrap n'est pas chargé du tout, un repli maison prend le
       relais : le menu s'ouvre quand même. Sans cela, le bouton « … » reste
       visible mais inerte — exactement le symptôme à éviter.              */
    if (window.bootstrap && bootstrap.Dropdown) {
      document.querySelectorAll('[data-bs-toggle="dropdown"]').forEach(function (el) {
        // Les menus des tableaux sont positionnés en `fixed` : ils sortent
        // ainsi du conteneur défilant qui, sinon, les rognerait.
        var options = el.hasAttribute("data-menu-flottant")
          ? { popperConfig: { strategy: "fixed" } } : {};
        bootstrap.Dropdown.getOrCreateInstance(el, options);
      });
    } else {
      installerMenusDeSecours();
    }

    function installerMenusDeSecours() {
      function fermerTout() {
        document.querySelectorAll(".dropdown-menu.show").forEach(function (m) {
          m.classList.remove("show");
          var b = m.parentElement.querySelector('[data-bs-toggle="dropdown"]');
          if (b) { b.setAttribute("aria-expanded", "false"); }
        });
      }

      document.querySelectorAll('[data-bs-toggle="dropdown"]').forEach(function (bouton) {
        var menu = bouton.parentElement.querySelector(".dropdown-menu");
        if (!menu) { return; }

        bouton.addEventListener("click", function (evt) {
          evt.preventDefault();
          evt.stopPropagation();
          var ouvert = menu.classList.contains("show");
          fermerTout();
          if (ouvert) { return; }

          // Position calculée en `fixed` : le menu échappe à tout conteneur
          // qui rognerait son contenu, exactement comme le ferait Popper.
          menu.classList.add("show");
          bouton.setAttribute("aria-expanded", "true");
          var b = bouton.getBoundingClientRect();
          var m = menu.getBoundingClientRect();
          var basculeVersLeHaut = b.bottom + m.height > window.innerHeight - 8;
          menu.style.position = "fixed";
          menu.style.margin = "0";
          menu.style.left = Math.max(8, Math.min(b.right - m.width,
                                                 window.innerWidth - m.width - 8)) + "px";
          menu.style.top = (basculeVersLeHaut ? b.top - m.height - 4 : b.bottom + 4) + "px";
        });
      });

      document.addEventListener("click", fermerTout);
      window.addEventListener("resize", fermerTout);
      window.addEventListener("scroll", fermerTout, true);
      document.addEventListener("keydown", function (evt) {
        if (evt.key === "Escape") { fermerTout(); }
      });
    }

    /* --- Confirmation des actions sensibles ------------------------------
       Tout formulaire portant data-confirmation ouvre une fenêtre de
       confirmation avant d'être soumis. Le texte est porté par l'attribut,
       pour que chaque action dise précisément ce qu'elle va faire.        */
    var modale = document.getElementById("modale-confirmation");
    var instanceModale = modale && window.bootstrap ? new bootstrap.Modal(modale) : null;
    var formulaireEnAttente = null;

    document.querySelectorAll("form[data-confirmation]").forEach(function (f) {
      f.addEventListener("submit", function (evt) {
        if (f.dataset.confirme === "1") { return; }
        evt.preventDefault();
        formulaireEnAttente = f;
        if (instanceModale) {
          modale.querySelector("[data-role='titre']").textContent =
            f.dataset.titre || "Confirmer l'action";
          modale.querySelector("[data-role='texte']").textContent = f.dataset.confirmation;
          var valider = modale.querySelector("[data-role='valider']");
          valider.textContent = f.dataset.valider || "Confirmer";
          valider.className = "btn " + (f.dataset.critique === "1" ? "btn-critique" : "btn-gcvm");
          instanceModale.show();
        } else if (window.confirm(f.dataset.confirmation)) {
          f.dataset.confirme = "1";
          f.submit();
        }
      });
    });

    if (modale) {
      modale.querySelector("[data-role='valider']").addEventListener("click", function () {
        if (formulaireEnAttente) {
          formulaireEnAttente.dataset.confirme = "1";
          instanceModale.hide();
          formulaireEnAttente.submit();
        }
      });
    }

    /* --- Filtres qui se soumettent d'eux-mêmes -------------------------- */
    document.querySelectorAll("[data-auto-soumission]").forEach(function (champ) {
      champ.addEventListener("change", function () { champ.form.submit(); });
    });

    /* --- Afficher / masquer un mot de passe ----------------------------- */
    document.querySelectorAll("[data-bascule-mdp]").forEach(function (bouton) {
      bouton.addEventListener("click", function () {
        var cible = document.querySelector(bouton.dataset.basculeMdp);
        if (!cible) { return; }
        var visible = cible.type === "text";
        cible.type = visible ? "password" : "text";
        bouton.querySelector("i").className = visible ? "bi bi-eye" : "bi bi-eye-slash";
      });
    });

    /* --- Copier un mot de passe initial --------------------------------- */
    document.querySelectorAll("[data-copier]").forEach(function (bouton) {
      bouton.addEventListener("click", function () {
        var cible = document.querySelector(bouton.dataset.copier);
        if (!cible || !navigator.clipboard) { return; }
        navigator.clipboard.writeText(cible.value || cible.textContent).then(function () {
          var ancien = bouton.innerHTML;
          bouton.innerHTML = '<i class="bi bi-check2"></i> Copié';
          setTimeout(function () { bouton.innerHTML = ancien; }, 1600);
        });
      });
    });

    /* --- Effacement automatique des messages ---------------------------- */
    document.querySelectorAll(".alert[data-ephemere]").forEach(function (a) {
      setTimeout(function () {
        if (window.bootstrap) { bootstrap.Alert.getOrCreateInstance(a).close(); }
      }, 9000);
    });
  });
})();
