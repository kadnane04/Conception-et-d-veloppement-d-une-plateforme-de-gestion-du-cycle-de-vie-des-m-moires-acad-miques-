"""
Transitions du cycle de vie d'un mémoire.

Chaque transition est écrite **une seule fois, ici**, et appelée par la vue du
rôle concerné. Trois choses y sont faites ensemble, et c'est le point : changer
le statut, tracer la décision, prévenir les personnes concernées.

Éparpiller ces trois gestes dans les vues garantirait qu'un jour l'un des trois
soit oublié — typiquement la notification. Les regrouper rend l'oubli
impossible et les règles lisibles d'un seul endroit.
"""

from django.db import transaction
from django.utils import timezone

from apps.accounts.models import Role, Utilisateur
from apps.notifications.models import Notification, TypeNotification

from .models import DecisionMemoire, Memoire, StatutMemoire


def responsables_des_etudes():
    return Utilisateur.objects.filter(role=Role.RESP_ETUDES, is_active=True)


def responsables_academiques():
    return Utilisateur.objects.filter(role=Role.RESP_ACADEMIQUE, is_active=True)


def _prevenir(destinataires, type_notification, titre, message, lien=""):
    for destinataire in destinataires:
        if destinataire is not None:
            Notification.envoyer(destinataire, type_notification, titre, message, lien)


# ==========================================================================
# Étape 2 — l'encadreur se prononce sur le mémoire déposé
# ==========================================================================
@transaction.atomic
def valider_par_encadreur(memoire, auteur, commentaire=""):
    memoire.statut = StatutMemoire.VALIDE_ENCADREUR
    memoire.commentaire_encadreur = commentaire
    memoire.date_validation_encadreur = timezone.now()
    memoire.save(update_fields=["statut", "commentaire_encadreur",
                                "date_validation_encadreur"])

    DecisionMemoire.tracer(
        memoire, auteur, DecisionMemoire.Etape.ENCADREUR,
        DecisionMemoire.Sens.VALIDATION,
        f"Mémoire validé par l'encadreur {auteur.nom_complet}", commentaire)

    _prevenir([memoire.etudiant], TypeNotification.MEMOIRE_VALIDE,
              "Votre mémoire a été validé par votre encadreur",
              f"{auteur.nom_complet} a validé « {memoire.titre} ». Le dossier "
              f"part maintenant vers le Responsable des Études.", "/memoire/")

    _prevenir(responsables_des_etudes(), TypeNotification.MEMOIRE_VALIDE,
              "Mémoire prêt pour transmission académique",
              f"L'encadreur {auteur.nom_complet} a validé le mémoire de "
              f"{memoire.etudiant.nom_complet}. Il est prêt à être transmis au "
              f"Responsable Académique.", "/etudes/memoires/")
    return memoire


@transaction.atomic
def rejeter_par_encadreur(memoire, auteur, motif):
    memoire.statut = StatutMemoire.REJETE_ENCADREUR
    memoire.commentaire_encadreur = motif
    memoire.save(update_fields=["statut", "commentaire_encadreur"])

    DecisionMemoire.tracer(
        memoire, auteur, DecisionMemoire.Etape.ENCADREUR,
        DecisionMemoire.Sens.REJET,
        f"Mémoire rejeté par l'encadreur {auteur.nom_complet}", motif)

    _prevenir([memoire.etudiant], TypeNotification.MEMOIRE_REJETE,
              "Votre mémoire a été rejeté par votre encadreur",
              f"Motif : {motif}", "/memoire/")
    return memoire


# ==========================================================================
# Étape 3 — le Responsable des Études transmet
# ==========================================================================
@transaction.atomic
def transmettre(memoire, auteur):
    memoire.statut = StatutMemoire.TRANSMIS
    memoire.date_transmission = timezone.now()
    memoire.transmis_par = auteur if auteur.pk else None
    memoire.save(update_fields=["statut", "date_transmission", "transmis_par"])

    DecisionMemoire.tracer(
        memoire, auteur, DecisionMemoire.Etape.RESP_ETUDES,
        DecisionMemoire.Sens.TRANSMISSION,
        f"Dossier transmis au Responsable Académique par {auteur.nom_complet}")

    _prevenir(responsables_academiques(), TypeNotification.MEMOIRE_DEPOSE,
              "Nouveau mémoire à examiner",
              f"Le mémoire de {memoire.etudiant.nom_complet} — « {memoire.titre} » — "
              f"vous a été transmis pour validation.", "/academique/memoires/")

    _prevenir([memoire.etudiant, memoire.encadreur], TypeNotification.INFORMATION,
              "Votre dossier a été transmis",
              "Le Responsable des Études a transmis le mémoire au Responsable "
              "Académique.", "/memoire/")
    return memoire


# ==========================================================================
# Étape 4 — le Responsable Académique se prononce
# ==========================================================================
@transaction.atomic
def valider_par_academique(memoire, auteur, commentaire=""):
    memoire.statut = StatutMemoire.VALIDE_RESP_ACADEMIQUE
    memoire.commentaire_academique = commentaire
    memoire.date_validation_academique = timezone.now()
    memoire.save(update_fields=["statut", "commentaire_academique",
                                "date_validation_academique"])

    DecisionMemoire.tracer(
        memoire, auteur, DecisionMemoire.Etape.RESP_ACADEMIQUE,
        DecisionMemoire.Sens.VALIDATION,
        f"Mémoire validé par le Responsable Académique {auteur.nom_complet}",
        commentaire)

    # Les trois parties sont prévenues, comme le demande le cahier des charges.
    _prevenir([memoire.etudiant], TypeNotification.MEMOIRE_VALIDE,
              "Votre mémoire a été validé",
              "Le Responsable Académique a validé votre mémoire. La soutenance "
              "va être programmée.", "/memoire/")
    _prevenir([memoire.encadreur], TypeNotification.MEMOIRE_VALIDE,
              "Mémoire validé par le Responsable Académique",
              f"Le mémoire de {memoire.etudiant.nom_complet} a été validé.",
              "/encadreur/memoires/")
    _prevenir(responsables_des_etudes(), TypeNotification.MEMOIRE_VALIDE,
              "Mémoire validé — soutenance à planifier",
              f"Le mémoire de {memoire.etudiant.nom_complet} est validé. "
              f"Vous pouvez programmer la soutenance.", "/etudes/soutenances/")
    return memoire


@transaction.atomic
def rejeter_par_academique(memoire, auteur, motif):
    memoire.statut = StatutMemoire.REJETE_RESP_ACADEMIQUE
    memoire.commentaire_academique = motif
    memoire.save(update_fields=["statut", "commentaire_academique"])

    DecisionMemoire.tracer(
        memoire, auteur, DecisionMemoire.Etape.RESP_ACADEMIQUE,
        DecisionMemoire.Sens.REJET,
        f"Mémoire rejeté par le Responsable Académique {auteur.nom_complet}", motif)

    _prevenir([memoire.etudiant], TypeNotification.MEMOIRE_REJETE,
              "Votre mémoire a été rejeté", f"Motif : {motif}", "/memoire/")
    _prevenir([memoire.encadreur], TypeNotification.MEMOIRE_REJETE,
              "Mémoire rejeté par le Responsable Académique",
              f"Mémoire de {memoire.etudiant.nom_complet}. Motif : {motif}",
              "/encadreur/memoires/")
    _prevenir(responsables_des_etudes(), TypeNotification.MEMOIRE_REJETE,
              "Mémoire rejeté par le Responsable Académique",
              f"Mémoire de {memoire.etudiant.nom_complet}. Motif : {motif}",
              "/etudes/memoires/")
    return memoire


# ==========================================================================
# Étape 6 — version finale
# ==========================================================================
@transaction.atomic
def valider_version_finale(memoire, auteur):
    memoire.statut = StatutMemoire.FINALE_VALIDEE_ENCADREUR
    memoire.save(update_fields=["statut"])

    DecisionMemoire.tracer(
        memoire, auteur, DecisionMemoire.Etape.ENCADREUR,
        DecisionMemoire.Sens.VALIDATION,
        f"Version finale validée par l'encadreur {auteur.nom_complet}")

    _prevenir([memoire.etudiant], TypeNotification.MEMOIRE_VALIDE,
              "Votre version finale a été validée",
              "Votre encadreur a validé la version corrigée. Le Responsable des "
              "Études procédera à l'archivage.", "/memoire/")
    _prevenir(responsables_des_etudes(), TypeNotification.MEMOIRE_VALIDE,
              "Version finale prête à archiver",
              f"La version finale du mémoire de {memoire.etudiant.nom_complet} "
              f"a été validée par son encadreur.", "/etudes/archivage/")
    return memoire


@transaction.atomic
def rejeter_version_finale(memoire, auteur, motif):
    memoire.statut = StatutMemoire.FINALE_REJETEE_ENCADREUR
    memoire.commentaire_encadreur = motif
    memoire.save(update_fields=["statut", "commentaire_encadreur"])

    DecisionMemoire.tracer(
        memoire, auteur, DecisionMemoire.Etape.ENCADREUR,
        DecisionMemoire.Sens.REJET,
        f"Version finale rejetée par l'encadreur {auteur.nom_complet}", motif)

    _prevenir([memoire.etudiant], TypeNotification.MEMOIRE_REJETE,
              "Votre version finale a été rejetée",
              f"Motif : {motif}", "/memoire/")
    return memoire


# ==========================================================================
# Étape 7 — archivage
# ==========================================================================
@transaction.atomic
def archiver(memoire, auteur, niveau_acces=None):
    """
    Crée la fiche de bibliothèque à partir du dossier, puis clôt le mémoire.

    La fiche recopie titre, auteur, année et filière : elle doit rester
    lisible même si le compte étudiant est supprimé plus tard.
    """
    from apps.archives.models import MemoireArchive, NiveauAcces

    version = memoire.derniere_version_finale or memoire.derniere_version
    if version is None:
        raise ValueError("Aucune version déposée : rien à archiver.")

    profil = memoire.etudiant.profil
    soutenance = getattr(memoire, "soutenance", None)

    archive, cree = MemoireArchive.objects.get_or_create(
        memoire=memoire,
        defaults={
            "etudiant": memoire.etudiant,
            "encadreur": memoire.encadreur,
            "titre": memoire.titre,
            "auteur_nom": memoire.etudiant.nom_complet,
            "encadreur_nom": memoire.encadreur.nom_complet if memoire.encadreur else "",
            "annee": memoire.annee_academique.libelle,
            "filiere": profil.get_filiere_display() if profil else "",
            "resume": memoire.resume,
            "mots_cles": memoire.theme.mots_cles,
            "nom_original": version.nom_original,
            "taille_octets": version.taille_octets,
            "origine": MemoireArchive.Origine.PLATEFORME,
            "niveau_acces": niveau_acces or NiveauAcces.INTERNE,
            "note_finale": soutenance.note_finale if soutenance else None,
            "mention": soutenance.mention if soutenance else "",
            "archive_par": auteur if auteur.pk else None,
        })

    if cree:
        # Le fichier est recopié : l'archive ne doit pas dépendre du dossier
        # d'origine, qui pourrait être purgé.
        version.fichier.open("rb")
        archive.fichier.save(version.nom_original or f"memoire-{memoire.pk}.pdf",
                             version.fichier, save=True)
        version.fichier.close()

    memoire.statut = StatutMemoire.ARCHIVE
    memoire.date_archivage = timezone.now()
    memoire.save(update_fields=["statut", "date_archivage"])

    DecisionMemoire.tracer(
        memoire, auteur, DecisionMemoire.Etape.RESP_ETUDES,
        DecisionMemoire.Sens.ARCHIVAGE,
        f"Mémoire archivé dans la bibliothèque par {auteur.nom_complet}")

    _prevenir([memoire.etudiant, memoire.encadreur], TypeNotification.INFORMATION,
              "Votre mémoire est archivé",
              "Il figure désormais dans la bibliothèque numérique de "
              "l'établissement.", "/bibliotheque/")
    return archive
