"""Tests du module « memories » — phase ultérieure."""
