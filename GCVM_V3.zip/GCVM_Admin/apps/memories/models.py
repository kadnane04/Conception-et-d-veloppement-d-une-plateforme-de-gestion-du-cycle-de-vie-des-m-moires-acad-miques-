"""
Mémoires et versions déposées.

Décision structurante : **le dépôt n'écrase jamais le précédent**.

Chaque dépôt crée une ligne dans `VersionMemoire`. Le mémoire porte l'état du
dossier ; les versions portent l'historique des fichiers. Sans cette
séparation, la version 2 remplacerait la version 1 et l'étudiant comme
l'encadreur perdraient la trace du travail — or c'est précisément cette trace
que le suivi d'un mémoire doit produire.

Le fichier n'est pas servi directement : il passe par une vue qui vérifie
d'abord qui le demande (voir `apps/memories/views.py`). Un mémoire non soutenu
n'a pas à être téléchargeable par une URL devinée.
"""

import os

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone


class AnneeAcademique(models.Model):
    """Année universitaire, créée par l'administration."""

    libelle = models.CharField("Libellé", max_length=20, unique=True,
                               help_text="Exemple : 2025-2026")
    date_debut = models.DateField("Début", null=True, blank=True)
    date_fin = models.DateField("Fin", null=True, blank=True)
    est_active = models.BooleanField(
        "Année en cours", default=False,
        help_text="Une seule année peut être active à la fois.")

    class Meta:
        verbose_name = "Année académique"
        verbose_name_plural = "Années académiques"
        ordering = ["-libelle"]
        constraints = [
            models.UniqueConstraint(
                fields=["est_active"], condition=models.Q(est_active=True),
                name="ux_une_seule_annee_active"),
        ]

    def __str__(self):
        return self.libelle

    @classmethod
    def active(cls):
        return cls.objects.filter(est_active=True).first()


def valider_document(fichier):
    """
    Contrôle du fichier déposé : extension et taille.

    Les deux contrôles sont nécessaires. L'extension seule n'empêche pas un
    fichier de 900 Mo ; la taille seule n'empêche pas le dépôt d'un exécutable
    renommé en .pdf. Le contrôle vit dans le modèle, pas seulement dans le
    formulaire : il s'applique ainsi aussi aux imports et aux scripts.
    """
    extensions = settings.GCVM["EXTENSIONS_AUTORISEES"]
    taille_max = settings.GCVM["TAILLE_MAX_DEPOT_MO"]

    extension = os.path.splitext(fichier.name)[1].lower().lstrip(".")
    if extension not in extensions:
        raise ValidationError(
            f"Format « .{extension} » refusé. "
            f"Formats acceptés : {', '.join('.' + e for e in extensions)}.")

    if fichier.size > taille_max * 1024 * 1024:
        raise ValidationError(
            f"Fichier trop volumineux ({fichier.size / 1024 / 1024:.1f} Mo). "
            f"Maximum autorisé : {taille_max} Mo.")


def chemin_depot(instance, nom_fichier):
    """media/memoires/<année>/<étudiant>/v<n>_<nom>."""
    annee = instance.memoire.annee_academique.libelle.replace("/", "-")
    etudiant = instance.memoire.etudiant_id
    base = os.path.basename(nom_fichier).replace(" ", "_")
    return f"memoires/{annee}/etudiant-{etudiant}/v{instance.numero}_{base}"


class StatutMemoire(models.TextChoices):
    """
    Les états du dossier, dans l'ordre du cycle.

    Le cycle complet :
        dépôt → encadreur → responsable des études → responsable académique
        → soutenance → corrections → version finale → encadreur
        → responsable des études → archivage

    Chaque rejet renvoie le dossier à l'étudiant sans le détruire : il redépose
    une version, et le circuit repart à l'étape correspondante.
    """

    BROUILLON = "BROUILLON", "Brouillon"
    DEPOSE = "DEPOSE", "Déposé"
    VALIDE_ENCADREUR = "VALIDE_ENCADREUR", "Validé par l'encadreur"
    REJETE_ENCADREUR = "REJETE_ENCADREUR", "Rejeté par l'encadreur"
    TRANSMIS = "TRANSMIS", "Transmis au responsable académique"
    VALIDE_RESP_ACADEMIQUE = "VALIDE_RESP_ACADEMIQUE", "Validé par le responsable académique"
    REJETE_RESP_ACADEMIQUE = "REJETE_RESP_ACADEMIQUE", "Rejeté par le responsable académique"
    SOUTENANCE_PLANIFIEE = "SOUTENANCE_PLANIFIEE", "Soutenance programmée"
    SOUTENU = "SOUTENU", "Soutenu — corrections attendues"
    FINALE_DEPOSEE = "FINALE_DEPOSEE", "Version finale déposée"
    FINALE_VALIDEE_ENCADREUR = "FINALE_VALIDEE_ENCADREUR", "Version finale validée par l'encadreur"
    FINALE_REJETEE_ENCADREUR = "FINALE_REJETEE_ENCADREUR", "Version finale rejetée par l'encadreur"
    ARCHIVE = "ARCHIVE", "Archivé"


class Memoire(models.Model):
    """Le dossier de mémoire d'un étudiant, pour une année académique."""

    etudiant = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Étudiant",
        on_delete=models.CASCADE, related_name="memoires",
        limit_choices_to={"role": "ETUDIANT"})

    theme = models.ForeignKey(
        "themes.Theme", verbose_name="Thème", on_delete=models.PROTECT,
        related_name="memoires")

    encadreur = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Encadreur",
        on_delete=models.PROTECT, related_name="memoires_encadres",
        null=True, blank=True, limit_choices_to={"role": "PROFESSEUR"})

    annee_academique = models.ForeignKey(
        AnneeAcademique, verbose_name="Année académique",
        on_delete=models.PROTECT, related_name="memoires")

    titre = models.CharField("Titre du mémoire", max_length=250)
    resume = models.TextField("Résumé")

    statut = models.CharField(
        "Statut", max_length=25, choices=StatutMemoire.choices,
        default=StatutMemoire.BROUILLON)

    date_creation = models.DateTimeField("Ouverture du dossier", default=timezone.now)
    date_dernier_depot = models.DateTimeField("Dernier dépôt", null=True, blank=True)

    commentaire_encadreur = models.TextField("Observation de l'encadreur", blank=True)
    commentaire_academique = models.TextField("Observation du responsable académique", blank=True)

    # Dates clés du circuit, renseignées au fur et à mesure.
    date_validation_encadreur = models.DateTimeField(
        "Validé par l'encadreur le", null=True, blank=True)
    date_transmission = models.DateTimeField("Transmis le", null=True, blank=True)
    date_validation_academique = models.DateTimeField(
        "Validé par le responsable académique le", null=True, blank=True)
    date_archivage = models.DateTimeField("Archivé le", null=True, blank=True)

    transmis_par = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Transmis par",
        on_delete=models.SET_NULL, null=True, blank=True,
        related_name="memoires_transmis")

    class Meta:
        verbose_name = "Mémoire"
        verbose_name_plural = "Mémoires"
        ordering = ["-date_creation"]
        constraints = [
            # Un étudiant n'ouvre qu'un dossier par année académique.
            models.UniqueConstraint(
                fields=["etudiant", "annee_academique"],
                name="ux_memoire_par_etudiant_et_annee"),
            # Un thème validé n'alimente qu'un seul mémoire : c'est ce qui
            # donne son sens à la validation du thème.
            models.UniqueConstraint(fields=["theme"], name="ux_memoire_par_theme"),
        ]

    def __str__(self):
        return self.titre

    # -- État ---------------------------------------------------------------
    @property
    def derniere_version(self):
        return self.versions.order_by("-numero").first()

    @property
    def nb_versions(self):
        return self.versions.count()

    @property
    def prochain_numero(self):
        derniere = self.derniere_version
        return (derniere.numero + 1) if derniere else 1

    @property
    def est_depose(self):
        return self.statut != StatutMemoire.BROUILLON

    @property
    def couleur_statut(self):
        if self.statut in REJETS:
            return "rouge"
        if self.statut in {StatutMemoire.VALIDE_ENCADREUR,
                           StatutMemoire.VALIDE_RESP_ACADEMIQUE,
                           StatutMemoire.FINALE_VALIDEE_ENCADREUR,
                           StatutMemoire.ARCHIVE}:
            return "vert"
        if self.statut == StatutMemoire.BROUILLON:
            return "gris"
        if self.statut in {StatutMemoire.SOUTENU, StatutMemoire.SOUTENANCE_PLANIFIEE}:
            return "ambre"
        return "bleu"

    @property
    def etape_courante(self):
        """Rang atteint dans le circuit (voir ETAPES_CIRCUIT)."""
        return RANG_ETAPE.get(self.statut, 0)

    # -- Ce que chaque acteur peut faire, à cet instant ---------------------
    @property
    def attend_encadreur(self):
        return self.statut == StatutMemoire.DEPOSE

    @property
    def attend_transmission(self):
        return self.statut == StatutMemoire.VALIDE_ENCADREUR

    @property
    def attend_academique(self):
        return self.statut == StatutMemoire.TRANSMIS

    @property
    def attend_planification(self):
        return (self.statut == StatutMemoire.VALIDE_RESP_ACADEMIQUE
                and not hasattr(self, "soutenance"))

    @property
    def attend_version_finale(self):
        return self.statut in {StatutMemoire.SOUTENU,
                               StatutMemoire.FINALE_REJETEE_ENCADREUR}

    @property
    def attend_validation_finale_encadreur(self):
        return self.statut == StatutMemoire.FINALE_DEPOSEE

    @property
    def attend_archivage(self):
        return self.statut == StatutMemoire.FINALE_VALIDEE_ENCADREUR

    @property
    def est_archive(self):
        return self.statut == StatutMemoire.ARCHIVE

    @property
    def redepot_possible(self):
        """
        L'étudiant peut redéposer tant que son dossier n'a pas quitté sa main :
        après un rejet, ou avant que l'encadreur ne se soit prononcé. Une fois
        le dossier transmis, il ne lui appartient plus.
        """
        return self.statut in {StatutMemoire.DEPOSE,
                               StatutMemoire.REJETE_ENCADREUR,
                               StatutMemoire.REJETE_RESP_ACADEMIQUE}

    @property
    def derniere_version_finale(self):
        return self.versions.filter(est_finale=True).order_by("-numero").first()


# Le circuit affiché à l'étudiant et aux autres acteurs. Une seule définition,
# pour que tous les écrans racontent exactement la même histoire.
ETAPES_CIRCUIT = [
    (1, "Étudiant", "Dépôt du mémoire"),
    (2, "Encadreur", "Lecture et validation"),
    (3, "Resp. des études", "Transmission"),
    (4, "Resp. académique", "Validation"),
    (5, "Soutenance", "Jury et délibération"),
    (6, "Version finale", "Corrections puis archivage"),
]

RANG_ETAPE = {
    StatutMemoire.BROUILLON: 0,
    StatutMemoire.DEPOSE: 1,
    StatutMemoire.REJETE_ENCADREUR: 1,
    StatutMemoire.VALIDE_ENCADREUR: 2,
    StatutMemoire.TRANSMIS: 3,
    StatutMemoire.REJETE_RESP_ACADEMIQUE: 3,
    StatutMemoire.VALIDE_RESP_ACADEMIQUE: 4,
    StatutMemoire.SOUTENANCE_PLANIFIEE: 5,
    StatutMemoire.SOUTENU: 5,
    StatutMemoire.FINALE_DEPOSEE: 6,
    StatutMemoire.FINALE_REJETEE_ENCADREUR: 6,
    StatutMemoire.FINALE_VALIDEE_ENCADREUR: 6,
    StatutMemoire.ARCHIVE: 7,
}

REJETS = {
    StatutMemoire.REJETE_ENCADREUR,
    StatutMemoire.REJETE_RESP_ACADEMIQUE,
    StatutMemoire.FINALE_REJETEE_ENCADREUR,
}


class VersionMemoire(models.Model):
    """Un fichier déposé, à une date, par quelqu'un. Jamais écrasé."""

    memoire = models.ForeignKey(
        Memoire, verbose_name="Mémoire", on_delete=models.CASCADE,
        related_name="versions")
    numero = models.PositiveSmallIntegerField("Version")
    est_finale = models.BooleanField(
        "Version finale", default=False,
        help_text="Version déposée après la soutenance, corrections comprises.")
    fichier = models.FileField(
        "Fichier", upload_to=chemin_depot, validators=[valider_document])
    taille_octets = models.PositiveBigIntegerField("Taille", default=0)
    nom_original = models.CharField("Nom du fichier déposé", max_length=255, blank=True)
    commentaire = models.TextField(
        "Note de version", blank=True,
        help_text="Facultatif : ce qui a changé depuis la version précédente.")

    depose_par = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Déposée par",
        on_delete=models.SET_NULL, null=True, related_name="versions_deposees")
    date_depot = models.DateTimeField("Date du dépôt", default=timezone.now)

    class Meta:
        verbose_name = "Version du mémoire"
        verbose_name_plural = "Versions du mémoire"
        ordering = ["-numero"]
        constraints = [
            models.UniqueConstraint(fields=["memoire", "numero"],
                                    name="ux_version_par_memoire"),
        ]

    def __str__(self):
        suffixe = " (finale)" if self.est_finale else ""
        return f"{self.memoire} — version {self.numero}{suffixe}"

    @property
    def taille_lisible(self):
        octets = self.taille_octets or 0
        if octets < 1024:
            return f"{octets} o"
        if octets < 1024 * 1024:
            return f"{octets / 1024:.0f} Ko"
        return f"{octets / 1024 / 1024:.1f} Mo"


class DecisionMemoire(models.Model):
    """
    Trace des décisions prises sur un mémoire.

    Chaque validation, rejet, transmission ou archivage y laisse une ligne :
    qui, quand, à quelle étape, et pour quel motif. C'est ce qui permet à
    n'importe quel acteur — et au jury le jour de la soutenance — de
    reconstituer le parcours du dossier sans interroger personne.

    Le libellé est figé à l'écriture : il reste lisible même si le compte de
    l'auteur est supprimé par la suite.
    """

    class Etape(models.TextChoices):
        ENCADREUR = "ENCADREUR", "Encadreur"
        RESP_ETUDES = "RESP_ETUDES", "Responsable des études"
        RESP_ACADEMIQUE = "RESP_ACADEMIQUE", "Responsable académique"
        JURY = "JURY", "Jury"
        ETUDIANT = "ETUDIANT", "Étudiant"

    class Sens(models.TextChoices):
        DEPOT = "DEPOT", "Dépôt"
        VALIDATION = "VALIDATION", "Validation"
        REJET = "REJET", "Rejet"
        TRANSMISSION = "TRANSMISSION", "Transmission"
        PLANIFICATION = "PLANIFICATION", "Planification de la soutenance"
        SOUTENANCE = "SOUTENANCE", "Soutenance tenue"
        ARCHIVAGE = "ARCHIVAGE", "Archivage"

    memoire = models.ForeignKey(
        Memoire, verbose_name="Mémoire", on_delete=models.CASCADE,
        related_name="decisions")
    auteur = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Auteur", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="decisions_memoire")
    etape = models.CharField("Étape", max_length=20, choices=Etape.choices)
    sens = models.CharField("Nature", max_length=20, choices=Sens.choices)
    libelle = models.CharField("Résumé", max_length=255)
    motif = models.TextField("Motif", blank=True)
    horodatage = models.DateTimeField("Date", default=timezone.now)

    class Meta:
        verbose_name = "Décision sur un mémoire"
        verbose_name_plural = "Décisions sur les mémoires"
        ordering = ["-horodatage"]

    def __str__(self):
        return f"{self.horodatage:%d/%m/%Y} — {self.libelle}"

    @property
    def couleur(self):
        return {self.Sens.REJET: "rouge",
                self.Sens.VALIDATION: "vert",
                self.Sens.ARCHIVAGE: "vert",
                self.Sens.SOUTENANCE: "ambre"}.get(self.sens, "bleu")

    @classmethod
    def tracer(cls, memoire, auteur, etape, sens, libelle, motif=""):
        return cls.objects.create(
            memoire=memoire, auteur=auteur if (auteur and auteur.pk) else None,
            etape=etape, sens=sens, libelle=libelle[:255], motif=motif)
