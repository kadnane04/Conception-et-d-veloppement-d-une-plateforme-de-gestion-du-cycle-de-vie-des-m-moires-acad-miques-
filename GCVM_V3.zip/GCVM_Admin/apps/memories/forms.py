"""Formulaires de dépôt du mémoire."""

from django import forms
from django.conf import settings

from apps.accounts.forms import styliser

from .models import AnneeAcademique, valider_document


class ChampFichierMemoire(forms.FileField):
    """Champ fichier qui applique le contrôle d'extension et de taille."""

    def __init__(self, *args, **kwargs):
        extensions = settings.GCVM["EXTENSIONS_AUTORISEES"]
        kwargs.setdefault("label", "Fichier du mémoire")
        kwargs.setdefault(
            "help_text",
            f"Format accepté : {', '.join('.' + e for e in extensions)}. "
            f"Taille maximale : {settings.GCVM['TAILLE_MAX_DEPOT_MO']} Mo.")
        kwargs.setdefault("widget", forms.ClearableFileInput(attrs={
            "accept": ",".join("." + e for e in extensions)}))
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        fichier = super().clean(data, initial)
        if fichier:
            # Le contrôle du modèle est réappliqué ici pour que l'erreur
            # s'affiche dans le formulaire plutôt que de remonter en exception.
            valider_document(fichier)
        return fichier


class DepotMemoireForm(forms.Form):
    """Premier dépôt : ouverture du dossier."""

    annee_academique = forms.ModelChoiceField(
        label="Année académique", queryset=AnneeAcademique.objects.none(),
        empty_label="— Choisissez une année —")
    titre = forms.CharField(label="Titre du mémoire", max_length=250)
    resume = forms.CharField(
        label="Résumé", widget=forms.Textarea(attrs={
            "rows": 5, "placeholder": "Quelques paragraphes présentant le travail."}))
    fichier = ChampFichierMemoire()
    commentaire = forms.CharField(
        label="Note de version", required=False,
        widget=forms.Textarea(attrs={
            "rows": 2, "placeholder": "Facultatif : une précision à l'attention de l'encadreur."}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        annees = AnneeAcademique.objects.all()
        self.fields["annee_academique"].queryset = annees
        active = AnneeAcademique.active()
        if active is not None and not self.is_bound:
            self.fields["annee_academique"].initial = active.pk
        styliser(self)

    def clean_titre(self):
        titre = " ".join(self.cleaned_data["titre"].split())
        if len(titre) < 10:
            raise forms.ValidationError("Le titre du mémoire est trop court.")
        return titre

    def clean_resume(self):
        resume = self.cleaned_data["resume"].strip()
        if len(resume) < 100:
            raise forms.ValidationError(
                "Le résumé doit faire au moins 100 caractères : il sert à "
                "présenter le travail à l'encadreur et au jury.")
        return resume


class NouvelleVersionForm(forms.Form):
    """Dépôt d'une version corrigée : seul le fichier est redemandé."""

    fichier = ChampFichierMemoire()
    commentaire = forms.CharField(
        label="Ce qui a changé", required=False,
        widget=forms.Textarea(attrs={
            "rows": 2,
            "placeholder": "Facultatif : corrections apportées depuis la version précédente."}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        styliser(self)


class VersionFinaleForm(forms.Form):
    """
    Dépôt de la version corrigée, après la soutenance.

    Le champ « corrections apportées » est obligatoire ici, alors qu'il est
    facultatif pour les versions intermédiaires : l'encadreur doit pouvoir
    vérifier que les remarques du jury ont bien été prises en compte.
    """

    fichier = ChampFichierMemoire(label="Version finale du mémoire")
    commentaire = forms.CharField(
        label="Corrections apportées",
        widget=forms.Textarea(attrs={
            "rows": 4,
            "placeholder": "Reprenez point par point les remarques du jury et "
                           "ce que vous avez modifié."}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        styliser(self)

    def clean_commentaire(self):
        texte = self.cleaned_data["commentaire"].strip()
        if len(texte) < 40:
            raise forms.ValidationError(
                "Décrivez les corrections apportées : c'est ce que votre "
                "encadreur vérifiera avant de valider.")
        return texte
