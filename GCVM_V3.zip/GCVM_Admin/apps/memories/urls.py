"""Routes du module Mémoires — côté étudiant."""

from django.urls import path

from . import views

app_name = "memoires"

urlpatterns = [
    path("", views.mon_memoire, name="mon_memoire"),
    path("deposer/", views.deposer, name="deposer"),
    path("nouvelle-version/", views.nouvelle_version, name="nouvelle_version"),
    path("version-finale/", views.deposer_version_finale, name="version_finale"),
    path("version/<int:pk>/telecharger/", views.telecharger_version, name="telecharger_version"),
]
