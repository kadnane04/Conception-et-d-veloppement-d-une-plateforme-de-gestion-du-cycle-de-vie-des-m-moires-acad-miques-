"""
Dépôt du mémoire — côté étudiant.

Deux règles structurent ce module.

1. **L'étape n'est ouverte que si le thème est validé et l'encadreur a
   accepté.** Déposer un mémoire sans encadreur désigné n'aurait personne à
   qui l'adresser.

2. **Chaque dépôt crée une version.** Rien n'est écrasé. L'étudiant peut
   redéposer tant que le responsable académique n'a pas validé.
"""

import os

from django.contrib import messages
from django.db import transaction
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from apps.etudiant.decorators import etudiant_requis
from apps.notifications.models import Notification, TypeNotification
from apps.supervision.models import DemandeEncadrement, StatutDemande
from apps.themes.models import StatutTheme

from .forms import DepotMemoireForm, NouvelleVersionForm, VersionFinaleForm
from .models import (
    ETAPES_CIRCUIT, AnneeAcademique, DecisionMemoire, Memoire, StatutMemoire,
    VersionMemoire,
)


def etat_dossier(etudiant):
    """Renvoie (thème validé, demande acceptée, mémoire) — chacun ou None."""
    theme = etudiant.themes.filter(statut=StatutTheme.VALIDE).first()
    demande = (etudiant.demandes_encadrement
               .filter(statut=StatutDemande.ACCEPTE)
               .select_related("encadreur").first())
    memoire = (etudiant.memoires
               .select_related("theme", "encadreur", "annee_academique")
               .order_by("-date_creation").first())
    return theme, demande, memoire


def _verrou(requete, raison, detail, lien, libelle):
    return render(requete, "memoires/etape_verrouillee.html", {
        "rubrique": "memoire", "raison": raison, "detail": detail,
        "lien": lien, "libelle_lien": libelle,
    })


@etudiant_requis
def mon_memoire(requete):
    """Point d'entrée : dépôt initial, ou suivi du dossier existant."""
    theme, demande, memoire = etat_dossier(requete.user)

    if memoire is not None:
        return render(requete, "memoires/mon_memoire.html", {
            "rubrique": "memoire",
            "memoire": memoire,
            "versions": memoire.versions.select_related("depose_par"),
            "decisions": memoire.decisions.select_related("auteur"),
            "formulaire": NouvelleVersionForm(),
            "formulaire_finale": VersionFinaleForm(),
            "etapes": ETAPES_CIRCUIT,
            "soutenance": getattr(memoire, "soutenance", None),
        })

    if theme is None:
        return _verrou(
            requete, "Votre thème doit d'abord être validé.",
            "Le dépôt du mémoire s'ouvre une fois le sujet accepté par le "
            "Responsable des Études, puis l'encadrement accepté par un professeur.",
            "themes:mes_themes", "Voir mes thèmes")

    if demande is None:
        return _verrou(
            requete, "Un encadreur doit d'abord accepter votre demande.",
            "Votre thème est validé. Il reste à obtenir l'accord d'un encadreur "
            "avant de pouvoir déposer votre mémoire.",
            "supervision:mes_demandes", "Voir mes demandes d'encadrement")

    return redirect("memoires:deposer")


@etudiant_requis
def deposer(requete):
    """Premier dépôt : ouverture du dossier et enregistrement de la version 1."""
    theme, demande, memoire = etat_dossier(requete.user)

    if memoire is not None:
        return redirect("memoires:mon_memoire")
    if theme is None or demande is None:
        return redirect("memoires:mon_memoire")

    formulaire = DepotMemoireForm(requete.POST or None, requete.FILES or None,
                                  initial={"titre": theme.titre})

    if requete.method == "POST" and formulaire.is_valid():
        with transaction.atomic():
            memoire = Memoire.objects.create(
                etudiant=requete.user,
                theme=theme,
                encadreur=demande.encadreur,
                annee_academique=formulaire.cleaned_data["annee_academique"],
                titre=formulaire.cleaned_data["titre"],
                resume=formulaire.cleaned_data["resume"],
                statut=StatutMemoire.DEPOSE,
                date_dernier_depot=timezone.now(),
            )
            _enregistrer_version(memoire, formulaire.cleaned_data["fichier"],
                                 requete.user, formulaire.cleaned_data.get("commentaire", ""))

            Notification.envoyer(
                requete.user, TypeNotification.MEMOIRE_DEPOSE,
                "Votre mémoire a été déposé",
                f"La version 1 de « {memoire.titre} » a bien été enregistrée. "
                f"Elle est transmise à {demande.encadreur.nom_complet}.",
                lien="/memoire/")
            Notification.envoyer(
                demande.encadreur, TypeNotification.MEMOIRE_DEPOSE,
                "Nouveau mémoire déposé",
                f"{requete.user.nom_complet} a déposé son mémoire "
                f"« {memoire.titre} ».")

        messages.success(requete, "Votre mémoire a été déposé. Statut : Déposé.")
        return redirect("memoires:mon_memoire")

    return render(requete, "memoires/deposer.html", {
        "rubrique": "memoire", "formulaire": formulaire,
        "theme": theme, "encadreur": demande.encadreur,
    })


@etudiant_requis
def nouvelle_version(requete):
    """Dépôt d'une version corrigée. Le dossier conserve toutes les versions."""
    _, _, memoire = etat_dossier(requete.user)
    if memoire is None:
        return redirect("memoires:mon_memoire")

    if requete.method != "POST":
        return redirect("memoires:mon_memoire")

    if not memoire.redepot_possible:
        messages.warning(
            requete,
            "Votre mémoire a été validé par le responsable académique : "
            "le dossier est clos, plus aucune version ne peut être déposée.")
        return redirect("memoires:mon_memoire")

    formulaire = NouvelleVersionForm(requete.POST, requete.FILES)
    if not formulaire.is_valid():
        for champ, erreurs in formulaire.errors.items():
            for erreur in erreurs:
                messages.error(requete, erreur)
        return redirect("memoires:mon_memoire")

    with transaction.atomic():
        version = _enregistrer_version(
            memoire, formulaire.cleaned_data["fichier"], requete.user,
            formulaire.cleaned_data.get("commentaire", ""))
        memoire.statut = StatutMemoire.DEPOSE
        memoire.date_dernier_depot = timezone.now()
        memoire.save(update_fields=["statut", "date_dernier_depot"])

        Notification.envoyer(
            requete.user, TypeNotification.MEMOIRE_DEPOSE,
            f"Version {version.numero} déposée",
            f"La version {version.numero} de votre mémoire a été enregistrée "
            f"et transmise à votre encadreur.", lien="/memoire/")
        if memoire.encadreur:
            Notification.envoyer(
                memoire.encadreur, TypeNotification.MEMOIRE_DEPOSE,
                "Nouvelle version déposée",
                f"{requete.user.nom_complet} a déposé la version "
                f"{version.numero} de « {memoire.titre} ».")

    messages.success(requete, f"Version {version.numero} déposée.")
    return redirect("memoires:mon_memoire")


def _enregistrer_version(memoire, fichier, auteur, commentaire=""):
    """Crée la version suivante. Le numéro est calculé, jamais fourni."""
    return VersionMemoire.objects.create(
        memoire=memoire,
        numero=memoire.prochain_numero,
        fichier=fichier,
        taille_octets=fichier.size,
        nom_original=os.path.basename(fichier.name)[:255],
        commentaire=commentaire,
        depose_par=auteur,
    )


@etudiant_requis
def deposer_version_finale(requete):
    """
    Dépôt de la version corrigée après la soutenance.

    Elle est marquée `est_finale` : c'est elle que l'encadreur validera, puis
    que le Responsable des Études archivera. Les versions intermédiaires
    restent en place — l'historique du travail n'est jamais effacé.
    """
    _, _, memoire = etat_dossier(requete.user)
    if memoire is None or requete.method != "POST":
        return redirect("memoires:mon_memoire")

    if not memoire.attend_version_finale:
        messages.warning(
            requete,
            "La version finale se dépose après la soutenance, une fois les "
            "corrections effectuées.")
        return redirect("memoires:mon_memoire")

    formulaire = VersionFinaleForm(requete.POST, requete.FILES)
    if not formulaire.is_valid():
        for erreurs in formulaire.errors.values():
            for erreur in erreurs:
                messages.error(requete, erreur)
        return redirect("memoires:mon_memoire")

    with transaction.atomic():
        version = _enregistrer_version(
            memoire, formulaire.cleaned_data["fichier"], requete.user,
            formulaire.cleaned_data.get("commentaire", ""))
        version.est_finale = True
        version.save(update_fields=["est_finale"])

        memoire.statut = StatutMemoire.FINALE_DEPOSEE
        memoire.date_dernier_depot = timezone.now()
        memoire.save(update_fields=["statut", "date_dernier_depot"])

        DecisionMemoire.tracer(
            memoire, requete.user, DecisionMemoire.Etape.ETUDIANT,
            DecisionMemoire.Sens.DEPOT,
            f"Version finale déposée (version {version.numero})",
            formulaire.cleaned_data.get("commentaire", ""))

        Notification.envoyer(
            memoire.encadreur, TypeNotification.MEMOIRE_DEPOSE,
            "Version finale déposée",
            f"{requete.user.nom_complet} a déposé la version finale corrigée de "
            f"« {memoire.titre} ». Elle attend votre validation.",
            "/encadreur/memoires/")
        Notification.envoyer(
            requete.user, TypeNotification.MEMOIRE_DEPOSE,
            "Votre version finale a été déposée",
            "Elle est transmise à votre encadreur pour validation.", "/memoire/")

    messages.success(
        requete,
        f"Version finale déposée (version {version.numero}). Elle attend la "
        f"validation de votre encadreur.")
    return redirect("memoires:mon_memoire")


@etudiant_requis
def telecharger_version(requete, pk):
    """
    Téléchargement d'une version.

    Le fichier n'est pas exposé par une URL publique : cette vue vérifie que
    le demandeur est bien l'auteur du mémoire. Les autres profils (encadreur,
    responsable académique) obtiendront leur propre accès dans leurs modules.
    """
    version = get_object_or_404(
        VersionMemoire.objects.select_related("memoire"),
        pk=pk, memoire__etudiant=requete.user)

    if not version.fichier or not version.fichier.storage.exists(version.fichier.name):
        raise Http404("Le fichier de cette version est introuvable.")

    return FileResponse(
        version.fichier.open("rb"), as_attachment=True,
        filename=version.nom_original or os.path.basename(version.fichier.name))
