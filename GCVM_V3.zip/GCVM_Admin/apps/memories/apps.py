from django.apps import AppConfig


class MemoriesConfig(AppConfig):
    """Mémoires : dossier, dépôts versionnés, circuit de validation."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.memories"
    verbose_name = "Mémoires"
