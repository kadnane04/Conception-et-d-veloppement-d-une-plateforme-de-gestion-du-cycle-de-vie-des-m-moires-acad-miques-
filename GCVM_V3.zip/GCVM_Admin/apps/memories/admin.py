"""Administration Django du module « memories » — phase ultérieure."""
