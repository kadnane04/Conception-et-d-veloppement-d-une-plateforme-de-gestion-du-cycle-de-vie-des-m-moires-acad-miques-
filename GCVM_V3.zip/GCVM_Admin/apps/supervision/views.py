"""
Choix de l'encadreur — côté étudiant.

Règle d'accès : cette étape n'est ouverte que si l'étudiant a un thème validé.
Choisir un encadreur avant que le sujet soit accepté n'aurait pas de sens —
c'est le sujet qui détermine qui peut l'encadrer.
"""

from django.contrib import messages
from django.db import IntegrityError, transaction
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404, redirect, render

from apps.accounts.models import Grade, ProfilProfesseur, Role, StatutProfesseur, Utilisateur
from apps.etudiant.decorators import etudiant_requis
from apps.notifications.models import Notification, TypeNotification
from apps.themes.models import StatutTheme

from .models import DemandeEncadrement, StatutDemande


def etat_encadrement(etudiant):
    """Renvoie (thème validé ou None, demande en cours ou None)."""
    theme = etudiant.themes.filter(statut=StatutTheme.VALIDE).first()
    demande = (etudiant.demandes_encadrement
               .filter(statut__in=[StatutDemande.EN_ATTENTE, StatutDemande.ACCEPTE])
               .select_related("encadreur", "theme").first())
    return theme, demande


def encadreurs_disponibles():
    """
    Les professeurs habilités à encadrer.

    Le statut du profil fait foi : `ENCADREUR` ou `ENCADREUR_JURY`. Un
    professeur uniquement membre de jury n'apparaît pas — et il n'a pas pour
    autant un second compte quelque part.
    """
    return (Utilisateur.objects
            .filter(role=Role.PROFESSEUR, is_active=True,
                    profilprofesseur__statut__in=[StatutProfesseur.ENCADREUR,
                                                  StatutProfesseur.ENCADREUR_JURY])
            .select_related("profilprofesseur")
            .annotate(charge=Count("demandes_recues",
                                   filter=Q(demandes_recues__statut=StatutDemande.ACCEPTE)))
            .order_by("nom", "prenom"))


@etudiant_requis
def liste(requete):
    """Liste des encadreurs, avec recherche et filtre par grade."""
    theme, demande = etat_encadrement(requete.user)

    if theme is None:
        return render(requete, "supervision/etape_verrouillee.html", {
            "rubrique": "encadreur",
            "raison": "Vous devez d'abord faire valider un thème.",
            "detail": "Le choix de l'encadreur s'ouvre dès que le Responsable "
                      "des Études a validé votre proposition de sujet.",
            "lien": "themes:mes_themes", "libelle_lien": "Voir mes thèmes",
        })

    if demande is not None:
        # Une demande est déjà engagée : on montre son état plutôt que la liste.
        return redirect("supervision:mes_demandes")

    encadreurs = encadreurs_disponibles()

    recherche = requete.GET.get("q", "").strip()
    if recherche:
        encadreurs = encadreurs.filter(
            Q(nom__icontains=recherche) | Q(prenom__icontains=recherche)
            | Q(profilprofesseur__specialite__icontains=recherche)
            | Q(profilprofesseur__domaines_recherche__icontains=recherche))

    grade = requete.GET.get("grade", "")
    if grade:
        encadreurs = encadreurs.filter(profilprofesseur__grade=grade)

    return render(requete, "supervision/liste.html", {
        "rubrique": "encadreur",
        "theme": theme,
        "encadreurs": encadreurs,
        "recherche": recherche, "grade": grade, "grades": Grade.choices,
        "total": encadreurs_disponibles().count(),
    })


@etudiant_requis
def detail(requete, pk):
    """Fiche complète d'un encadreur, avec le bouton de sélection."""
    theme, demande = etat_encadrement(requete.user)
    encadreur = get_object_or_404(
        Utilisateur.objects.select_related("profilprofesseur"),
        pk=pk, role=Role.PROFESSEUR, is_active=True)

    profil = encadreur.profil
    if profil is None or not profil.est_encadreur:
        return render(requete, "supervision/etape_verrouillee.html", {
            "rubrique": "encadreur",
            "raison": "Ce professeur n'encadre pas de mémoire.",
            "detail": "Seuls les professeurs habilités à l'encadrement "
                      "apparaissent dans la liste.",
            "lien": "supervision:liste", "libelle_lien": "Retour à la liste",
        })

    return render(requete, "supervision/detail.html", {
        "rubrique": "encadreur",
        "encadreur": encadreur, "profil": profil,
        "theme": theme, "demande": demande,
        "peut_choisir": theme is not None and demande is None,
    })


@etudiant_requis
def choisir(requete, pk):
    """Création de la demande d'encadrement. Toujours en POST, après confirmation."""
    if requete.method != "POST":
        return redirect("supervision:detail", pk=pk)

    theme, demande = etat_encadrement(requete.user)

    if theme is None:
        messages.error(requete, "Vous devez d'abord faire valider un thème.")
        return redirect("themes:mes_themes")

    if demande is not None:
        messages.warning(
            requete,
            "Une demande d'encadrement est déjà en cours. Attendez la réponse "
            "avant d'en adresser une autre.")
        return redirect("supervision:mes_demandes")

    encadreur = get_object_or_404(Utilisateur, pk=pk, role=Role.PROFESSEUR, is_active=True)
    profil = encadreur.profil
    if profil is None or not profil.est_encadreur:
        messages.error(requete, "Ce professeur n'encadre pas de mémoire.")
        return redirect("supervision:liste")

    try:
        with transaction.atomic():
            nouvelle = DemandeEncadrement.objects.create(
                etudiant=requete.user, encadreur=encadreur, theme=theme,
                message=requete.POST.get("message", "").strip()[:2000])

            # L'étudiant est informé de sa propre demande : son historique de
            # notifications raconte alors tout le parcours.
            Notification.envoyer(
                requete.user, TypeNotification.ENCADREUR_DEMANDE,
                "Demande d'encadrement envoyée",
                f"Votre demande a été transmise à {encadreur.nom_complet}. "
                f"Vous serez prévenu dès qu'une réponse sera donnée.",
                lien="/encadrement/mes-demandes/")

            # Et l'encadreur la reçoit. Son traitement relève du module
            # Encadreur, développé dans une phase ultérieure.
            Notification.envoyer(
                encadreur, TypeNotification.ENCADREUR_DEMANDE,
                "Nouvelle demande d'encadrement",
                f"{requete.user.nom_complet} sollicite votre encadrement pour "
                f"le thème « {theme.titre} ».")
    except IntegrityError:
        # La contrainte d'unicité a joué : deux envois quasi simultanés.
        messages.warning(requete, "Une demande d'encadrement est déjà en cours.")
        return redirect("supervision:mes_demandes")

    messages.success(
        requete,
        f"Votre demande a été envoyée à {encadreur.nom_complet}. "
        f"Elle est en attente de sa réponse.")
    return redirect("supervision:mes_demandes")


@etudiant_requis
def mes_demandes(requete):
    """Historique : encadreur choisi, date de demande, statut."""
    demandes = (requete.user.demandes_encadrement
                .select_related("encadreur", "encadreur__profilprofesseur", "theme")
                .order_by("-date_demande"))
    theme, en_cours = etat_encadrement(requete.user)

    return render(requete, "supervision/mes_demandes.html", {
        "rubrique": "encadreur",
        "demandes": demandes, "theme": theme, "en_cours": en_cours,
        "peut_choisir": theme is not None and en_cours is None,
    })
