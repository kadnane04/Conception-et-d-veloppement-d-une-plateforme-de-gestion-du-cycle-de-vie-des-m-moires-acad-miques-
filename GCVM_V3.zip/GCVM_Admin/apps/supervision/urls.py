"""Routes du module Encadrement — côté étudiant."""

from django.urls import path

from . import views

app_name = "supervision"

urlpatterns = [
    path("encadreurs/", views.liste, name="liste"),
    path("encadreurs/<int:pk>/", views.detail, name="detail"),
    path("encadreurs/<int:pk>/choisir/", views.choisir, name="choisir"),
    path("mes-demandes/", views.mes_demandes, name="mes_demandes"),
]
