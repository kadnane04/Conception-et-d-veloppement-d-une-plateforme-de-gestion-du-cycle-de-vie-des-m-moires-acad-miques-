from django.apps import AppConfig


class SupervisionConfig(AppConfig):
    """Encadrement : demandes adressées par les étudiants aux professeurs."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.supervision"
    verbose_name = "Encadrement"
