"""Administration Django du module « supervision » — phase ultérieure."""
