"""
Encadrement : demandes adressées par les étudiants aux professeurs.

Le point de conception à retenir : **l'encadrement est une association, pas un
rôle de compte**. Un professeur ne « devient » pas encadreur ; il encadre tel
étudiant, sur tel thème, à telle date. Son aptitude à le faire est portée par
`ProfilProfesseur.statut` ; l'exercice effectif l'est par cette table.

C'est ce qui permet à un même professeur, avec un compte unique, d'encadrer un
mémoire, de siéger au jury d'un autre, et de n'avoir aucun rôle sur un
troisième.
"""

from django.conf import settings
from django.db import models
from django.utils import timezone


class StatutDemande(models.TextChoices):
    EN_ATTENTE = "EN_ATTENTE", "En attente"
    ACCEPTE = "ACCEPTE", "Accepté"
    REFUSE = "REFUSE", "Refusé"


class DemandeEncadrement(models.Model):
    """Demande d'un étudiant à un professeur, pour un thème validé."""

    etudiant = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Étudiant",
        on_delete=models.CASCADE, related_name="demandes_encadrement",
        limit_choices_to={"role": "ETUDIANT"})

    encadreur = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Encadreur sollicité",
        on_delete=models.CASCADE, related_name="demandes_recues",
        limit_choices_to={"role": "PROFESSEUR"})

    theme = models.ForeignKey(
        "themes.Theme", verbose_name="Thème", on_delete=models.CASCADE,
        related_name="demandes_encadrement")

    statut = models.CharField(
        "Statut", max_length=15, choices=StatutDemande.choices,
        default=StatutDemande.EN_ATTENTE)

    message = models.TextField(
        "Message à l'encadreur", blank=True,
        help_text="Facultatif : quelques lignes sur votre motivation.")

    date_demande = models.DateTimeField("Date de la demande", default=timezone.now)
    date_decision = models.DateTimeField("Date de la réponse", null=True, blank=True)
    motif_refus = models.TextField("Motif du refus", blank=True)

    class Meta:
        verbose_name = "Demande d'encadrement"
        verbose_name_plural = "Demandes d'encadrement"
        ordering = ["-date_demande"]
        constraints = [
            # Un étudiant ne sollicite qu'un encadreur à la fois : sans cette
            # contrainte, il pourrait démarcher tout le corps enseignant et
            # se retrouver avec deux acceptations contradictoires.
            models.UniqueConstraint(
                fields=["etudiant"], condition=models.Q(statut="EN_ATTENTE"),
                name="ux_demande_en_attente_par_etudiant"),
            # Et il n'a au plus qu'un encadreur accepté.
            models.UniqueConstraint(
                fields=["etudiant"], condition=models.Q(statut="ACCEPTE"),
                name="ux_encadreur_accepte_par_etudiant"),
            # Inutile de solliciter deux fois le même professeur sur le même
            # thème tant que la première demande n'a pas été tranchée.
            models.UniqueConstraint(
                fields=["etudiant", "encadreur", "theme"],
                condition=models.Q(statut="EN_ATTENTE"),
                name="ux_demande_unique_par_couple"),
        ]

    def __str__(self):
        return f"{self.etudiant} → {self.encadreur} ({self.get_statut_display()})"

    @property
    def est_en_attente(self):
        return self.statut == StatutDemande.EN_ATTENTE

    @property
    def est_acceptee(self):
        return self.statut == StatutDemande.ACCEPTE

    @property
    def est_refusee(self):
        return self.statut == StatutDemande.REFUSE

    @property
    def couleur_statut(self):
        return {StatutDemande.EN_ATTENTE: "ambre",
                StatutDemande.ACCEPTE: "vert",
                StatutDemande.REFUSE: "rouge"}.get(self.statut, "gris")

    # -- Décision (rendue par l'encadreur, module à venir) -----------------
    def accepter(self):
        self.statut = StatutDemande.ACCEPTE
        self.date_decision = timezone.now()
        self.motif_refus = ""
        self.save()

    def refuser(self, motif=""):
        self.statut = StatutDemande.REFUSE
        self.date_decision = timezone.now()
        self.motif_refus = motif
        self.save()
