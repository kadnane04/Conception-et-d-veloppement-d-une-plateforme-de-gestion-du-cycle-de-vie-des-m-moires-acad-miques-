"""Tests du module « supervision » — phase ultérieure."""
