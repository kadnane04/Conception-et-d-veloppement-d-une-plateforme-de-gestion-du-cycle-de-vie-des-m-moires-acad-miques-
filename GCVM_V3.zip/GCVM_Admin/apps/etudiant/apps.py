from django.apps import AppConfig


class EtudiantConfig(AppConfig):
    """Espace Étudiant : tableau de bord et documents mis à disposition."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.etudiant"
    verbose_name = "Espace Étudiant"
