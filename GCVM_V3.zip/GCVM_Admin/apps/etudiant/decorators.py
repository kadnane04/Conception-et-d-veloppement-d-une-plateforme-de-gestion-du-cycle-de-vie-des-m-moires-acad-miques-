"""
Garde d'accès à l'espace Étudiant.

Conservé pour ne pas modifier les modules qui l'importent déjà ; la règle
elle-même vit désormais dans `apps.accounts.gardes`, avec celles des autres
espaces. Une seule implémentation, un seul endroit à corriger.
"""

from apps.accounts.gardes import etudiant_requis  # noqa: F401
