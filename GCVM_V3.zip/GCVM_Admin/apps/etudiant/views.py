"""
Espace Étudiant : tableau de bord et documents mis à disposition.

Le tableau de bord est la vue d'ensemble du parcours : où en est le thème, où
en est l'encadreur, où en est le mémoire. Il assemble les trois modules sans
en porter aucun.
"""

import os

from django.contrib.auth.decorators import login_required
from django.http import FileResponse, Http404
from django.shortcuts import render
from django.db.models import F

from apps.administration.models import DocumentInstitutionnel
from apps.memories.models import StatutMemoire
from apps.notifications.models import Notification
from apps.supervision.models import StatutDemande
from apps.themes.models import StatutTheme

from .decorators import etudiant_requis


@etudiant_requis
def tableau_de_bord(requete):
    etudiant = requete.user

    # -- Thème : celui en attente, sinon le validé, sinon le dernier en date --
    theme = (etudiant.themes.filter(statut=StatutTheme.EN_ATTENTE).first()
             or etudiant.themes.filter(statut=StatutTheme.VALIDE).first()
             or etudiant.themes.order_by("-date_soumission").first())

    # -- Encadreur ---------------------------------------------------------
    demande = (etudiant.demandes_encadrement
               .select_related("encadreur", "encadreur__profilprofesseur")
               .order_by("-date_demande").first())

    # -- Mémoire -----------------------------------------------------------
    memoire = (etudiant.memoires
               .select_related("theme", "encadreur", "annee_academique")
               .order_by("-date_creation").first())

    # Les trois étapes du parcours, avec leur état. C'est ce qui donne à
    # l'étudiant, en un coup d'œil, la prochaine chose à faire.
    etapes = [
        {
            "numero": 1, "titre": "Choix du thème",
            "faite": theme is not None and theme.statut == StatutTheme.VALIDE,
            "en_cours": theme is not None and theme.statut == StatutTheme.EN_ATTENTE,
            "echec": theme is not None and theme.statut == StatutTheme.REJETE,
            "action": "themes:proposer" if theme is None else "themes:mes_themes",
            "libelle_action": "Proposer un thème" if theme is None else "Voir mes thèmes",
        },
        {
            "numero": 2, "titre": "Choix de l'encadreur",
            "faite": demande is not None and demande.statut == StatutDemande.ACCEPTE,
            "en_cours": demande is not None and demande.statut == StatutDemande.EN_ATTENTE,
            "echec": demande is not None and demande.statut == StatutDemande.REFUSE,
            "action": "supervision:liste" if demande is None else "supervision:mes_demandes",
            "libelle_action": "Choisir un encadreur" if demande is None else "Voir mes demandes",
        },
        {
            "numero": 3, "titre": "Dépôt du mémoire",
            "faite": memoire is not None and memoire.statut == StatutMemoire.VALIDE_RESP_ACADEMIQUE,
            "en_cours": memoire is not None and memoire.statut in {
                StatutMemoire.DEPOSE, StatutMemoire.VALIDE_ENCADREUR},
            "echec": memoire is not None and memoire.statut in {
                StatutMemoire.REJETE_ENCADREUR, StatutMemoire.REJETE_RESP_ACADEMIQUE},
            "action": "memoires:mon_memoire",
            "libelle_action": "Déposer mon mémoire" if memoire is None else "Voir mon mémoire",
        },
    ]

    return render(requete, "etudiant/tableau_de_bord.html", {
        "rubrique": "tdb",
        "profil": etudiant.profil,
        "theme": theme,
        "demande": demande,
        "memoire": memoire,
        "etapes": etapes,
        "progression": round(sum(1 for e in etapes if e["faite"]) * 100 / len(etapes)),
        "guide": DocumentInstitutionnel.guide_en_vigueur(),
        "notifications": Notification.objects.pour(etudiant)[:5],
        "nb_versions": memoire.nb_versions if memoire else 0,
    })


@login_required
def telecharger_document(requete, pk):
    """
    Téléchargement d'un document institutionnel.

    Réservé aux utilisateurs connectés : le guide n'est pas un document public.
    Le compteur sert à l'administration pour savoir s'il est réellement lu.
    """
    try:
        document = DocumentInstitutionnel.objects.get(pk=pk, est_publie=True)
    except DocumentInstitutionnel.DoesNotExist:
        raise Http404("Document introuvable ou retiré.")

    if not document.fichier or not document.fichier.storage.exists(document.fichier.name):
        raise Http404("Le fichier de ce document est introuvable.")

    DocumentInstitutionnel.objects.filter(pk=document.pk).update(
        nb_telechargements=F("nb_telechargements") + 1)

    return FileResponse(
        document.fichier.open("rb"), as_attachment=True,
        filename=document.nom_original or os.path.basename(document.fichier.name))
