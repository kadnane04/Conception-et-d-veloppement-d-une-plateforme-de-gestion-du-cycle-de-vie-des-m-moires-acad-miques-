"""Routes de l'espace Étudiant."""

from django.urls import path

from . import views

app_name = "etudiant"

urlpatterns = [
    path("", views.tableau_de_bord, name="tableau_de_bord"),
    path("document/<int:pk>/", views.telecharger_document, name="telecharger_document"),
]
