"""
Tests du module Étudiant.

Ils portent sur les règles du cahier des charges : l'enchaînement des étapes,
la détection des doublons, l'unicité des demandes, le versionnage des dépôts,
et le cloisonnement entre étudiants.
"""

from datetime import date
from io import BytesIO

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import (
    Filiere, Grade, ProfilEtudiant, ProfilProfesseur, Role, StatutProfesseur, Utilisateur,
)
from apps.administration.models import DocumentInstitutionnel
from apps.memories.models import AnneeAcademique, Memoire, StatutMemoire, VersionMemoire
from apps.notifications.models import Notification
from apps.supervision.models import DemandeEncadrement, StatutDemande
from apps.themes.models import (
    CategorieTheme, StatutTheme, Theme, normaliser_titre, score_similarite,
)

MDP = "Plateforme@2026"


def pdf(nom="memoire.pdf", taille=2048):
    """Un faux PDF minimal, suffisant pour les contrôles de format."""
    contenu = b"%PDF-1.4\n" + b"0" * max(taille - 9, 0)
    return SimpleUploadedFile(nom, contenu, content_type="application/pdf")


class BaseEtudiantTest(TestCase):

    def setUp(self):
        self.etudiant = Utilisateur.objects.create_user(
            email="ama.kossi@lbs.com", password=MDP, nom="KOSSI", prenom="Ama",
            date_naissance=date(2002, 4, 11), role=Role.ETUDIANT)
        ProfilEtudiant.objects.create(
            utilisateur=self.etudiant, filiere=Filiere.MANAGEMENT, matricule="LBS-001")

        self.encadreur = Utilisateur.objects.create_user(
            email="yao.mensah@lbs.com", password=MDP, nom="MENSAH", prenom="Yao",
            role=Role.PROFESSEUR)
        ProfilProfesseur.objects.create(
            utilisateur=self.encadreur, grade=Grade.MAITRE_CONFERENCES,
            specialite="Systèmes d'information", statut=StatutProfesseur.ENCADREUR_JURY,
            quota_encadrement=3, email_professionnel="y.mensah@lbs.com",
            domaines_recherche="Gouvernance du SI, ERP")

        self.jure_seul = Utilisateur.objects.create_user(
            email="sena.afi@lbs.com", password=MDP, nom="AFI", prenom="Sena",
            role=Role.PROFESSEUR)
        ProfilProfesseur.objects.create(
            utilisateur=self.jure_seul, grade=Grade.DOCTEUR,
            specialite="Contrôle de gestion", statut=StatutProfesseur.JURY)

        self.annee = AnneeAcademique.objects.create(libelle="2025-2026", est_active=True)
        self.categorie = CategorieTheme.objects.get(nom="Gestion")
        self.client.force_login(self.etudiant)

    # -- fabriques ---------------------------------------------------------
    def creer_theme(self, titre="Contribution du digital à la performance des PME togolaises",
                    statut=StatutTheme.EN_ATTENTE, etudiant=None, archive=False):
        theme = Theme.objects.create(
            etudiant=etudiant or self.etudiant, titre=titre,
            description="Description du sujet.", contexte="Contexte du sujet.",
            problematique="Quelle est la question ?", objectifs="Objectif général.",
            mots_cles="digital, PME", statut=statut, est_archive=archive)
        theme.categories.add(self.categorie)
        return theme

    def soumettre_theme(self, titre, confirmer=False):
        donnees = {
            "titre": titre, "description": "Une description suffisamment longue.",
            "contexte": "Le contexte de l'étude.",
            "problematique": "La question posée.", "objectifs": "Les objectifs visés.",
            "mots_cles": "digital, PME", "categories": [self.categorie.pk],
        }
        if confirmer:
            donnees["confirme_doublon"] = "1"
        return self.client.post(reverse("themes:proposer"), donnees, follow=True)


# ==========================================================================
# Détection des doublons
# ==========================================================================
class DetectionDoublonsTest(BaseEtudiantTest):

    def test_normalisation_du_titre(self):
        self.assertEqual(
            normaliser_titre("L'Impact du Digital sur la Performance !"),
            normaliser_titre("impact digital performance"))

    def test_titres_identiques_a_la_casse_pres(self):
        score = score_similarite(
            "La Gouvernance des PME au Togo", "la gouvernance des pme au togo")
        self.assertGreater(score, 0.95)

    def test_titres_sans_rapport(self):
        score = score_similarite(
            "Gouvernance des PME au Togo",
            "Optimisation des réseaux de capteurs sans fil")
        self.assertLess(score, 0.4)

    def test_seuls_les_themes_valides_ou_archives_comptent(self):
        titre = "La digitalisation des processus comptables au Togo"
        self.creer_theme(titre=titre, statut=StatutTheme.REJETE,
                         etudiant=self.autre_etudiant())
        self.assertEqual(Theme.similaires(titre), [],
                         "Un thème rejeté ne doit pas bloquer une nouvelle proposition.")

    def test_un_theme_valide_est_detecte(self):
        titre = "La digitalisation des processus comptables au Togo"
        self.creer_theme(titre=titre, statut=StatutTheme.VALIDE,
                         etudiant=self.autre_etudiant())
        self.assertTrue(Theme.similaires(titre))

    def test_un_theme_archive_est_detecte(self):
        titre = "La digitalisation des processus comptables au Togo"
        self.creer_theme(titre=titre, statut=StatutTheme.REJETE, archive=True,
                         etudiant=self.autre_etudiant())
        self.assertTrue(Theme.similaires(titre))

    def test_avertissement_affiche_et_rien_enregistre(self):
        self.creer_theme(titre="La digitalisation des processus comptables au Togo",
                         statut=StatutTheme.VALIDE, etudiant=self.autre_etudiant())
        reponse = self.soumettre_theme("La digitalisation des processus comptables au Togo")
        self.assertContains(reponse, "Un thème similaire existe déjà dans la base de données.")
        self.assertEqual(Theme.objects.filter(etudiant=self.etudiant).count(), 0)

    def test_confirmation_enregistre_et_trace_l_avertissement(self):
        self.creer_theme(titre="La digitalisation des processus comptables au Togo",
                         statut=StatutTheme.VALIDE, etudiant=self.autre_etudiant())
        self.soumettre_theme("La digitalisation des processus comptables au Togo",
                             confirmer=True)
        theme = Theme.objects.get(etudiant=self.etudiant)
        self.assertTrue(theme.doublon_signale)
        self.assertIn("%", theme.doublon_detail)

    def test_theme_different_passe_sans_avertissement(self):
        self.creer_theme(titre="La digitalisation des processus comptables au Togo",
                         statut=StatutTheme.VALIDE, etudiant=self.autre_etudiant())
        reponse = self.soumettre_theme(
            "Optimisation de la chaîne logistique portuaire de Lomé")
        self.assertNotContains(reponse, "Un thème similaire existe déjà")
        self.assertEqual(Theme.objects.filter(etudiant=self.etudiant).count(), 1)

    def autre_etudiant(self):
        if not hasattr(self, "_autre"):
            self._autre = Utilisateur.objects.create_user(
                email="autre@lbs.com", password=MDP, nom="AUTRE", prenom="Kofi",
                role=Role.ETUDIANT)
            ProfilEtudiant.objects.create(
                utilisateur=self._autre, filiere=Filiere.MANAGEMENT)
        return self._autre


# ==========================================================================
# Soumission et historique des thèmes
# ==========================================================================
class SoumissionThemeTest(BaseEtudiantTest):

    def test_formulaire_accessible(self):
        reponse = self.client.get(reverse("themes:proposer"))
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "Proposer un thème")

    def test_soumission_cree_un_theme_en_attente(self):
        self.soumettre_theme("Contribution du digital à la performance des PME togolaises")
        theme = Theme.objects.get(etudiant=self.etudiant)
        self.assertEqual(theme.statut, StatutTheme.EN_ATTENTE)
        self.assertIn(self.categorie, theme.categories.all())

    def test_soumission_notifie_l_etudiant(self):
        self.soumettre_theme("Contribution du digital à la performance des PME togolaises")
        self.assertTrue(Notification.objects.pour(self.etudiant).exists())

    def test_titre_trop_court_refuse(self):
        self.soumettre_theme("Le digital")
        self.assertEqual(Theme.objects.count(), 0)

    def test_categorie_obligatoire(self):
        self.client.post(reverse("themes:proposer"), {
            "titre": "Un titre suffisamment long pour être accepté",
            "description": "Description.", "contexte": "Contexte.",
            "problematique": "Question ?", "objectifs": "Objectifs.",
            "mots_cles": "a, b"})
        self.assertEqual(Theme.objects.count(), 0)

    def test_une_seule_proposition_a_la_fois(self):
        self.creer_theme(statut=StatutTheme.EN_ATTENTE)
        reponse = self.client.get(reverse("themes:proposer"))
        self.assertContains(reponse, "en attente de décision")
        self.soumettre_theme("Un tout autre sujet parfaitement distinct du premier")
        self.assertEqual(Theme.objects.filter(etudiant=self.etudiant).count(), 1)

    def test_nouvelle_proposition_possible_apres_rejet(self):
        self.creer_theme(statut=StatutTheme.REJETE)
        self.assertEqual(self.client.get(reverse("themes:proposer")).status_code, 200)
        self.soumettre_theme("Un tout autre sujet parfaitement distinct du premier")
        self.assertEqual(Theme.objects.filter(etudiant=self.etudiant).count(), 2)

    def test_theme_non_modifiable_une_fois_soumis(self):
        theme = self.creer_theme()
        self.assertFalse(theme.modifiable)

    def test_historique(self):
        self.creer_theme(statut=StatutTheme.REJETE, titre="Premier sujet proposé puis rejeté")
        reponse = self.client.get(reverse("themes:mes_themes"))
        self.assertEqual(reponse.status_code, 200)
        self.assertEqual(reponse.context["rejetes"], 1)

    def test_un_etudiant_ne_voit_pas_le_theme_d_un_autre(self):
        autre = Utilisateur.objects.create_user(
            email="autre2@lbs.com", password=MDP, nom="X", prenom="Y", role=Role.ETUDIANT)
        theme = self.creer_theme(etudiant=autre, titre="Sujet appartenant à quelqu'un d'autre")
        self.assertEqual(
            self.client.get(reverse("themes:detail", args=[theme.pk])).status_code, 404)


# ==========================================================================
# Choix de l'encadreur
# ==========================================================================
class ChoixEncadreurTest(BaseEtudiantTest):

    def test_etape_verrouillee_sans_theme_valide(self):
        reponse = self.client.get(reverse("supervision:liste"))
        self.assertContains(reponse, "faire valider un thème")

    def test_liste_ouverte_avec_theme_valide(self):
        self.creer_theme(statut=StatutTheme.VALIDE)
        reponse = self.client.get(reverse("supervision:liste"))
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "MENSAH")

    def test_un_professeur_jury_seul_n_apparait_pas(self):
        self.creer_theme(statut=StatutTheme.VALIDE)
        reponse = self.client.get(reverse("supervision:liste"))
        self.assertNotContains(reponse, "sena.afi@lbs.com")

    def test_fiche_encadreur(self):
        self.creer_theme(statut=StatutTheme.VALIDE)
        reponse = self.client.get(reverse("supervision:detail", args=[self.encadreur.pk]))
        self.assertContains(reponse, "y.mensah@lbs.com")
        self.assertContains(reponse, "Gouvernance du SI")

    def test_demande_creee(self):
        theme = self.creer_theme(statut=StatutTheme.VALIDE)
        self.client.post(reverse("supervision:choisir", args=[self.encadreur.pk]),
                         {"message": "Bonjour."}, follow=True)
        demande = DemandeEncadrement.objects.get(etudiant=self.etudiant)
        self.assertEqual(demande.statut, StatutDemande.EN_ATTENTE)
        self.assertEqual(demande.theme, theme)

    def test_les_deux_parties_sont_notifiees(self):
        self.creer_theme(statut=StatutTheme.VALIDE)
        self.client.post(reverse("supervision:choisir", args=[self.encadreur.pk]), follow=True)
        self.assertTrue(Notification.objects.pour(self.etudiant).exists())
        self.assertTrue(Notification.objects.pour(self.encadreur).exists())

    def test_une_seule_demande_en_attente(self):
        self.creer_theme(statut=StatutTheme.VALIDE)
        self.client.post(reverse("supervision:choisir", args=[self.encadreur.pk]), follow=True)
        autre_encadreur = Utilisateur.objects.create_user(
            email="komi.bawa@lbs.com", password=MDP, nom="BAWA", prenom="Komi",
            role=Role.PROFESSEUR)
        ProfilProfesseur.objects.create(
            utilisateur=autre_encadreur, grade=Grade.DOCTEUR, specialite="Stratégie",
            statut=StatutProfesseur.ENCADREUR)
        self.client.post(reverse("supervision:choisir", args=[autre_encadreur.pk]), follow=True)
        self.assertEqual(DemandeEncadrement.objects.filter(etudiant=self.etudiant).count(), 1)

    def test_demande_impossible_sans_theme_valide(self):
        self.creer_theme(statut=StatutTheme.EN_ATTENTE)
        self.client.post(reverse("supervision:choisir", args=[self.encadreur.pk]), follow=True)
        self.assertEqual(DemandeEncadrement.objects.count(), 0)

    def test_demande_ignoree_en_get(self):
        self.creer_theme(statut=StatutTheme.VALIDE)
        self.client.get(reverse("supervision:choisir", args=[self.encadreur.pk]))
        self.assertEqual(DemandeEncadrement.objects.count(), 0)

    def test_professeur_jury_seul_ne_peut_pas_etre_choisi(self):
        self.creer_theme(statut=StatutTheme.VALIDE)
        self.client.post(reverse("supervision:choisir", args=[self.jure_seul.pk]), follow=True)
        self.assertEqual(DemandeEncadrement.objects.count(), 0)

    def test_compteur_d_encadrements_en_cours(self):
        theme = self.creer_theme(statut=StatutTheme.VALIDE)
        demande = DemandeEncadrement.objects.create(
            etudiant=self.etudiant, encadreur=self.encadreur, theme=theme)
        profil = self.encadreur.profil
        self.assertEqual(profil.nb_encadrements_en_cours, 0)
        demande.accepter()
        self.assertEqual(profil.nb_encadrements_en_cours, 1)
        self.assertEqual(profil.places_restantes, 2)

    def test_historique_des_demandes(self):
        theme = self.creer_theme(statut=StatutTheme.VALIDE)
        DemandeEncadrement.objects.create(
            etudiant=self.etudiant, encadreur=self.encadreur, theme=theme,
            statut=StatutDemande.REFUSE, motif_refus="Quota atteint.")
        reponse = self.client.get(reverse("supervision:mes_demandes"))
        self.assertContains(reponse, "Quota atteint.")


# ==========================================================================
# Dépôt du mémoire
# ==========================================================================
class DepotMemoireTest(BaseEtudiantTest):

    def parcours_complet(self):
        theme = self.creer_theme(statut=StatutTheme.VALIDE)
        demande = DemandeEncadrement.objects.create(
            etudiant=self.etudiant, encadreur=self.encadreur, theme=theme)
        demande.accepter()
        return theme, demande

    def donnees_depot(self, **extra):
        donnees = {
            "annee_academique": self.annee.pk,
            "titre": "Contribution du digital à la performance des PME",
            "resume": "R" * 150,
            "fichier": pdf(),
        }
        donnees.update(extra)
        return donnees

    def test_verrouille_sans_theme(self):
        reponse = self.client.get(reverse("memoires:mon_memoire"))
        self.assertContains(reponse, "Votre thème doit d")

    def test_verrouille_sans_encadreur(self):
        self.creer_theme(statut=StatutTheme.VALIDE)
        reponse = self.client.get(reverse("memoires:mon_memoire"))
        self.assertContains(reponse, "Un encadreur doit d")

    def test_formulaire_accessible_apres_acceptation(self):
        self.parcours_complet()
        reponse = self.client.get(reverse("memoires:mon_memoire"), follow=True)
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "Déposer mon mémoire")

    def test_depot_cree_memoire_et_version_1(self):
        self.parcours_complet()
        self.client.post(reverse("memoires:deposer"), self.donnees_depot(), follow=True)
        memoire = Memoire.objects.get(etudiant=self.etudiant)
        self.assertEqual(memoire.statut, StatutMemoire.DEPOSE)
        self.assertEqual(memoire.encadreur, self.encadreur)
        self.assertEqual(memoire.nb_versions, 1)
        self.assertEqual(memoire.derniere_version.numero, 1)

    def test_format_non_pdf_refuse(self):
        self.parcours_complet()
        mauvais = SimpleUploadedFile("memoire.exe", b"MZ" + b"0" * 100,
                                     content_type="application/octet-stream")
        self.client.post(reverse("memoires:deposer"),
                         self.donnees_depot(fichier=mauvais), follow=True)
        self.assertEqual(Memoire.objects.count(), 0)

    def test_fichier_trop_volumineux_refuse(self):
        self.parcours_complet()
        from django.test import override_settings
        from django.conf import settings
        reglages = dict(settings.GCVM, TAILLE_MAX_DEPOT_MO=0)
        with override_settings(GCVM=reglages):
            self.client.post(reverse("memoires:deposer"),
                             self.donnees_depot(), follow=True)
        self.assertEqual(Memoire.objects.count(), 0)

    def test_resume_trop_court_refuse(self):
        self.parcours_complet()
        self.client.post(reverse("memoires:deposer"),
                         self.donnees_depot(resume="Trop court."), follow=True)
        self.assertEqual(Memoire.objects.count(), 0)

    def test_nouvelle_version_n_ecrase_pas_la_precedente(self):
        self.parcours_complet()
        self.client.post(reverse("memoires:deposer"), self.donnees_depot(), follow=True)
        self.client.post(reverse("memoires:nouvelle_version"),
                         {"fichier": pdf("memoire_v2.pdf"),
                          "commentaire": "Corrections du chapitre 2."}, follow=True)
        memoire = Memoire.objects.get(etudiant=self.etudiant)
        self.assertEqual(memoire.nb_versions, 2)
        self.assertEqual([v.numero for v in memoire.versions.all()], [2, 1])
        self.assertEqual(memoire.derniere_version.commentaire, "Corrections du chapitre 2.")

    def test_redepot_impossible_apres_validation_academique(self):
        self.parcours_complet()
        self.client.post(reverse("memoires:deposer"), self.donnees_depot(), follow=True)
        memoire = Memoire.objects.get(etudiant=self.etudiant)
        memoire.statut = StatutMemoire.VALIDE_RESP_ACADEMIQUE
        memoire.save()
        self.client.post(reverse("memoires:nouvelle_version"),
                         {"fichier": pdf("v3.pdf")}, follow=True)
        self.assertEqual(Memoire.objects.get(pk=memoire.pk).nb_versions, 1)

    def test_telechargement_de_sa_propre_version(self):
        self.parcours_complet()
        self.client.post(reverse("memoires:deposer"), self.donnees_depot(), follow=True)
        version = VersionMemoire.objects.get()
        reponse = self.client.get(
            reverse("memoires:telecharger_version", args=[version.pk]))
        self.assertEqual(reponse.status_code, 200)

    def test_un_etudiant_ne_telecharge_pas_le_memoire_d_un_autre(self):
        self.parcours_complet()
        self.client.post(reverse("memoires:deposer"), self.donnees_depot(), follow=True)
        version = VersionMemoire.objects.get()

        intrus = Utilisateur.objects.create_user(
            email="intrus@lbs.com", password=MDP, nom="I", prenom="N", role=Role.ETUDIANT)
        ProfilEtudiant.objects.create(utilisateur=intrus, filiere=Filiere.MANAGEMENT)
        self.client.force_login(intrus)
        self.assertEqual(self.client.get(
            reverse("memoires:telecharger_version", args=[version.pk])).status_code, 404)

    def tearDown(self):
        for version in VersionMemoire.objects.all():
            version.fichier.delete(save=False)


# ==========================================================================
# Tableau de bord, notifications, profil
# ==========================================================================
class TableauDeBordEtudiantTest(BaseEtudiantTest):

    def test_redirection_apres_connexion(self):
        self.client.logout()
        reponse = self.client.post(reverse("comptes:connexion"), {
            "email": "ama.kossi@lbs.com", "mot_de_passe": MDP}, follow=True)
        self.assertEqual(reponse.status_code, 200)
        self.assertTrue(reponse.redirect_chain[-1][0].startswith("/etudiant/"))

    def test_affichage_sans_rien_de_commence(self):
        reponse = self.client.get(reverse("etudiant:tableau_de_bord"))
        self.assertEqual(reponse.status_code, 200)
        self.assertEqual(reponse.context["progression"], 0)

    def test_progression_avec_theme_valide(self):
        self.creer_theme(statut=StatutTheme.VALIDE)
        reponse = self.client.get(reverse("etudiant:tableau_de_bord"))
        self.assertEqual(reponse.context["etapes"][0]["faite"], True)
        self.assertEqual(reponse.context["progression"], 33)

    def test_administrateur_n_entre_pas_dans_l_espace_etudiant(self):
        admin = Utilisateur.objects.create_user(
            email="admin.test@lbs.com", password=MDP, nom="A", prenom="B",
            role=Role.ADMINISTRATEUR, is_staff=True, is_superuser=True)
        self.client.force_login(admin)
        reponse = self.client.get(reverse("etudiant:tableau_de_bord"), follow=True)
        self.assertTrue(reponse.redirect_chain[-1][0].startswith("/administration/"))

    def test_anonyme_redirige(self):
        self.client.logout()
        reponse = self.client.get(reverse("etudiant:tableau_de_bord"))
        self.assertEqual(reponse.status_code, 302)
        self.assertIn("connexion", reponse.url)

    def test_guide_absent_puis_present(self):
        reponse = self.client.get(reverse("etudiant:tableau_de_bord"))
        self.assertIsNone(reponse.context["guide"])

        document = DocumentInstitutionnel.objects.create(
            titre="Guide de rédaction 2026",
            categorie=DocumentInstitutionnel.Categorie.GUIDE_REDACTION,
            fichier=SimpleUploadedFile("guide.pdf", b"%PDF-1.4 guide"),
            taille_octets=14, nom_original="guide.pdf")
        reponse = self.client.get(reverse("etudiant:tableau_de_bord"))
        self.assertEqual(reponse.context["guide"], document)
        self.assertContains(reponse, "Télécharger le guide de rédaction")

        reponse = self.client.get(
            reverse("etudiant:telecharger_document", args=[document.pk]))
        self.assertEqual(reponse.status_code, 200)
        document.refresh_from_db()
        self.assertEqual(document.nb_telechargements, 1)
        document.fichier.delete(save=False)

    def test_guide_non_publie_inaccessible(self):
        document = DocumentInstitutionnel.objects.create(
            titre="Brouillon", est_publie=False,
            fichier=SimpleUploadedFile("brouillon.pdf", b"%PDF-1.4"))
        self.assertEqual(self.client.get(
            reverse("etudiant:telecharger_document", args=[document.pk])).status_code, 404)
        document.fichier.delete(save=False)


class NotificationsTest(BaseEtudiantTest):

    def test_page_accessible(self):
        self.assertEqual(self.client.get(reverse("notifications:liste")).status_code, 200)

    def test_compteur_de_non_lues(self):
        Notification.envoyer(self.etudiant, "THEME_VALIDE", "Votre thème a été validé",
                             "Bonne nouvelle.")
        self.assertEqual(Notification.compteur(self.etudiant), 1)
        reponse = self.client.get(reverse("etudiant:tableau_de_bord"))
        self.assertEqual(reponse.context["nb_notifications"], 1)

    def test_ouvrir_marque_comme_lue(self):
        notification = Notification.envoyer(
            self.etudiant, "THEME_VALIDE", "Votre thème a été validé", "Bonne nouvelle.")
        self.client.get(reverse("notifications:ouvrir", args=[notification.pk]))
        notification.refresh_from_db()
        self.assertTrue(notification.est_lue)
        self.assertIsNotNone(notification.date_lecture)

    def test_tout_marquer_lu(self):
        for i in range(3):
            Notification.envoyer(self.etudiant, "INFORMATION", f"Message {i}", "…")
        self.client.post(reverse("notifications:tout_marquer_lu"))
        self.assertEqual(Notification.compteur(self.etudiant), 0)

    def test_un_etudiant_ne_lit_pas_les_notifications_d_un_autre(self):
        notification = Notification.envoyer(
            self.encadreur, "INFORMATION", "Pour l'encadreur", "…")
        self.assertEqual(self.client.get(
            reverse("notifications:ouvrir", args=[notification.pk])).status_code, 404)

    def test_filtre_lues_non_lues(self):
        lue = Notification.envoyer(self.etudiant, "INFORMATION", "Déjà lue", "…")
        lue.marquer_lue()
        Notification.envoyer(self.etudiant, "INFORMATION", "Pas encore lue", "…")
        reponse = self.client.get(reverse("notifications:liste") + "?etat=non-lues")
        # Le filtre porte sur le tableau ; la cloche de la barre supérieure
        # continue d'afficher les dernières notifications, lues comprises.
        titres = [n.titre for n in reponse.context["page"].object_list]
        self.assertEqual(titres, ["Pas encore lue"])


class ProfilEtudiantTest(BaseEtudiantTest):

    def test_profil_affiche_filiere_et_date_de_naissance(self):
        reponse = self.client.get(reverse("comptes:mon_profil"))
        self.assertContains(reponse, "Management")
        self.assertContains(reponse, "11/04/2002")

    def test_mise_a_jour_des_informations(self):
        self.client.post(reverse("comptes:mon_profil"), {
            "nom": "KOSSI", "prenom": "Ama Rose",
            "date_naissance": "2002-04-11", "telephone": "90112233"})
        self.etudiant.refresh_from_db()
        self.assertEqual(self.etudiant.prenom, "Ama Rose")

    def test_changement_de_mot_de_passe(self):
        self.client.post(reverse("comptes:changer_mot_de_passe"), {
            "mot_de_passe_actuel": MDP,
            "nouveau": "NouveauMdp@2026", "confirmation": "NouveauMdp@2026"})
        self.etudiant.refresh_from_db()
        self.assertTrue(self.etudiant.check_password("NouveauMdp@2026"))

    def test_l_etudiant_ne_change_pas_sa_filiere(self):
        formulaire_champs = self.client.get(
            reverse("comptes:mon_profil")).context["formulaire"].fields
        self.assertNotIn("filiere", formulaire_champs)
        self.assertNotIn("email", formulaire_champs)


# ==========================================================================
# Référentiels côté administrateur
# ==========================================================================
class ReferentielsAdminTest(TestCase):

    def setUp(self):
        self.admin = Utilisateur.objects.create_user(
            email="admin.test@lbs.com", password=MDP, nom="A", prenom="B",
            role=Role.ADMINISTRATEUR, is_staff=True, is_superuser=True)
        self.client.force_login(self.admin)

    def test_categories_livrees_avec_la_plateforme(self):
        self.assertGreaterEqual(CategorieTheme.objects.count(), 10)
        for nom in ["Data Science", "Cybersécurité", "Finance"]:
            self.assertTrue(CategorieTheme.objects.filter(nom=nom).exists(), nom)

    def test_creation_de_categorie(self):
        self.client.post(reverse("administration:categories"), {
            "nom": "Logistique", "description": "Chaîne d'approvisionnement.",
            "ordre": 110, "est_active": "on"}, follow=True)
        self.assertTrue(CategorieTheme.objects.filter(nom="Logistique").exists())

    def test_categorie_en_double_refusee(self):
        self.client.post(reverse("administration:categories"), {
            "nom": "finance", "ordre": 10, "est_active": "on"}, follow=True)
        self.assertEqual(CategorieTheme.objects.filter(nom__iexact="finance").count(), 1)

    def test_categorie_utilisee_est_desactivee_et_non_supprimee(self):
        categorie = CategorieTheme.objects.get(nom="Gestion")
        etudiant = Utilisateur.objects.create_user(
            email="e@lbs.com", password=MDP, nom="E", prenom="F", role=Role.ETUDIANT)
        theme = Theme.objects.create(
            etudiant=etudiant, titre="Un sujet rattaché à cette catégorie",
            description="d", contexte="c", problematique="p", objectifs="o",
            mots_cles="m")
        theme.categories.add(categorie)

        self.client.post(
            reverse("administration:supprimer_categorie", args=[categorie.pk]), follow=True)
        categorie.refresh_from_db()
        self.assertFalse(categorie.est_active)

    def test_annee_academique_unique_active(self):
        self.client.post(reverse("administration:annees"), {
            "libelle": "2025-2026", "est_active": "on"}, follow=True)
        self.client.post(reverse("administration:annees"), {
            "libelle": "2026-2027", "est_active": "on"}, follow=True)
        self.assertEqual(AnneeAcademique.objects.filter(est_active=True).count(), 1)
        self.assertEqual(AnneeAcademique.active().libelle, "2026-2027")

    def test_depot_du_guide(self):
        self.client.post(reverse("administration:documents"), {
            "titre": "Guide de rédaction 2026",
            "categorie": DocumentInstitutionnel.Categorie.GUIDE_REDACTION,
            "fichier": SimpleUploadedFile("guide.pdf", b"%PDF-1.4 contenu"),
            "est_publie": "on"}, follow=True)
        guide = DocumentInstitutionnel.guide_en_vigueur()
        self.assertIsNotNone(guide)
        self.assertEqual(guide.depose_par, self.admin)
        guide.fichier.delete(save=False)

    def test_un_etudiant_n_accede_pas_aux_referentiels(self):
        etudiant = Utilisateur.objects.create_user(
            email="etu@lbs.com", password=MDP, nom="E", prenom="F", role=Role.ETUDIANT)
        ProfilEtudiant.objects.create(utilisateur=etudiant, filiere=Filiere.MANAGEMENT)
        self.client.force_login(etudiant)
        for nom in ["categories", "annees", "documents"]:
            reponse = self.client.get(reverse(f"administration:{nom}"), follow=True)
            self.assertTrue(reponse.redirect_chain[-1][0].startswith("/etudiant/"), nom)
