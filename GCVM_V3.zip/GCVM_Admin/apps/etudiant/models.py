"""
L'espace Étudiant n'a pas de modèle propre.

Il assemble ceux des autres modules : `themes.Theme`,
`supervision.DemandeEncadrement`, `memories.Memoire`,
`notifications.Notification`. Le fichier existe pour que Django reconnaisse
l'application.
"""
