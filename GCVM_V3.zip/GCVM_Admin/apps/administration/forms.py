"""
Formulaires des référentiels gérés par l'administration.

Les catégories de thèmes, les années académiques et le guide de rédaction sont
saisis ici, puis consommés par l'espace Étudiant. L'étudiant choisit dans ces
listes, il ne les alimente pas.
"""

import os

from django import forms
from django.core.exceptions import ValidationError

from apps.accounts.forms import styliser
from apps.memories.models import AnneeAcademique
from apps.themes.models import CategorieTheme

from .models import DocumentInstitutionnel


class CategorieThemeForm(forms.ModelForm):

    class Meta:
        model = CategorieTheme
        fields = ["nom", "description", "ordre", "est_active"]
        widgets = {
            "nom": forms.TextInput(attrs={"placeholder": "Cybersécurité"}),
            "description": forms.TextInput(attrs={
                "placeholder": "Facultatif : à quoi correspond ce domaine."}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        styliser(self)

    def clean_nom(self):
        nom = " ".join(self.cleaned_data["nom"].split())
        doublons = CategorieTheme.objects.filter(nom__iexact=nom)
        if self.instance.pk:
            doublons = doublons.exclude(pk=self.instance.pk)
        if doublons.exists():
            raise forms.ValidationError("Cette catégorie existe déjà.")
        return nom


class AnneeAcademiqueForm(forms.ModelForm):

    class Meta:
        model = AnneeAcademique
        fields = ["libelle", "date_debut", "date_fin", "est_active"]
        widgets = {
            "libelle": forms.TextInput(attrs={"placeholder": "2025-2026"}),
            "date_debut": forms.DateInput(attrs={"type": "date"}),
            "date_fin": forms.DateInput(attrs={"type": "date"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        styliser(self)

    def clean(self):
        donnees = super().clean()
        debut, fin = donnees.get("date_debut"), donnees.get("date_fin")
        if debut and fin and fin <= debut:
            self.add_error("date_fin", "La fin doit suivre le début.")
        return donnees

    def validate_constraints(self):
        """
        La contrainte « une seule année active » est laissée à save().

        Depuis Django 4.1, un ModelForm vérifie les contraintes du modèle
        avant l'enregistrement. Il refuserait donc une nouvelle année active
        au motif qu'une autre l'est déjà — alors que c'est précisément ce que
        save() s'apprête à corriger en basculant l'ancienne. La contrainte
        reste en base : elle protège les écritures qui ne passent pas par ce
        formulaire.
        """
        exclusions = set(self._get_validation_exclusions()) | {"est_active"}
        try:
            self.instance.validate_constraints(exclude=exclusions)
        except ValidationError as erreur:
            self._update_errors(erreur)

    def save(self, commit=True):
        annee = super().save(commit=False)
        if not commit:
            return annee
        if annee.est_active:
            # Une seule année peut être active : la contrainte de base de
            # données l'impose, on désactive donc l'ancienne avant
            # d'enregistrer. À la création, annee.pk vaut None — filtrer sur
            # est_active plutôt qu'exclure une clé inexistante.
            AnneeAcademique.objects.filter(est_active=True).update(est_active=False)
        annee.save()
        return annee


class DocumentInstitutionnelForm(forms.ModelForm):

    class Meta:
        model = DocumentInstitutionnel
        fields = ["titre", "description", "categorie", "fichier", "est_publie"]
        widgets = {
            "titre": forms.TextInput(attrs={
                "placeholder": "Guide de rédaction du mémoire — édition 2026"}),
            "description": forms.TextInput(attrs={
                "placeholder": "Facultatif : à qui s'adresse ce document."}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        styliser(self)

    def save(self, commit=True, depose_par=None):
        document = super().save(commit=False)
        fichier = self.cleaned_data.get("fichier")
        if fichier is not None and hasattr(fichier, "size"):
            document.taille_octets = fichier.size
            document.nom_original = os.path.basename(fichier.name)[:255]
        if depose_par is not None and depose_par.pk:
            document.depose_par = depose_par
        if commit:
            document.save()
        return document
