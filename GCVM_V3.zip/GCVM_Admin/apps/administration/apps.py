from django.apps import AppConfig


class AdministrationConfig(AppConfig):
    """Module Administrateur : tableau de bord et gestion des comptes."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.administration"
    verbose_name = "Module Administrateur"
