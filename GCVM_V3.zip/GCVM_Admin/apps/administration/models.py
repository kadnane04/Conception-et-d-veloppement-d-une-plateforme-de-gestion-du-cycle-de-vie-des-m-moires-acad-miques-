"""
Documents mis à disposition par l'administration.

Le guide méthodologique de rédaction est déposé ici par l'administrateur et
téléchargé par les étudiants depuis leur tableau de bord.

Le fichier n'est pas servi directement par le serveur de fichiers : il passe
par une vue qui vérifie d'abord que le demandeur est connecté. Un document
interne n'a pas à être accessible par une URL devinée.
"""

import os

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone


def valider_guide(fichier):
    extensions = settings.GCVM["EXTENSIONS_GUIDE"]
    taille_max = settings.GCVM["TAILLE_MAX_DEPOT_MO"]

    extension = os.path.splitext(fichier.name)[1].lower().lstrip(".")
    if extension not in extensions:
        raise ValidationError(
            f"Format « .{extension} » refusé. "
            f"Formats acceptés : {', '.join('.' + e for e in extensions)}.")
    if fichier.size > taille_max * 1024 * 1024:
        raise ValidationError(
            f"Fichier trop volumineux ({fichier.size / 1024 / 1024:.1f} Mo). "
            f"Maximum : {taille_max} Mo.")


class DocumentInstitutionnel(models.Model):
    """Document de référence proposé au téléchargement dans la plateforme."""

    class Categorie(models.TextChoices):
        GUIDE_REDACTION = "GUIDE_REDACTION", "Guide de rédaction du mémoire"
        MODELE = "MODELE", "Modèle de document"
        REGLEMENT = "REGLEMENT", "Règlement"
        AUTRE = "AUTRE", "Autre document"

    titre = models.CharField("Titre", max_length=150)
    description = models.CharField("Description", max_length=255, blank=True)
    categorie = models.CharField(
        "Catégorie", max_length=20, choices=Categorie.choices,
        default=Categorie.GUIDE_REDACTION)

    fichier = models.FileField(
        "Fichier", upload_to="documents/", validators=[valider_guide])
    nom_original = models.CharField("Nom du fichier", max_length=255, blank=True)
    taille_octets = models.PositiveBigIntegerField("Taille", default=0)

    est_publie = models.BooleanField(
        "Visible par les étudiants", default=True,
        help_text="Décochez pour retirer le document sans le supprimer.")

    depose_par = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Déposé par",
        on_delete=models.SET_NULL, null=True, blank=True,
        related_name="documents_deposes")
    date_depot = models.DateTimeField("Date de dépôt", default=timezone.now)
    nb_telechargements = models.PositiveIntegerField("Téléchargements", default=0)

    class Meta:
        verbose_name = "Document institutionnel"
        verbose_name_plural = "Documents institutionnels"
        ordering = ["-date_depot"]

    def __str__(self):
        return self.titre

    @property
    def taille_lisible(self):
        octets = self.taille_octets or 0
        if octets < 1024:
            return f"{octets} o"
        if octets < 1024 * 1024:
            return f"{octets / 1024:.0f} Ko"
        return f"{octets / 1024 / 1024:.1f} Mo"

    @classmethod
    def guide_en_vigueur(cls):
        """Le guide de rédaction le plus récent, s'il en existe un."""
        return cls.objects.filter(
            categorie=cls.Categorie.GUIDE_REDACTION, est_publie=True).first()
