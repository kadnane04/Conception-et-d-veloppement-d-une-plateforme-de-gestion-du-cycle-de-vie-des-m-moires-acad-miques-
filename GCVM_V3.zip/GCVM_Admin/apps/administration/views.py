"""
Module Administrateur.

Tableau de bord, création des comptes, gestion des comptes.

Une seule vue d'ajout et une seule vue de gestion servent les quatre
catégories : le rôle est un paramètre d'URL. Dupliquer quatre fois le même
code aurait multiplié par quatre les corrections à faire à chaque évolution.
"""

from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Count, Q
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from apps.accounts.forms import FORMULAIRES_PAR_ROLE, generer_mot_de_passe
from apps.accounts.models import (
    Activite, Filiere, Grade, JournalActivite, Role, StatutProfesseur, Utilisateur,
)

# Rôles gérés depuis le module Administrateur, dans l'ordre du menu.
CATEGORIES = {
    "etudiants": {
        "role": Role.ETUDIANT, "singulier": "étudiant", "pluriel": "étudiants",
        "article": "un", "icone": "bi-mortarboard",
    },
    "professeurs": {
        "role": Role.PROFESSEUR, "singulier": "professeur", "pluriel": "professeurs",
        "article": "un", "icone": "bi-person-video3",
    },
    "responsables-academiques": {
        "role": Role.RESP_ACADEMIQUE, "singulier": "responsable académique",
        "pluriel": "responsables académiques", "article": "un", "icone": "bi-bank",
    },
    "responsables-etudes": {
        "role": Role.RESP_ETUDES, "singulier": "responsable des études",
        "pluriel": "responsables des études", "article": "un", "icone": "bi-clipboard-check",
    },
}


def est_administrateur(utilisateur):
    return utilisateur.is_authenticated and utilisateur.est_administrateur


# Toutes les vues de ce module passent par ce garde : un utilisateur
# authentifié mais non administrateur est renvoyé vers son propre espace.
administrateur_requis = user_passes_test(est_administrateur, login_url="comptes:redirection")


def categorie_ou_404(cle):
    if cle not in CATEGORIES:
        raise Http404("Catégorie de compte inconnue.")
    return CATEGORIES[cle]


def profil_de(utilisateur):
    return utilisateur.profil


# ==========================================================================
# Tableau de bord
# ==========================================================================
@login_required
@administrateur_requis
def tableau_de_bord(requete):
    par_role = {
        ligne["role"]: ligne["n"]
        for ligne in Utilisateur.objects.values("role").annotate(n=Count("id"))
    }

    cartes = [
        {"cle": "etudiants", "titre": "Étudiants", "valeur": par_role.get(Role.ETUDIANT, 0),
         "icone": "bi-mortarboard", "ton": "bleu"},
        {"cle": "professeurs", "titre": "Professeurs", "valeur": par_role.get(Role.PROFESSEUR, 0),
         "icone": "bi-person-video3", "ton": "bleu"},
        {"cle": "responsables-academiques", "titre": "Responsables académiques",
         "valeur": par_role.get(Role.RESP_ACADEMIQUE, 0), "icone": "bi-bank", "ton": "bleu"},
        {"cle": "responsables-etudes", "titre": "Responsables des études",
         "valeur": par_role.get(Role.RESP_ETUDES, 0), "icone": "bi-clipboard-check", "ton": "bleu"},
        {"cle": None, "titre": "Total des utilisateurs", "valeur": sum(par_role.values()),
         "icone": "bi-people", "ton": "fonce"},
    ]

    actifs = Utilisateur.objects.filter(is_active=True).count()
    inactifs = Utilisateur.objects.filter(is_active=False).count()
    total = actifs + inactifs

    professeurs_avec_role = Utilisateur.objects.filter(
        role=Role.PROFESSEUR,
    ).exclude(profilprofesseur__statut=StatutProfesseur.AUCUN).count()

    return render(requete, "administration/tableau_de_bord.html", {
        "rubrique": "tdb",
        "cartes": cartes,
        "total": total,
        "actifs": actifs,
        "inactifs": inactifs,
        "part_actifs": round(actifs * 100 / total) if total else 0,
        "professeurs_avec_role": professeurs_avec_role,
        "jamais_connectes": Utilisateur.objects.filter(dernier_acces__isnull=True).count(),
        "dernieres_inscriptions": (
            Utilisateur.objects.order_by("-date_creation")[:8]
        ),
        "activites": JournalActivite.objects.select_related("auteur")[:10],
        "repartition_filieres": [
            {"libelle": libelle,
             "n": Utilisateur.objects.filter(role=Role.ETUDIANT,
                                             profiletudiant__filiere=code).count()}
            for code, libelle in Filiere.choices
        ],
    })


# ==========================================================================
# Ajout d'un compte
# ==========================================================================
@login_required
@administrateur_requis
def ajouter(requete, categorie):
    infos = categorie_ou_404(categorie)
    Formulaire = FORMULAIRES_PAR_ROLE[infos["role"]]
    formulaire = Formulaire(requete.POST or None)

    if requete.method == "POST" and formulaire.is_valid():
        with transaction.atomic():
            utilisateur = formulaire.enregistrer(auteur=requete.user)
            JournalActivite.enregistrer(
                requete.user, Activite.CREATION_COMPTE,
                f"Création du compte {infos['singulier']} de {utilisateur.nom_complet}",
                cible=utilisateur, requete=requete)
        messages.success(
            requete,
            f"Compte créé pour {utilisateur.nom_complet} ({utilisateur.email}). "
            f"Communiquez-lui son mot de passe initial : il pourra le changer ensuite.")
        return redirect("administration:gestion", categorie=categorie)

    return render(requete, "administration/formulaire_compte.html", {
        "rubrique": f"ajout-{categorie}",
        "categorie": categorie, "infos": infos, "formulaire": formulaire,
        "titre": f"Ajouter {infos['article']} {infos['singulier']}",
        "mode": "ajout",
    })


# ==========================================================================
# Gestion d'une catégorie
# ==========================================================================
@login_required
@administrateur_requis
def gestion(requete, categorie):
    infos = categorie_ou_404(categorie)
    role = infos["role"]

    comptes = Utilisateur.objects.filter(role=role)

    # -- Recherche ---------------------------------------------------------
    recherche = requete.GET.get("q", "").strip()
    if recherche:
        comptes = comptes.filter(
            Q(nom__icontains=recherche) | Q(prenom__icontains=recherche)
            | Q(email__icontains=recherche)
        )

    # -- Filtres -----------------------------------------------------------
    etat = requete.GET.get("etat", "")
    if etat == "actifs":
        comptes = comptes.filter(is_active=True)
    elif etat == "inactifs":
        comptes = comptes.filter(is_active=False)

    filtre_secondaire = requete.GET.get("filtre", "")
    if filtre_secondaire:
        if role == Role.ETUDIANT:
            comptes = comptes.filter(profiletudiant__filiere=filtre_secondaire)
        elif role == Role.PROFESSEUR:
            comptes = comptes.filter(profilprofesseur__statut=filtre_secondaire)
        elif role == Role.RESP_ETUDES:
            comptes = comptes.filter(profilresponsableetudes__grade=filtre_secondaire)
        elif role == Role.RESP_ACADEMIQUE:
            comptes = comptes.filter(profilresponsableacademique__grade=filtre_secondaire)

    # -- Tri ---------------------------------------------------------------
    TRIS = {
        "nom": ["nom", "prenom"], "-nom": ["-nom", "-prenom"],
        "email": ["email"], "-email": ["-email"],
        "date": ["date_creation"], "-date": ["-date_creation"],
    }
    tri = requete.GET.get("tri", "nom")
    comptes = comptes.order_by(*TRIS.get(tri, TRIS["nom"]))

    comptes = comptes.select_related(
        "profiletudiant", "profilprofesseur",
        "profilresponsableetudes", "profilresponsableacademique",
    )

    # -- Pagination --------------------------------------------------------
    from django.conf import settings
    paginateur = Paginator(comptes, settings.GCVM["ELEMENTS_PAR_PAGE"])
    page = paginateur.get_page(requete.GET.get("page"))

    # Les paramètres courants sont réinjectés dans les liens de pagination et
    # d'en-tête de colonne, pour que tri, filtres et recherche se combinent.
    parametres = requete.GET.copy()
    parametres.pop("page", None)

    # La colonne affichée et le critère de filtrage ne coïncident pas pour les
    # professeurs : la colonne montre le grade, le filtre porte sur les
    # responsabilités (qui ont leur propre colonne).
    if role == Role.ETUDIANT:
        libelle_colonne, libelle_filtre, choix_filtre = "Filière", "Filière", Filiere.choices
    elif role == Role.PROFESSEUR:
        libelle_colonne = "Grade"
        libelle_filtre, choix_filtre = "Responsabilités", StatutProfesseur.choices
    else:
        libelle_colonne, libelle_filtre, choix_filtre = "Grade", "Grade", Grade.choices

    return render(requete, "administration/gestion.html", {
        "rubrique": f"gestion-{categorie}",
        "categorie": categorie, "infos": infos,
        "page": page, "total_filtre": paginateur.count,
        "total_global": Utilisateur.objects.filter(role=role).count(),
        "recherche": recherche, "etat": etat, "tri": tri,
        "filtre_secondaire": filtre_secondaire,
        "libelle_colonne": libelle_colonne,
        "libelle_filtre": libelle_filtre, "choix_filtre": choix_filtre,
        "parametres": parametres.urlencode(),
    })


@login_required
@administrateur_requis
def consulter(requete, categorie, pk):
    infos = categorie_ou_404(categorie)
    compte = get_object_or_404(Utilisateur, pk=pk, role=infos["role"])
    return render(requete, "administration/fiche_compte.html", {
        "rubrique": f"gestion-{categorie}",
        "categorie": categorie, "infos": infos, "compte": compte,
        "profil": profil_de(compte),
        "activites": JournalActivite.objects.filter(
            Q(cible=compte) | Q(auteur=compte)).select_related("auteur")[:15],
    })


@login_required
@administrateur_requis
def modifier(requete, categorie, pk):
    infos = categorie_ou_404(categorie)
    compte = get_object_or_404(Utilisateur, pk=pk, role=infos["role"])
    Formulaire = FORMULAIRES_PAR_ROLE[infos["role"]]

    profil = profil_de(compte)
    initiales = {
        "nom": compte.nom, "prenom": compte.prenom, "email": compte.email,
        "date_naissance": compte.date_naissance, "telephone": compte.telephone,
    }
    if profil is not None:
        for champ in Formulaire.base_fields:
            if hasattr(profil, champ):
                initiales[champ] = getattr(profil, champ)

    formulaire = Formulaire(requete.POST or None, instance=compte, initial=initiales)

    if requete.method == "POST" and formulaire.is_valid():
        ancien_statut = getattr(profil, "statut", None)
        with transaction.atomic():
            formulaire.enregistrer(auteur=requete.user)
            JournalActivite.enregistrer(
                requete.user, Activite.MODIFICATION_COMPTE,
                f"Modification du compte de {compte.nom_complet}",
                cible=compte, requete=requete)
            # Le profil relu depuis la base : l'objet chargé plus haut porte
            # encore l'ancienne valeur, Django ayant mis la relation en cache.
            compte.refresh_from_db()
            nouveau_statut = getattr(profil_de(compte), "statut", None)
            if ancien_statut is not None and nouveau_statut != ancien_statut:
                JournalActivite.enregistrer(
                    requete.user, Activite.CHANGEMENT_STATUT,
                    f"{compte.nom_complet} : responsabilités passées à "
                    f"« {StatutProfesseur(nouveau_statut).label} »",
                    cible=compte, requete=requete)
        messages.success(requete, f"Le compte de {compte.nom_complet} a été mis à jour.")
        return redirect("administration:consulter", categorie=categorie, pk=compte.pk)

    return render(requete, "administration/formulaire_compte.html", {
        "rubrique": f"gestion-{categorie}",
        "categorie": categorie, "infos": infos, "formulaire": formulaire,
        "compte": compte, "titre": f"Modifier le compte de {compte.nom_complet}",
        "mode": "modification",
    })


# --------------------------------------------------------------------------
# Actions sensibles — toutes en POST, toutes confirmées par l'interface
# --------------------------------------------------------------------------
@login_required
@administrateur_requis
def reinitialiser_mot_de_passe(requete, categorie, pk):
    infos = categorie_ou_404(categorie)
    compte = get_object_or_404(Utilisateur, pk=pk, role=infos["role"])
    if requete.method != "POST":
        return redirect("administration:consulter", categorie=categorie, pk=pk)

    nouveau = generer_mot_de_passe()
    compte.set_password(nouveau)
    compte.save(update_fields=["password"])
    JournalActivite.enregistrer(
        requete.user, Activite.REINIT_MOT_DE_PASSE,
        f"Réinitialisation du mot de passe de {compte.nom_complet}",
        cible=compte, requete=requete)
    messages.success(
        requete,
        f"Nouveau mot de passe de {compte.nom_complet} : {nouveau} — "
        f"communiquez-le-lui, il n'est affiché qu'une seule fois.")
    return redirect("administration:consulter", categorie=categorie, pk=pk)


@login_required
@administrateur_requis
def basculer_activation(requete, categorie, pk):
    infos = categorie_ou_404(categorie)
    compte = get_object_or_404(Utilisateur, pk=pk, role=infos["role"])
    if requete.method != "POST":
        return redirect("administration:gestion", categorie=categorie)

    if compte.pk == requete.user.pk:
        messages.error(requete, "Vous ne pouvez pas désactiver votre propre compte.")
        return redirect("administration:gestion", categorie=categorie)

    compte.is_active = not compte.is_active
    compte.save(update_fields=["is_active"])
    if compte.is_active:
        JournalActivite.enregistrer(
            requete.user, Activite.REACTIVATION,
            f"Réactivation du compte de {compte.nom_complet}", cible=compte, requete=requete)
        messages.success(requete, f"Le compte de {compte.nom_complet} a été réactivé.")
    else:
        JournalActivite.enregistrer(
            requete.user, Activite.DESACTIVATION,
            f"Désactivation du compte de {compte.nom_complet}", cible=compte, requete=requete)
        messages.warning(
            requete,
            f"Le compte de {compte.nom_complet} a été désactivé : il ne peut plus se "
            f"connecter, mais ses données restent consultables.")
    return redirect(requete.POST.get("retour")
                    or f"/administration/{categorie}/")


@login_required
@administrateur_requis
def supprimer(requete, categorie, pk):
    infos = categorie_ou_404(categorie)
    compte = get_object_or_404(Utilisateur, pk=pk, role=infos["role"])
    if requete.method != "POST":
        return redirect("administration:consulter", categorie=categorie, pk=pk)

    if compte.pk == requete.user.pk:
        messages.error(requete, "Vous ne pouvez pas supprimer votre propre compte.")
        return redirect("administration:gestion", categorie=categorie)

    nom = compte.nom_complet
    # Le libellé est écrit avant la suppression : le journal doit rester
    # lisible une fois le compte parti.
    JournalActivite.enregistrer(
        requete.user, Activite.SUPPRESSION,
        f"Suppression définitive du compte de {nom} ({compte.email})", requete=requete)
    compte.delete()
    messages.success(requete, f"Le compte de {nom} a été supprimé définitivement.")
    return redirect("administration:gestion", categorie=categorie)


# ==========================================================================
# Journal
# ==========================================================================
@login_required
@administrateur_requis
def journal(requete):
    activites = JournalActivite.objects.select_related("auteur", "cible")
    type_activite = requete.GET.get("type", "")
    if type_activite:
        activites = activites.filter(type_activite=type_activite)

    from django.conf import settings
    paginateur = Paginator(activites, settings.GCVM["ELEMENTS_PAR_PAGE"] * 2)
    return render(requete, "administration/journal.html", {
        "rubrique": "journal",
        "page": paginateur.get_page(requete.GET.get("page")),
        "types": Activite.choices, "type_activite": type_activite,
        "aujourdhui": JournalActivite.objects.filter(
            horodatage__date=timezone.localdate()).count(),
    })


# ==========================================================================
# Référentiels alimentant l'espace Étudiant
# ==========================================================================
# Ces trois écrans ont été ajoutés avec le module Étudiant : les catégories de
# thèmes, les années académiques et le guide de rédaction sont saisis ici puis
# consommés là-bas. Ils ne modifient en rien la gestion des comptes.

from apps.memories.models import AnneeAcademique          # noqa: E402
from apps.themes.models import CategorieTheme             # noqa: E402

from .forms import (                                       # noqa: E402
    AnneeAcademiqueForm, CategorieThemeForm, DocumentInstitutionnelForm,
)
from .models import DocumentInstitutionnel                 # noqa: E402


@login_required
@administrateur_requis
def categories(requete):
    """Catégories de thèmes : liste et création dans le même écran."""
    formulaire = CategorieThemeForm(requete.POST or None)
    if requete.method == "POST" and formulaire.is_valid():
        categorie = formulaire.save()
        JournalActivite.enregistrer(
            requete.user, Activite.MODIFICATION_COMPTE,
            f"Création de la catégorie de thème « {categorie.nom} »", requete=requete)
        messages.success(requete, f"Catégorie « {categorie.nom} » créée.")
        return redirect("administration:categories")

    return render(requete, "administration/categories.html", {
        "rubrique": "categories",
        "categories": CategorieTheme.objects.annotate(n=Count("themes")),
        "formulaire": formulaire,
    })


@login_required
@administrateur_requis
def modifier_categorie(requete, pk):
    categorie = get_object_or_404(CategorieTheme, pk=pk)
    formulaire = CategorieThemeForm(requete.POST or None, instance=categorie)
    if requete.method == "POST" and formulaire.is_valid():
        formulaire.save()
        messages.success(requete, f"Catégorie « {categorie.nom} » mise à jour.")
        return redirect("administration:categories")
    return render(requete, "administration/categorie_form.html", {
        "rubrique": "categories", "formulaire": formulaire, "categorie": categorie,
    })


@login_required
@administrateur_requis
def supprimer_categorie(requete, pk):
    categorie = get_object_or_404(CategorieTheme, pk=pk)
    if requete.method != "POST":
        return redirect("administration:categories")
    if categorie.themes.exists():
        # Supprimer une catégorie rattachée à des thèmes effacerait le lien
        # sans prévenir. La désactivation la retire du formulaire étudiant
        # tout en conservant l'historique.
        categorie.est_active = False
        categorie.save(update_fields=["est_active"])
        messages.warning(
            requete,
            f"« {categorie.nom} » est utilisée par {categorie.themes.count()} thème(s) : "
            f"elle a été désactivée plutôt que supprimée.")
    else:
        nom = categorie.nom
        categorie.delete()
        messages.success(requete, f"Catégorie « {nom} » supprimée.")
    return redirect("administration:categories")


@login_required
@administrateur_requis
def annees(requete):
    """Années académiques : liste et création."""
    formulaire = AnneeAcademiqueForm(requete.POST or None)
    if requete.method == "POST" and formulaire.is_valid():
        annee = formulaire.save()
        messages.success(requete, f"Année {annee.libelle} enregistrée.")
        return redirect("administration:annees")

    return render(requete, "administration/annees.html", {
        "rubrique": "annees",
        "annees": AnneeAcademique.objects.annotate(n=Count("memoires")),
        "formulaire": formulaire,
    })


@login_required
@administrateur_requis
def activer_annee(requete, pk):
    annee = get_object_or_404(AnneeAcademique, pk=pk)
    if requete.method != "POST":
        return redirect("administration:annees")
    AnneeAcademique.objects.update(est_active=False)
    annee.est_active = True
    annee.save(update_fields=["est_active"])
    messages.success(requete, f"L'année {annee.libelle} est désormais l'année en cours.")
    return redirect("administration:annees")


@login_required
@administrateur_requis
def documents(requete):
    """Dépôt du guide de rédaction et des autres documents institutionnels."""
    formulaire = DocumentInstitutionnelForm(requete.POST or None, requete.FILES or None)
    if requete.method == "POST" and formulaire.is_valid():
        document = formulaire.save(depose_par=requete.user)
        messages.success(
            requete,
            f"« {document.titre} » a été déposé. Les étudiants peuvent désormais "
            f"le télécharger depuis leur tableau de bord.")
        return redirect("administration:documents")

    return render(requete, "administration/documents.html", {
        "rubrique": "documents",
        "documents": DocumentInstitutionnel.objects.select_related("depose_par"),
        "formulaire": formulaire,
        "guide": DocumentInstitutionnel.guide_en_vigueur(),
    })


@login_required
@administrateur_requis
def supprimer_document(requete, pk):
    document = get_object_or_404(DocumentInstitutionnel, pk=pk)
    if requete.method != "POST":
        return redirect("administration:documents")
    titre = document.titre
    document.fichier.delete(save=False)
    document.delete()
    messages.success(requete, f"« {titre} » a été supprimé.")
    return redirect("administration:documents")
