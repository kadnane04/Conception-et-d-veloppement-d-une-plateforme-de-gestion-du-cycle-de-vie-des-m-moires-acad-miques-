"""Routes du module Administrateur."""

from django.urls import path

from . import views

app_name = "administration"

urlpatterns = [
    path("", views.tableau_de_bord, name="tableau_de_bord"),
    path("journal/", views.journal, name="journal"),

    # Référentiels alimentant l'espace Étudiant
    path("categories/", views.categories, name="categories"),
    path("categories/<int:pk>/modifier/", views.modifier_categorie, name="modifier_categorie"),
    path("categories/<int:pk>/supprimer/", views.supprimer_categorie, name="supprimer_categorie"),
    path("annees/", views.annees, name="annees"),
    path("annees/<int:pk>/activer/", views.activer_annee, name="activer_annee"),
    path("documents/", views.documents, name="documents"),
    path("documents/<int:pk>/supprimer/", views.supprimer_document, name="supprimer_document"),

    # <categorie> vaut etudiants, professeurs, responsables-academiques
    # ou responsables-etudes. Une seule série de vues sert les quatre.
    path("ajouter/<slug:categorie>/", views.ajouter, name="ajouter"),
    path("<slug:categorie>/", views.gestion, name="gestion"),
    path("<slug:categorie>/<int:pk>/", views.consulter, name="consulter"),
    path("<slug:categorie>/<int:pk>/modifier/", views.modifier, name="modifier"),
    path("<slug:categorie>/<int:pk>/mot-de-passe/",
         views.reinitialiser_mot_de_passe, name="reinitialiser_mot_de_passe"),
    path("<slug:categorie>/<int:pk>/activation/",
         views.basculer_activation, name="basculer_activation"),
    path("<slug:categorie>/<int:pk>/supprimer/", views.supprimer, name="supprimer"),
]
