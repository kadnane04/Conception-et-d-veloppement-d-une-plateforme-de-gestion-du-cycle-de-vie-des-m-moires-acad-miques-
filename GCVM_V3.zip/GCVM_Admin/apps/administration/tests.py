"""
Tests du module Administrateur.

Ils couvrent ce que la navigation ne révèle pas : la soumission des
formulaires, les contrôles d'unicité, l'effet réel des actions sensibles.
"""

from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import (
    Activite, Filiere, Grade, JournalActivite, ProfilEtudiant, ProfilProfesseur,
    Role, StatutProfesseur, Utilisateur,
)

MDP = "Plateforme@2026"


class BaseAdminTest(TestCase):

    def setUp(self):
        self.admin = Utilisateur.objects.create_user(
            email="admin.test@lbs.com", password=MDP, nom="Admin", prenom="Test",
            role=Role.ADMINISTRATEUR, is_staff=True, is_superuser=True)
        self.client.force_login(self.admin)

    def creer_etudiant(self, email="ama.kossi@lbs.com", **extra):
        donnees = {
            "nom": "KOSSI", "prenom": "Ama", "date_naissance": "2002-04-11",
            "email": email, "telephone": "", "mot_de_passe": "Etudiant@2026",
            "filiere": Filiere.MANAGEMENT, "matricule": "LBS-001",
        }
        donnees.update(extra)
        return self.client.post(
            reverse("administration:ajouter", args=["etudiants"]), donnees, follow=True)

    def creer_professeur(self, email="yao.mensah@lbs.com", statut=StatutProfesseur.ENCADREUR_JURY):
        return self.client.post(
            reverse("administration:ajouter", args=["professeurs"]), {
                "nom": "MENSAH", "prenom": "Yao", "date_naissance": "1978-09-02",
                "email": email, "telephone": "", "mot_de_passe": "Professeur@2026",
                "grade": Grade.MAITRE_CONFERENCES, "specialite": "Systèmes d'information",
                "statut": statut, "quota_encadrement": 6,
            }, follow=True)


class TableauDeBordTest(BaseAdminTest):

    def test_affichage(self):
        reponse = self.client.get(reverse("administration:tableau_de_bord"))
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "Tableau de bord")

    def test_compteurs_par_role(self):
        self.creer_etudiant()
        self.creer_professeur()
        reponse = self.client.get(reverse("administration:tableau_de_bord"))
        valeurs = {c["titre"]: c["valeur"] for c in reponse.context["cartes"]}
        self.assertEqual(valeurs["Étudiants"], 1)
        self.assertEqual(valeurs["Professeurs"], 1)
        self.assertEqual(valeurs["Total des utilisateurs"], Utilisateur.objects.count())

    def test_dernieres_inscriptions_et_activites(self):
        self.creer_etudiant()
        reponse = self.client.get(reverse("administration:tableau_de_bord"))
        self.assertTrue(reponse.context["dernieres_inscriptions"])
        self.assertTrue(reponse.context["activites"])


class CreationDeComptesTest(BaseAdminTest):

    def test_creation_etudiant_cree_compte_et_profil(self):
        reponse = self.creer_etudiant()
        self.assertEqual(reponse.status_code, 200)
        utilisateur = Utilisateur.objects.get(email="ama.kossi@lbs.com")
        self.assertEqual(utilisateur.role, Role.ETUDIANT)
        self.assertEqual(utilisateur.profil.filiere, Filiere.MANAGEMENT)
        self.assertEqual(utilisateur.cree_par, self.admin)

    def test_mot_de_passe_initial_utilisable_et_hache(self):
        self.creer_etudiant()
        utilisateur = Utilisateur.objects.get(email="ama.kossi@lbs.com")
        self.assertNotIn("Etudiant@2026", utilisateur.password)
        self.assertTrue(utilisateur.check_password("Etudiant@2026"))

    def test_email_en_double_refuse(self):
        self.creer_etudiant()
        reponse = self.creer_etudiant()
        self.assertContains(reponse, "déjà cette adresse")
        self.assertEqual(Utilisateur.objects.filter(email="ama.kossi@lbs.com").count(), 1)

    def test_email_en_double_entre_deux_roles_differents(self):
        self.creer_etudiant(email="partage@lbs.com")
        reponse = self.creer_professeur(email="partage@lbs.com")
        self.assertContains(reponse, "déjà cette adresse")

    def test_champ_obligatoire_manquant(self):
        reponse = self.creer_etudiant(nom="")
        self.assertEqual(Utilisateur.objects.filter(role=Role.ETUDIANT).count(), 0)
        self.assertContains(reponse, "obligatoire")

    def test_mot_de_passe_trop_faible_refuse(self):
        self.creer_etudiant(mot_de_passe="1234")
        self.assertEqual(Utilisateur.objects.filter(email="ama.kossi@lbs.com").count(), 0)

    def test_professeur_cumulant_les_deux_responsabilites(self):
        self.creer_professeur()
        profil = Utilisateur.objects.get(email="yao.mensah@lbs.com").profil
        self.assertTrue(profil.est_encadreur)
        self.assertTrue(profil.est_jury)

    def test_un_seul_compte_par_professeur(self):
        self.creer_professeur()
        self.assertEqual(Utilisateur.objects.filter(role=Role.PROFESSEUR).count(), 1)

    def test_creation_responsables(self):
        for categorie, role in [("responsables-etudes", Role.RESP_ETUDES),
                                ("responsables-academiques", Role.RESP_ACADEMIQUE)]:
            self.client.post(reverse("administration:ajouter", args=[categorie]), {
                "nom": "ADJO", "prenom": "Kodjo", "date_naissance": "1980-01-01",
                "email": f"{categorie}@lbs.com", "telephone": "",
                "mot_de_passe": "Responsable@2026", "grade": Grade.DOCTEUR}, follow=True)
            utilisateur = Utilisateur.objects.get(email=f"{categorie}@lbs.com")
            self.assertEqual(utilisateur.role, role)
            self.assertEqual(utilisateur.profil.grade, Grade.DOCTEUR)

    def test_creation_journalisee(self):
        self.creer_etudiant()
        self.assertTrue(JournalActivite.objects.filter(
            type_activite=Activite.CREATION_COMPTE).exists())

    def test_categorie_inconnue(self):
        self.assertEqual(self.client.get(
            reverse("administration:ajouter", args=["pilotes"])).status_code, 404)


class GestionDesComptesTest(BaseAdminTest):

    def setUp(self):
        super().setUp()
        self.creer_etudiant()
        self.etudiant = Utilisateur.objects.get(email="ama.kossi@lbs.com")

    def url(self, nom, *args):
        return reverse(f"administration:{nom}", args=args)

    def test_liste(self):
        reponse = self.client.get(self.url("gestion", "etudiants"))
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "ama.kossi@lbs.com")

    def test_recherche(self):
        self.assertContains(self.client.get(self.url("gestion", "etudiants") + "?q=kossi"),
                            "ama.kossi@lbs.com")
        self.assertNotContains(self.client.get(self.url("gestion", "etudiants") + "?q=zzzz"),
                               "ama.kossi@lbs.com")

    def test_filtre_par_etat(self):
        self.etudiant.is_active = False
        self.etudiant.save()
        self.assertNotContains(
            self.client.get(self.url("gestion", "etudiants") + "?etat=actifs"),
            "ama.kossi@lbs.com")
        self.assertContains(
            self.client.get(self.url("gestion", "etudiants") + "?etat=inactifs"),
            "ama.kossi@lbs.com")

    def test_filtre_par_filiere(self):
        self.assertContains(
            self.client.get(self.url("gestion", "etudiants") + "?filtre=MANAGEMENT"),
            "ama.kossi@lbs.com")
        self.assertNotContains(
            self.client.get(self.url("gestion", "etudiants") + "?filtre=SYSTEME_INFORMATION"),
            "ama.kossi@lbs.com")

    def test_tri(self):
        for tri in ["nom", "-nom", "email", "-email", "date", "-date"]:
            self.assertEqual(self.client.get(
                self.url("gestion", "etudiants") + f"?tri={tri}").status_code, 200)

    def test_consultation(self):
        reponse = self.client.get(self.url("consulter", "etudiants", self.etudiant.pk))
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "KOSSI")

    def test_consultation_dans_la_mauvaise_categorie(self):
        self.assertEqual(self.client.get(
            self.url("consulter", "professeurs", self.etudiant.pk)).status_code, 404)

    def test_modification(self):
        self.client.post(self.url("modifier", "etudiants", self.etudiant.pk), {
            "nom": "KOSSI", "prenom": "Ama Rose", "date_naissance": "2002-04-11",
            "email": "ama.kossi@lbs.com", "telephone": "90112233",
            "filiere": Filiere.SYSTEME_INFORMATION, "matricule": "LBS-001"}, follow=True)
        self.etudiant.refresh_from_db()
        self.assertEqual(self.etudiant.prenom, "Ama Rose")
        self.assertEqual(self.etudiant.profil.filiere, Filiere.SYSTEME_INFORMATION)

    def test_modification_ne_demande_pas_le_mot_de_passe(self):
        reponse = self.client.get(self.url("modifier", "etudiants", self.etudiant.pk))
        self.assertNotIn("mot_de_passe", reponse.context["formulaire"].fields)

    def test_reinitialisation_du_mot_de_passe(self):
        ancien = self.etudiant.password
        self.client.post(self.url("reinitialiser_mot_de_passe", "etudiants", self.etudiant.pk))
        self.etudiant.refresh_from_db()
        self.assertNotEqual(self.etudiant.password, ancien)
        self.assertFalse(self.etudiant.check_password("Etudiant@2026"))

    def test_desactivation_puis_reactivation(self):
        url = self.url("basculer_activation", "etudiants", self.etudiant.pk)
        self.client.post(url)
        self.etudiant.refresh_from_db()
        self.assertFalse(self.etudiant.is_active)
        self.client.post(url)
        self.etudiant.refresh_from_db()
        self.assertTrue(self.etudiant.is_active)

    def test_suppression(self):
        self.client.post(self.url("supprimer", "etudiants", self.etudiant.pk))
        self.assertFalse(Utilisateur.objects.filter(pk=self.etudiant.pk).exists())
        self.assertFalse(ProfilEtudiant.objects.filter(pk=self.etudiant.pk).exists())

    def test_journal_conserve_la_trace_apres_suppression(self):
        self.client.post(self.url("supprimer", "etudiants", self.etudiant.pk))
        trace = JournalActivite.objects.filter(type_activite=Activite.SUPPRESSION).first()
        self.assertIsNotNone(trace)
        self.assertIn("KOSSI", trace.libelle)

    def test_actions_sensibles_ignorent_les_requetes_get(self):
        """Une action destructrice ne doit jamais partir d'un simple GET."""
        for nom in ["supprimer", "basculer_activation", "reinitialiser_mot_de_passe"]:
            self.client.get(self.url(nom, "etudiants", self.etudiant.pk))
        self.etudiant.refresh_from_db()
        self.assertTrue(Utilisateur.objects.filter(pk=self.etudiant.pk).exists())
        self.assertTrue(self.etudiant.is_active)
        self.assertTrue(self.etudiant.check_password("Etudiant@2026"))

    def test_administrateur_ne_peut_pas_se_desactiver(self):
        Utilisateur.objects.filter(pk=self.admin.pk).update(role=Role.ETUDIANT)
        self.client.post(self.url("basculer_activation", "etudiants", self.admin.pk))
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.is_active)

    def test_administrateur_ne_peut_pas_se_supprimer(self):
        Utilisateur.objects.filter(pk=self.admin.pk).update(role=Role.ETUDIANT)
        self.client.post(self.url("supprimer", "etudiants", self.admin.pk))
        self.assertTrue(Utilisateur.objects.filter(pk=self.admin.pk).exists())

    def test_pagination(self):
        for i in range(20):
            Utilisateur.objects.create_user(
                email=f"etu{i}@lbs.com", password=MDP, nom=f"NOM{i}", prenom="X",
                role=Role.ETUDIANT)
        reponse = self.client.get(self.url("gestion", "etudiants"))
        self.assertTrue(reponse.context["page"].has_next())


class ChangementDeResponsabilitesTest(BaseAdminTest):
    """Le cœur du principe « un professeur, un seul compte »."""

    def test_passage_encadreur_vers_encadreur_et_jury(self):
        self.creer_professeur(statut=StatutProfesseur.ENCADREUR)
        prof = Utilisateur.objects.get(email="yao.mensah@lbs.com")
        self.assertFalse(prof.profil.est_jury)

        self.client.post(
            reverse("administration:modifier", args=["professeurs", prof.pk]), {
                "nom": "MENSAH", "prenom": "Yao", "date_naissance": "1978-09-02",
                "email": "yao.mensah@lbs.com", "telephone": "",
                "grade": Grade.MAITRE_CONFERENCES, "specialite": "Systèmes d'information",
                "statut": StatutProfesseur.ENCADREUR_JURY, "quota_encadrement": 6},
            follow=True)

        prof.refresh_from_db()
        profil = ProfilProfesseur.objects.get(pk=prof.pk)
        self.assertTrue(profil.est_encadreur)
        self.assertTrue(profil.est_jury)
        # Toujours un seul compte, et le changement est tracé.
        self.assertEqual(Utilisateur.objects.filter(role=Role.PROFESSEUR).count(), 1)
        self.assertTrue(JournalActivite.objects.filter(
            type_activite=Activite.CHANGEMENT_STATUT).exists())


class JournalTest(BaseAdminTest):

    def test_affichage_et_filtre(self):
        self.creer_etudiant()
        self.assertEqual(self.client.get(reverse("administration:journal")).status_code, 200)
        reponse = self.client.get(
            reverse("administration:journal") + f"?type={Activite.CREATION_COMPTE}")
        self.assertEqual(reponse.status_code, 200)
        for activite in reponse.context["page"].object_list:
            self.assertEqual(activite.type_activite, Activite.CREATION_COMPTE)


class ModulesTest(TestCase):
    """
    État des modules après la phase 3.

    Tous les modules métier sont désormais développés. Les espaces par rôle
    (etudiant, encadreur, etudes, academique, jury) n'ont volontairement aucun
    modèle : ils pilotent ceux des modules métier.
    """

    METIER = ["themes", "supervision", "memories", "notifications",
              "defenses", "archives"]
    ESPACES = ["etudiant", "encadreur", "etudes", "academique", "jury"]

    def test_applications_installees(self):
        from django.apps import apps
        for nom in self.METIER + self.ESPACES + ["accounts", "administration"]:
            self.assertTrue(apps.is_installed(f"apps.{nom}"), nom)

    def test_modules_metier_portent_leurs_modeles(self):
        from django.apps import apps
        for nom in self.METIER:
            self.assertTrue(list(apps.get_app_config(nom).get_models()), nom)

    def test_espaces_par_role_sans_modele(self):
        """Un espace est une vue sur les modules métier, pas un modèle de plus."""
        from django.apps import apps
        for nom in self.ESPACES:
            self.assertEqual(list(apps.get_app_config(nom).get_models()), [], nom)
