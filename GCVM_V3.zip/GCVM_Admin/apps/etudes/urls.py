"""Routes de l'espace Responsable des Études."""

from django.urls import path

from . import views

app_name = "etudes"

urlpatterns = [
    path("", views.tableau_de_bord, name="tableau_de_bord"),

    # Thèmes
    path("themes/", views.themes, name="themes"),
    path("themes/<int:pk>/", views.detail_theme, name="detail_theme"),

    # Encadrements
    path("encadrements/", views.encadrements, name="encadrements"),

    # Mémoires et transmission
    path("memoires/", views.memoires, name="memoires"),
    path("memoires/<int:pk>/", views.detail_memoire, name="detail_memoire"),
    path("memoires/<int:pk>/transmettre/", views.transmettre_memoire,
         name="transmettre_memoire"),

    # Soutenances
    path("soutenances/", views.soutenances, name="soutenances"),
    path("soutenances/planifier/<int:pk>/", views.planifier, name="planifier"),
    path("soutenances/<int:pk>/", views.detail_soutenance, name="detail_soutenance"),
    path("soutenances/<int:pk>/cloturer/", views.cloturer_soutenance,
         name="cloturer_soutenance"),
    path("jury/<int:pk>/remplacer/", views.remplacer_membre, name="remplacer_membre"),

    # Archivage et bibliothèque
    path("archivage/", views.archivage, name="archivage"),
    path("archivage/<int:pk>/", views.archiver_memoire, name="archiver_memoire"),
    path("importer/", views.importer_archive, name="importer_archive"),

    path("version/<int:pk>/telecharger/", views.telecharger_version,
         name="telecharger_version"),
]
