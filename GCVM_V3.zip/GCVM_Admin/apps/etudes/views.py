"""
Espace Responsable des Études.

C'est le pivot du cycle : il valide les thèmes, transmet les mémoires au
Responsable Académique, programme les soutenances, puis archive. Chaque action
passe par les services de `apps.memories`, qui changent le statut, tracent la
décision et préviennent les personnes concernées d'un seul geste.
"""

import os

from django.contrib import messages
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Count, Q
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from apps.accounts.gardes import resp_etudes_requis
from apps.archives.models import MemoireArchive
from apps.defenses.models import (
    ParticipationJury, RoleJury, Soutenance, StatutParticipation, StatutSoutenance,
    mention_pour_note,
)
from apps.memories.models import Memoire, StatutMemoire, VersionMemoire
from apps.memories.services import archiver, transmettre
from apps.notifications.models import Notification, TypeNotification
from apps.supervision.models import DemandeEncadrement, StatutDemande
from apps.themes.models import StatutTheme, Theme

from .forms import (
    DecisionThemeForm, ImportArchiveForm, RemplacantForm, ResultatSoutenanceForm,
    SoutenanceForm,
)


def _pagination(requete, file, par_page=None):
    from django.conf import settings
    return Paginator(file, par_page or settings.GCVM["ELEMENTS_PAR_PAGE"]).get_page(
        requete.GET.get("page"))


# ==========================================================================
# Tableau de bord
# ==========================================================================
@resp_etudes_requis
def tableau_de_bord(requete):
    themes_attente = Theme.objects.filter(statut=StatutTheme.EN_ATTENTE)
    encadrements = DemandeEncadrement.objects.filter(statut=StatutDemande.ACCEPTE)
    a_transmettre = Memoire.objects.filter(statut=StatutMemoire.VALIDE_ENCADREUR)
    a_planifier = Memoire.objects.filter(
        statut=StatutMemoire.VALIDE_RESP_ACADEMIQUE, soutenance__isnull=True)
    a_archiver = Memoire.objects.filter(statut=StatutMemoire.FINALE_VALIDEE_ENCADREUR)
    archives = MemoireArchive.objects.all()

    cartes = [
        {"cle": "etudes:themes", "titre": "Thèmes en attente",
         "valeur": themes_attente.count(), "icone": "bi-lightbulb", "ton": "bleu"},
        {"cle": "etudes:encadrements", "titre": "Encadrements acceptés",
         "valeur": encadrements.count(), "icone": "bi-person-check", "ton": "bleu"},
        {"cle": "etudes:memoires", "titre": "Mémoires à transmettre",
         "valeur": a_transmettre.count(), "icone": "bi-send", "ton": "bleu"},
        {"cle": "etudes:soutenances", "titre": "Soutenances à planifier",
         "valeur": a_planifier.count(), "icone": "bi-calendar-plus", "ton": "bleu"},
        {"cle": "etudes:archivage", "titre": "À archiver",
         "valeur": a_archiver.count(), "icone": "bi-archive", "ton": "bleu"},
        {"cle": "archives:bibliotheque", "titre": "Mémoires archivés",
         "valeur": archives.count(), "icone": "bi-book", "ton": "fonce"},
    ]

    prochaines = (Soutenance.objects
                  .filter(date_soutenance__gte=timezone.localdate())
                  .exclude(statut=StatutSoutenance.ANNULEE)
                  .select_related("memoire", "memoire__etudiant", "salle")
                  .order_by("date_soutenance", "heure_debut")[:5])

    return render(requete, "etudes/tableau_de_bord.html", {
        "rubrique": "tdb", "cartes": cartes,
        "themes_attente": themes_attente.select_related("etudiant")[:5],
        "a_transmettre": a_transmettre.select_related("etudiant", "encadreur")[:5],
        "prochaines": prochaines,
        "jurys_incomplets": Soutenance.objects.filter(
            statut=StatutSoutenance.EN_COMPOSITION).count(),
    })


# ==========================================================================
# Validation des thèmes
# ==========================================================================
@resp_etudes_requis
def themes(requete):
    liste = (Theme.objects.select_related("etudiant", "etudiant__profiletudiant",
                                          "decide_par")
             .prefetch_related("categories").order_by("-date_soumission"))

    filtre = requete.GET.get("statut", StatutTheme.EN_ATTENTE)
    if filtre:
        liste = liste.filter(statut=filtre)
    recherche = requete.GET.get("q", "").strip()
    if recherche:
        liste = liste.filter(Q(titre__icontains=recherche)
                             | Q(etudiant__nom__icontains=recherche)
                             | Q(etudiant__prenom__icontains=recherche))

    return render(requete, "etudes/themes.html", {
        "rubrique": "themes", "page": _pagination(requete, liste),
        "filtre": filtre, "recherche": recherche, "statuts": StatutTheme.choices,
        "en_attente": Theme.objects.filter(statut=StatutTheme.EN_ATTENTE).count(),
    })


@resp_etudes_requis
def detail_theme(requete, pk):
    theme = get_object_or_404(
        Theme.objects.select_related("etudiant", "etudiant__profiletudiant", "decide_par")
        .prefetch_related("categories"), pk=pk)

    formulaire = DecisionThemeForm(requete.POST or None)

    if requete.method == "POST":
        if not theme.est_en_attente:
            messages.warning(requete, "Une décision a déjà été rendue sur ce thème.")
            return redirect("etudes:themes")

        if formulaire.is_valid():
            if formulaire.cleaned_data["decision"] == "valider":
                theme.valider(par=requete.user)
                Notification.envoyer(
                    theme.etudiant, TypeNotification.THEME_VALIDE,
                    "Votre thème a été validé",
                    f"« {theme.titre} » est validé. Vous pouvez maintenant "
                    f"choisir un encadreur.", "/encadrement/encadreurs/")
                messages.success(
                    requete,
                    f"Thème validé. {theme.etudiant.nom_complet} peut choisir "
                    f"un encadreur.")
            else:
                motif = formulaire.cleaned_data["motif"].strip()
                theme.rejeter(motif, par=requete.user)
                Notification.envoyer(
                    theme.etudiant, TypeNotification.THEME_REJETE,
                    "Votre thème a été rejeté",
                    f"Motif : {motif}. Vous pouvez proposer un nouveau sujet.",
                    "/themes/mes-themes/")
                messages.info(requete, "Thème rejeté et étudiant prévenu.")
            return redirect("etudes:themes")

    # Sujets proches déjà pris : la décision se prend en connaissance de cause.
    similaires = Theme.similaires(theme.titre, exclure_pk=theme.pk)

    return render(requete, "etudes/detail_theme.html", {
        "rubrique": "themes", "theme": theme, "formulaire": formulaire,
        "similaires": similaires,
    })


# ==========================================================================
# Encadrements
# ==========================================================================
@resp_etudes_requis
def encadrements(requete):
    liste = (DemandeEncadrement.objects
             .select_related("etudiant", "encadreur", "encadreur__profilprofesseur",
                             "theme")
             .order_by("-date_demande"))
    filtre = requete.GET.get("statut", "")
    if filtre:
        liste = liste.filter(statut=filtre)

    return render(requete, "etudes/encadrements.html", {
        "rubrique": "encadrements", "page": _pagination(requete, liste),
        "filtre": filtre, "statuts": StatutDemande.choices,
        "acceptes": DemandeEncadrement.objects.filter(
            statut=StatutDemande.ACCEPTE).count(),
    })


# ==========================================================================
# Réception et transmission des mémoires
# ==========================================================================
@resp_etudes_requis
def memoires(requete):
    liste = (Memoire.objects.select_related("etudiant", "encadreur", "theme",
                                            "annee_academique")
             .order_by("-date_dernier_depot"))
    filtre = requete.GET.get("statut", StatutMemoire.VALIDE_ENCADREUR)
    if filtre:
        liste = liste.filter(statut=filtre)

    return render(requete, "etudes/memoires.html", {
        "rubrique": "memoires", "page": _pagination(requete, liste),
        "filtre": filtre, "statuts": StatutMemoire.choices,
        "a_transmettre": Memoire.objects.filter(
            statut=StatutMemoire.VALIDE_ENCADREUR).count(),
    })


@resp_etudes_requis
def detail_memoire(requete, pk):
    memoire = get_object_or_404(
        Memoire.objects.select_related("etudiant", "encadreur", "theme",
                                       "annee_academique"), pk=pk)
    return render(requete, "etudes/detail_memoire.html", {
        "rubrique": "memoires", "memoire": memoire,
        "versions": memoire.versions.select_related("depose_par"),
        "decisions": memoire.decisions.select_related("auteur"),
        "soutenance": getattr(memoire, "soutenance", None),
    })


@resp_etudes_requis
def transmettre_memoire(requete, pk):
    memoire = get_object_or_404(Memoire, pk=pk)
    if requete.method != "POST":
        return redirect("etudes:detail_memoire", pk=pk)
    if not memoire.attend_transmission:
        messages.warning(
            requete, "Ce mémoire n'est pas en attente de transmission.")
        return redirect("etudes:detail_memoire", pk=pk)

    transmettre(memoire, requete.user)
    messages.success(
        requete,
        f"Le mémoire de {memoire.etudiant.nom_complet} a été transmis au "
        f"Responsable Académique.")
    return redirect("etudes:memoires")


# ==========================================================================
# Soutenances
# ==========================================================================
@resp_etudes_requis
def soutenances(requete):
    a_planifier = (Memoire.objects
                   .filter(statut=StatutMemoire.VALIDE_RESP_ACADEMIQUE,
                           soutenance__isnull=True)
                   .select_related("etudiant", "encadreur", "theme"))

    programmees = (Soutenance.objects
                   .select_related("memoire", "memoire__etudiant", "salle")
                   .prefetch_related("membres__enseignant")
                   .order_by("date_soutenance", "heure_debut"))

    filtre = requete.GET.get("statut", "")
    if filtre:
        programmees = programmees.filter(statut=filtre)

    return render(requete, "etudes/soutenances.html", {
        "rubrique": "soutenances", "a_planifier": a_planifier,
        "page": _pagination(requete, programmees),
        "filtre": filtre, "statuts": StatutSoutenance.choices,
        "en_composition": Soutenance.objects.filter(
            statut=StatutSoutenance.EN_COMPOSITION).count(),
    })


@resp_etudes_requis
def planifier(requete, pk):
    """Création de la soutenance et invitation du jury."""
    memoire = get_object_or_404(
        Memoire.objects.select_related("etudiant", "encadreur", "theme"), pk=pk)

    if hasattr(memoire, "soutenance"):
        return redirect("etudes:detail_soutenance", pk=memoire.soutenance.pk)

    if memoire.statut != StatutMemoire.VALIDE_RESP_ACADEMIQUE:
        messages.warning(
            requete,
            "La soutenance ne se programme qu'une fois le mémoire validé par "
            "le Responsable Académique.")
        return redirect("etudes:soutenances")

    formulaire = SoutenanceForm(requete.POST or None, memoire=memoire)

    if requete.method == "POST" and formulaire.is_valid():
        with transaction.atomic():
            soutenance = formulaire.save(commit=False)
            soutenance.memoire = memoire
            soutenance.planifiee_par = requete.user
            soutenance.save()

            president = formulaire.cleaned_data.get("president")
            membres = list(formulaire.cleaned_data["membres"])

            # L'encadreur siège de droit, et son accord est acquis.
            if memoire.encadreur_id:
                ParticipationJury.objects.create(
                    soutenance=soutenance, enseignant=memoire.encadreur,
                    role=RoleJury.ENCADREUR, statut=StatutParticipation.ACCEPTE,
                    date_reponse=timezone.now())

            for enseignant in membres:
                role = (RoleJury.PRESIDENT if president and enseignant.pk == president.pk
                        else RoleJury.MEMBRE)
                ParticipationJury.objects.create(
                    soutenance=soutenance, enseignant=enseignant, role=role)
                Notification.envoyer(
                    enseignant, TypeNotification.JURY_INVITATION,
                    "Vous avez été sélectionné comme membre du jury",
                    f"Soutenance de {memoire.etudiant.nom_complet} — "
                    f"« {memoire.titre} », le "
                    f"{soutenance.date_soutenance:%d/%m/%Y} à "
                    f"{soutenance.heure_debut:%H:%M}, salle {soutenance.salle}.",
                    "/jury/")

            soutenance.rafraichir_statut()
            _prevenir_si_confirmee(soutenance)

        messages.success(
            requete,
            f"Soutenance programmée. {len(membres)} invitation(s) envoyée(s) "
            f"au jury.")
        return redirect("etudes:detail_soutenance", pk=soutenance.pk)

    return render(requete, "etudes/planifier.html", {
        "rubrique": "soutenances", "memoire": memoire, "formulaire": formulaire,
    })


def _prevenir_si_confirmee(soutenance):
    """
    Quand tous les jurys ont accepté, l'étudiant et l'encadreur sont prévenus.

    La notification porte la date, l'heure, la salle et la liste du jury :
    elle doit suffire à elle seule, sans que le destinataire ait à ouvrir
    une autre page.
    """
    # Le passage du mémoire en « soutenance programmée » est fait par
    # Soutenance.rafraichir_statut() : ne reste ici que l'information des
    # personnes concernées.
    if soutenance.statut != StatutSoutenance.CONFIRMEE:
        return

    jury = ", ".join(
        f"{m.enseignant.nom_complet} ({m.get_role_display()})"
        for m in soutenance.membres.filter(statut=StatutParticipation.ACCEPTE)
                                   .select_related("enseignant"))
    message = (f"Date : {soutenance.date_soutenance:%d/%m/%Y}\n"
               f"Heure : {soutenance.heure_debut:%H:%M} – {soutenance.heure_fin:%H:%M}\n"
               f"Salle : {soutenance.salle}\n"
               f"Jury : {jury}")

    for destinataire, lien in ((soutenance.memoire.etudiant, "/soutenances/ma-soutenance/"),
                               (soutenance.memoire.encadreur, "/jury/")):
        Notification.envoyer(
            destinataire, TypeNotification.SOUTENANCE_PROGRAMMEE,
            "Votre soutenance est programmée", message, lien)


@resp_etudes_requis
def detail_soutenance(requete, pk):
    soutenance = get_object_or_404(
        Soutenance.objects.select_related("memoire", "memoire__etudiant",
                                          "memoire__encadreur", "salle"), pk=pk)
    return render(requete, "etudes/detail_soutenance.html", {
        "rubrique": "soutenances", "soutenance": soutenance,
        "membres": soutenance.participations,
        "formulaire_remplacant": RemplacantForm(soutenance=soutenance),
        "formulaire_resultat": ResultatSoutenanceForm(),
        "evaluations": [m.evaluation for m in soutenance.membres.all()
                        if hasattr(m, "evaluation")],
    })


@resp_etudes_requis
def remplacer_membre(requete, pk):
    """Remplacement d'un membre du jury qui a refusé."""
    participation = get_object_or_404(
        ParticipationJury.objects.select_related("soutenance"), pk=pk)
    soutenance = participation.soutenance

    if requete.method != "POST":
        return redirect("etudes:detail_soutenance", pk=soutenance.pk)

    if participation.statut != StatutParticipation.REFUSE:
        messages.warning(requete, "Seul un membre ayant refusé peut être remplacé.")
        return redirect("etudes:detail_soutenance", pk=soutenance.pk)

    formulaire = RemplacantForm(requete.POST, soutenance=soutenance)
    if not formulaire.is_valid():
        messages.error(requete, "Choisissez un enseignant remplaçant.")
        return redirect("etudes:detail_soutenance", pk=soutenance.pk)

    remplacant = formulaire.cleaned_data["remplacant"]
    with transaction.atomic():
        participation.statut = StatutParticipation.REMPLACE
        participation.save(update_fields=["statut"])
        nouvelle = ParticipationJury.objects.create(
            soutenance=soutenance, enseignant=remplacant,
            role=participation.role if participation.role != RoleJury.ENCADREUR
            else RoleJury.MEMBRE,
            remplace=participation)
        Notification.envoyer(
            remplacant, TypeNotification.JURY_INVITATION,
            "Vous avez été sélectionné comme membre du jury",
            f"En remplacement de {participation.enseignant.nom_complet}. "
            f"Soutenance de {soutenance.memoire.etudiant.nom_complet} le "
            f"{soutenance.date_soutenance:%d/%m/%Y} à "
            f"{soutenance.heure_debut:%H:%M}, salle {soutenance.salle}.", "/jury/")
        soutenance.rafraichir_statut()
        _prevenir_si_confirmee(soutenance)

    messages.success(requete, f"{remplacant.nom_complet} a été invité en remplacement.")
    return redirect("etudes:detail_soutenance", pk=soutenance.pk)


@resp_etudes_requis
def cloturer_soutenance(requete, pk):
    """Enregistrement du résultat après la séance."""
    soutenance = get_object_or_404(
        Soutenance.objects.select_related("memoire", "memoire__etudiant"), pk=pk)

    if requete.method != "POST":
        return redirect("etudes:detail_soutenance", pk=pk)

    formulaire = ResultatSoutenanceForm(requete.POST)
    if not formulaire.is_valid():
        for erreurs in formulaire.errors.values():
            for erreur in erreurs:
                messages.error(requete, erreur)
        return redirect("etudes:detail_soutenance", pk=pk)

    from apps.memories.models import DecisionMemoire

    with transaction.atomic():
        note = formulaire.cleaned_data["note_finale"]
        soutenance.note_finale = note
        soutenance.mention = mention_pour_note(note)
        soutenance.deliberation = formulaire.cleaned_data.get("deliberation", "")
        soutenance.statut = StatutSoutenance.TENUE
        soutenance.date_tenue = timezone.now()
        soutenance.save()

        memoire = soutenance.memoire
        memoire.statut = StatutMemoire.SOUTENU
        memoire.save(update_fields=["statut"])

        DecisionMemoire.tracer(
            memoire, requete.user, DecisionMemoire.Etape.JURY,
            DecisionMemoire.Sens.SOUTENANCE,
            f"Soutenance tenue — note {note}/20, mention {soutenance.mention}",
            soutenance.deliberation)

        Notification.envoyer(
            memoire.etudiant, TypeNotification.INFORMATION,
            "Résultat de votre soutenance",
            f"Note : {note}/20 — mention {soutenance.mention}. Vous pouvez "
            f"maintenant déposer votre version finale corrigée.", "/memoire/")
        Notification.envoyer(
            memoire.encadreur, TypeNotification.INFORMATION,
            "Soutenance tenue",
            f"{memoire.etudiant.nom_complet} a obtenu {note}/20 "
            f"(mention {soutenance.mention}).", "/encadreur/memoires/")

    messages.success(
        requete, f"Résultat enregistré : {note}/20, mention {soutenance.mention}.")
    return redirect("etudes:detail_soutenance", pk=pk)


# ==========================================================================
# Archivage
# ==========================================================================
@resp_etudes_requis
def archivage(requete):
    a_archiver = (Memoire.objects.filter(statut=StatutMemoire.FINALE_VALIDEE_ENCADREUR)
                  .select_related("etudiant", "encadreur", "annee_academique"))
    deja = (MemoireArchive.objects.filter(origine=MemoireArchive.Origine.PLATEFORME)
            .select_related("etudiant"))

    return render(requete, "etudes/archivage.html", {
        "rubrique": "archivage", "a_archiver": a_archiver,
        "archives": deja[:10], "total_archives": MemoireArchive.objects.count(),
    })


@resp_etudes_requis
def archiver_memoire(requete, pk):
    memoire = get_object_or_404(Memoire, pk=pk)
    if requete.method != "POST":
        return redirect("etudes:archivage")
    if not memoire.attend_archivage:
        messages.warning(
            requete,
            "Ce mémoire ne peut être archivé qu'après validation de sa version "
            "finale par l'encadreur.")
        return redirect("etudes:archivage")

    try:
        archive = archiver(memoire, requete.user)
    except ValueError as erreur:
        messages.error(requete, str(erreur))
        return redirect("etudes:archivage")

    messages.success(
        requete,
        f"« {archive.titre} » figure désormais dans la bibliothèque numérique.")
    return redirect("etudes:archivage")


@resp_etudes_requis
def importer_archive(requete):
    """Ajout manuel d'un mémoire d'une promotion antérieure."""
    formulaire = ImportArchiveForm(requete.POST or None, requete.FILES or None)

    if requete.method == "POST" and formulaire.is_valid():
        archive = formulaire.save(archive_par=requete.user)
        messages.success(
            requete,
            f"« {archive.titre} » a été ajouté à la bibliothèque.")
        return redirect("etudes:importer_archive")

    return render(requete, "etudes/importer_archive.html", {
        "rubrique": "import", "formulaire": formulaire,
        "recents": MemoireArchive.objects.filter(
            origine=MemoireArchive.Origine.IMPORT)[:8],
        "total_imports": MemoireArchive.objects.filter(
            origine=MemoireArchive.Origine.IMPORT).count(),
    })


# ==========================================================================
# Téléchargement
# ==========================================================================
@resp_etudes_requis
def telecharger_version(requete, pk):
    version = get_object_or_404(
        VersionMemoire.objects.select_related("memoire"), pk=pk)
    if not version.fichier or not version.fichier.storage.exists(version.fichier.name):
        raise Http404("Le fichier de cette version est introuvable.")
    return FileResponse(
        version.fichier.open("rb"), as_attachment=True,
        filename=version.nom_original or os.path.basename(version.fichier.name))
