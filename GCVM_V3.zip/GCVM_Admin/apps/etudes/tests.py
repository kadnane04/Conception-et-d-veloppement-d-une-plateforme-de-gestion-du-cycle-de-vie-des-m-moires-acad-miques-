"""
Tests du cycle complet — phase 3.

Ils suivent un mémoire de sa validation de thème jusqu'à son archivage, en
vérifiant à chaque étape que les bonnes personnes sont prévenues, que les
verrous tiennent, et qu'aucun acteur ne peut agir hors de son tour.
"""

from datetime import date, time, timedelta

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from apps.accounts.models import (
    Filiere, Grade, ProfilEtudiant, ProfilProfesseur, ProfilResponsableAcademique,
    ProfilResponsableEtudes, Role, StatutProfesseur, Utilisateur,
)
from apps.archives.models import Consultation, MemoireArchive, NiveauAcces
from apps.defenses.models import (
    Evaluation, ParticipationJury, RoleJury, Salle, Soutenance, StatutParticipation,
    StatutSoutenance, mention_pour_note,
)
from apps.memories.models import (
    AnneeAcademique, DecisionMemoire, Memoire, StatutMemoire, VersionMemoire,
)
from apps.memories.services import (
    archiver, rejeter_par_academique, transmettre, valider_par_academique,
    valider_par_encadreur, valider_version_finale,
)
from apps.notifications.models import Notification
from apps.supervision.models import DemandeEncadrement, StatutDemande
from apps.themes.models import CategorieTheme, StatutTheme, Theme

MDP = "Plateforme@2026"


def pdf(nom="memoire.pdf"):
    return SimpleUploadedFile(nom, b"%PDF-1.4\n" + b"0" * 2000,
                              content_type="application/pdf")


class BaseCycleTest(TestCase):
    """Un dossier complet, prêt à être poussé d'étape en étape."""

    def setUp(self):
        self.etudiant = self._compte("ama.kossi@lbs.com", "KOSSI", "Ama", Role.ETUDIANT)
        ProfilEtudiant.objects.create(
            utilisateur=self.etudiant, filiere=Filiere.MANAGEMENT, matricule="LBS-001")

        self.encadreur = self._professeur("yao.mensah@lbs.com", "MENSAH", "Yao",
                                          StatutProfesseur.ENCADREUR)
        self.jure1 = self._professeur("sena.afi@lbs.com", "AFI", "Sena",
                                      StatutProfesseur.JURY)
        self.jure2 = self._professeur("komi.bawa@lbs.com", "BAWA", "Komi",
                                      StatutProfesseur.ENCADREUR_JURY)
        self.jure3 = self._professeur("afiwa.sossou@lbs.com", "SOSSOU", "Afiwa",
                                      StatutProfesseur.AUCUN)

        self.resp_etudes = self._compte("yawa.attisso@lbs.com", "ATTISSO", "Yawa",
                                        Role.RESP_ETUDES)
        ProfilResponsableEtudes.objects.create(
            utilisateur=self.resp_etudes, grade=Grade.DOCTEUR)
        self.resp_academique = self._compte("elom.kpodar@lbs.com", "KPODAR", "Elom",
                                            Role.RESP_ACADEMIQUE)
        ProfilResponsableAcademique.objects.create(
            utilisateur=self.resp_academique, grade=Grade.PROFESSEUR_TITULAIRE)

        self.annee = AnneeAcademique.objects.create(libelle="2025-2026", est_active=True)
        self.salle = Salle.objects.create(nom="Amphi A", capacite=100)
        self.categorie = CategorieTheme.objects.get(nom="Gestion")

    def _compte(self, email, nom, prenom, role):
        return Utilisateur.objects.create_user(
            email=email, password=MDP, nom=nom, prenom=prenom, role=role)

    def _professeur(self, email, nom, prenom, statut):
        compte = self._compte(email, nom, prenom, Role.PROFESSEUR)
        ProfilProfesseur.objects.create(
            utilisateur=compte, grade=Grade.DOCTEUR, specialite="Gestion",
            statut=statut, quota_encadrement=5)
        return compte

    # -- fabriques ---------------------------------------------------------
    def theme_valide(self):
        theme = Theme.objects.create(
            etudiant=self.etudiant,
            titre="Contribution du contrôle de gestion à la performance des PME",
            description="d", contexte="c", problematique="p", objectifs="o",
            mots_cles="gestion, PME", statut=StatutTheme.VALIDE,
            date_decision=timezone.now(), decide_par=self.resp_etudes)
        theme.categories.add(self.categorie)
        return theme

    def memoire_depose(self):
        theme = self.theme_valide()
        demande = DemandeEncadrement.objects.create(
            etudiant=self.etudiant, encadreur=self.encadreur, theme=theme)
        demande.accepter()
        memoire = Memoire.objects.create(
            etudiant=self.etudiant, theme=theme, encadreur=self.encadreur,
            annee_academique=self.annee, titre=theme.titre, resume="R" * 150,
            statut=StatutMemoire.DEPOSE, date_dernier_depot=timezone.now())
        VersionMemoire.objects.create(
            memoire=memoire, numero=1, fichier=pdf(), taille_octets=2009,
            nom_original="memoire.pdf", depose_par=self.etudiant)
        return memoire

    def tearDown(self):
        for version in VersionMemoire.objects.all():
            version.fichier.delete(save=False)
        for archive in MemoireArchive.objects.all():
            archive.fichier.delete(save=False)


# ==========================================================================
# Le cycle, d'un bout à l'autre
# ==========================================================================
class CycleCompletTest(BaseCycleTest):

    def test_parcours_du_depot_a_l_archivage(self):
        """Le scénario central : chaque étape déverrouille la suivante."""
        memoire = self.memoire_depose()
        self.assertEqual(memoire.statut, StatutMemoire.DEPOSE)
        self.assertTrue(memoire.attend_encadreur)

        # 1. L'encadreur valide
        valider_par_encadreur(memoire, self.encadreur, "Travail sérieux.")
        memoire.refresh_from_db()
        self.assertEqual(memoire.statut, StatutMemoire.VALIDE_ENCADREUR)
        self.assertTrue(memoire.attend_transmission)

        # 2. Le Responsable des Études transmet
        transmettre(memoire, self.resp_etudes)
        memoire.refresh_from_db()
        self.assertEqual(memoire.statut, StatutMemoire.TRANSMIS)
        self.assertTrue(memoire.attend_academique)

        # 3. Le Responsable Académique valide
        valider_par_academique(memoire, self.resp_academique)
        memoire.refresh_from_db()
        self.assertEqual(memoire.statut, StatutMemoire.VALIDE_RESP_ACADEMIQUE)
        self.assertTrue(memoire.attend_planification)

        # 4. Soutenance programmée, jury complet
        soutenance = self._programmer(memoire)
        self.assertEqual(soutenance.statut, StatutSoutenance.CONFIRMEE)

        # 5. Soutenance tenue
        soutenance.note_finale = 15
        soutenance.mention = mention_pour_note(15)
        soutenance.statut = StatutSoutenance.TENUE
        soutenance.save()
        memoire.statut = StatutMemoire.SOUTENU
        memoire.save()
        self.assertTrue(memoire.attend_version_finale)

        # 6. Version finale, validée par l'encadreur
        version = VersionMemoire.objects.create(
            memoire=memoire, numero=2, fichier=pdf("finale.pdf"),
            taille_octets=2009, nom_original="finale.pdf", est_finale=True,
            depose_par=self.etudiant)
        memoire.statut = StatutMemoire.FINALE_DEPOSEE
        memoire.save()
        valider_version_finale(memoire, self.encadreur)
        memoire.refresh_from_db()
        self.assertTrue(memoire.attend_archivage)

        # 7. Archivage
        archive = archiver(memoire, self.resp_etudes)
        memoire.refresh_from_db()
        self.assertEqual(memoire.statut, StatutMemoire.ARCHIVE)
        self.assertEqual(archive.auteur_nom, self.etudiant.nom_complet)
        self.assertEqual(archive.annee, "2025-2026")
        self.assertEqual(archive.note_finale, 15)

        # Le dossier a laissé une trace à chaque étape.
        self.assertGreaterEqual(memoire.decisions.count(), 5)

    def _programmer(self, memoire):
        soutenance = Soutenance.objects.create(
            memoire=memoire, date_soutenance=timezone.localdate() + timedelta(days=20),
            heure_debut=time(9, 0), heure_fin=time(10, 0), salle=self.salle,
            planifiee_par=self.resp_etudes)
        ParticipationJury.objects.create(
            soutenance=soutenance, enseignant=self.encadreur, role=RoleJury.ENCADREUR,
            statut=StatutParticipation.ACCEPTE)
        for enseignant, role in [(self.jure1, RoleJury.PRESIDENT),
                                 (self.jure2, RoleJury.MEMBRE)]:
            ParticipationJury.objects.create(
                soutenance=soutenance, enseignant=enseignant, role=role).accepter()
        soutenance.refresh_from_db()
        return soutenance


# ==========================================================================
# Notifications croisées
# ==========================================================================
class NotificationsDuCycleTest(BaseCycleTest):

    def test_validation_encadreur_previent_etudiant_et_resp_etudes(self):
        memoire = self.memoire_depose()
        valider_par_encadreur(memoire, self.encadreur)
        self.assertTrue(Notification.objects.pour(self.etudiant).exists())
        self.assertTrue(Notification.objects.pour(self.resp_etudes).exists())

    def test_transmission_previent_le_resp_academique(self):
        memoire = self.memoire_depose()
        valider_par_encadreur(memoire, self.encadreur)
        transmettre(memoire, self.resp_etudes)
        self.assertTrue(Notification.objects.pour(self.resp_academique).exists())

    def test_validation_academique_previent_les_trois(self):
        """Le cahier des charges l'exige explicitement."""
        memoire = self.memoire_depose()
        valider_par_encadreur(memoire, self.encadreur)
        transmettre(memoire, self.resp_etudes)
        Notification.objects.all().delete()

        valider_par_academique(memoire, self.resp_academique)
        for destinataire in (self.etudiant, self.encadreur, self.resp_etudes):
            self.assertTrue(
                Notification.objects.pour(destinataire).exists(),
                f"{destinataire} n'a pas été prévenu.")

    def test_rejet_academique_transmet_le_motif_aux_trois(self):
        memoire = self.memoire_depose()
        valider_par_encadreur(memoire, self.encadreur)
        transmettre(memoire, self.resp_etudes)
        Notification.objects.all().delete()

        rejeter_par_academique(memoire, self.resp_academique,
                               "Bibliographie insuffisante.")
        for destinataire in (self.etudiant, self.encadreur, self.resp_etudes):
            messages = Notification.objects.pour(destinataire)
            self.assertTrue(messages.exists(), str(destinataire))
            self.assertIn("Bibliographie insuffisante",
                          " ".join(n.message for n in messages))


# ==========================================================================
# Espace Encadreur
# ==========================================================================
class EspaceEncadreurTest(BaseCycleTest):

    def setUp(self):
        super().setUp()
        self.client.force_login(self.encadreur)

    def test_tableau_de_bord(self):
        self.assertEqual(
            self.client.get(reverse("encadreur:tableau_de_bord")).status_code, 200)

    def test_accepter_une_demande(self):
        theme = self.theme_valide()
        demande = DemandeEncadrement.objects.create(
            etudiant=self.etudiant, encadreur=self.encadreur, theme=theme)
        self.client.post(
            reverse("encadreur:repondre_demande", args=[demande.pk, "accepter"]),
            follow=True)
        demande.refresh_from_db()
        self.assertEqual(demande.statut, StatutDemande.ACCEPTE)
        self.assertTrue(Notification.objects.pour(self.etudiant).exists())

    def test_refus_sans_motif_refuse(self):
        theme = self.theme_valide()
        demande = DemandeEncadrement.objects.create(
            etudiant=self.etudiant, encadreur=self.encadreur, theme=theme)
        self.client.post(
            reverse("encadreur:repondre_demande", args=[demande.pk, "refuser"]),
            {"motif": ""}, follow=True)
        demande.refresh_from_db()
        self.assertEqual(demande.statut, StatutDemande.EN_ATTENTE)

    def test_refus_avec_motif(self):
        theme = self.theme_valide()
        demande = DemandeEncadrement.objects.create(
            etudiant=self.etudiant, encadreur=self.encadreur, theme=theme)
        self.client.post(
            reverse("encadreur:repondre_demande", args=[demande.pk, "refuser"]),
            {"motif": "Quota atteint."}, follow=True)
        demande.refresh_from_db()
        self.assertEqual(demande.statut, StatutDemande.REFUSE)
        self.assertEqual(demande.motif_refus, "Quota atteint.")

    def test_valider_un_memoire(self):
        memoire = self.memoire_depose()
        self.client.post(
            reverse("encadreur:decider_memoire", args=[memoire.pk, "valider"]),
            {"commentaire": "Bon travail."}, follow=True)
        memoire.refresh_from_db()
        self.assertEqual(memoire.statut, StatutMemoire.VALIDE_ENCADREUR)

    def test_rejet_sans_motif_refuse(self):
        memoire = self.memoire_depose()
        self.client.post(
            reverse("encadreur:decider_memoire", args=[memoire.pk, "rejeter"]),
            {"commentaire": ""}, follow=True)
        memoire.refresh_from_db()
        self.assertEqual(memoire.statut, StatutMemoire.DEPOSE)

    def test_un_encadreur_ne_voit_pas_le_memoire_d_un_autre(self):
        memoire = self.memoire_depose()
        self.client.force_login(self.jure1)
        self.assertEqual(self.client.get(
            reverse("encadreur:detail_memoire", args=[memoire.pk])).status_code, 404)

    def test_telechargement_refuse_a_un_tiers(self):
        memoire = self.memoire_depose()
        version = memoire.versions.first()
        self.client.force_login(self.jure1)
        self.assertEqual(self.client.get(
            reverse("encadreur:telecharger_version", args=[version.pk])).status_code, 404)

    def test_decision_ignoree_en_get(self):
        memoire = self.memoire_depose()
        self.client.get(reverse("encadreur:decider_memoire", args=[memoire.pk, "valider"]))
        memoire.refresh_from_db()
        self.assertEqual(memoire.statut, StatutMemoire.DEPOSE)


# ==========================================================================
# Espace Responsable des Études
# ==========================================================================
class EspaceEtudesTest(BaseCycleTest):

    def setUp(self):
        super().setUp()
        self.client.force_login(self.resp_etudes)

    def test_tableau_de_bord(self):
        self.assertEqual(
            self.client.get(reverse("etudes:tableau_de_bord")).status_code, 200)

    def test_valider_un_theme(self):
        theme = Theme.objects.create(
            etudiant=self.etudiant, titre="Un sujet suffisamment long pour passer",
            description="d", contexte="c", problematique="p", objectifs="o",
            mots_cles="m")
        theme.categories.add(self.categorie)
        self.client.post(reverse("etudes:detail_theme", args=[theme.pk]),
                         {"decision": "valider", "motif": ""}, follow=True)
        theme.refresh_from_db()
        self.assertEqual(theme.statut, StatutTheme.VALIDE)
        self.assertEqual(theme.decide_par, self.resp_etudes)
        self.assertTrue(Notification.objects.pour(self.etudiant).exists())

    def test_rejet_de_theme_sans_motif_refuse(self):
        theme = Theme.objects.create(
            etudiant=self.etudiant, titre="Un sujet suffisamment long pour passer",
            description="d", contexte="c", problematique="p", objectifs="o",
            mots_cles="m")
        self.client.post(reverse("etudes:detail_theme", args=[theme.pk]),
                         {"decision": "rejeter", "motif": "   "}, follow=True)
        theme.refresh_from_db()
        self.assertEqual(theme.statut, StatutTheme.EN_ATTENTE)

    def test_rejet_de_theme_avec_motif(self):
        theme = Theme.objects.create(
            etudiant=self.etudiant, titre="Un sujet suffisamment long pour passer",
            description="d", contexte="c", problematique="p", objectifs="o",
            mots_cles="m")
        self.client.post(reverse("etudes:detail_theme", args=[theme.pk]),
                         {"decision": "rejeter", "motif": "Périmètre trop large."},
                         follow=True)
        theme.refresh_from_db()
        self.assertEqual(theme.statut, StatutTheme.REJETE)
        self.assertEqual(theme.motif_rejet, "Périmètre trop large.")

    def test_transmission(self):
        memoire = self.memoire_depose()
        valider_par_encadreur(memoire, self.encadreur)
        self.client.post(reverse("etudes:transmettre_memoire", args=[memoire.pk]),
                         follow=True)
        memoire.refresh_from_db()
        self.assertEqual(memoire.statut, StatutMemoire.TRANSMIS)
        self.assertEqual(memoire.transmis_par, self.resp_etudes)

    def test_transmission_impossible_avant_validation_encadreur(self):
        memoire = self.memoire_depose()
        self.client.post(reverse("etudes:transmettre_memoire", args=[memoire.pk]),
                         follow=True)
        memoire.refresh_from_db()
        self.assertEqual(memoire.statut, StatutMemoire.DEPOSE)

    def test_import_d_un_ancien_memoire(self):
        self.client.post(reverse("etudes:importer_archive"), {
            "titre": "L'impact de la microfinance sur l'entrepreneuriat féminin",
            "auteur_nom": "ADJAVON Afi", "encadreur_nom": "Dr. KOUASSI",
            "annee": "2022-2023", "filiere": "Management",
            "resume": "R" * 120, "mots_cles": "microfinance, Togo",
            "fichier": pdf("ancien.pdf"),
            "niveau_acces": NiveauAcces.INTERNE}, follow=True)
        archive = MemoireArchive.objects.get(auteur_nom="ADJAVON Afi")
        self.assertEqual(archive.origine, MemoireArchive.Origine.IMPORT)
        self.assertEqual(archive.archive_par, self.resp_etudes)

    def test_import_resume_trop_court_refuse(self):
        self.client.post(reverse("etudes:importer_archive"), {
            "titre": "Un titre", "auteur_nom": "X", "annee": "2020-2021",
            "resume": "Trop court.", "fichier": pdf(),
            "niveau_acces": NiveauAcces.INTERNE}, follow=True)
        self.assertEqual(MemoireArchive.objects.count(), 0)


# ==========================================================================
# Soutenances
# ==========================================================================
class SoutenanceTest(BaseCycleTest):

    def setUp(self):
        super().setUp()
        self.memoire = self.memoire_depose()
        valider_par_encadreur(self.memoire, self.encadreur)
        transmettre(self.memoire, self.resp_etudes)
        valider_par_academique(self.memoire, self.resp_academique)
        self.memoire.refresh_from_db()
        self.client.force_login(self.resp_etudes)

    def donnees(self, **extra):
        donnees = {
            "date_soutenance": (timezone.localdate() + timedelta(days=20)).isoformat(),
            "heure_debut": "09:00", "heure_fin": "10:00", "salle": self.salle.pk,
            "membres": [self.jure1.pk, self.jure2.pk],
            "president": self.jure1.pk,
        }
        donnees.update(extra)
        return donnees

    def test_planification(self):
        self.client.post(reverse("etudes:planifier", args=[self.memoire.pk]),
                         self.donnees(), follow=True)
        soutenance = Soutenance.objects.get(memoire=self.memoire)
        # Encadreur membre de droit + les deux invités.
        self.assertEqual(soutenance.membres.count(), 3)
        self.assertEqual(soutenance.statut, StatutSoutenance.EN_COMPOSITION)

    def test_l_encadreur_siege_de_droit_et_a_deja_accepte(self):
        self.client.post(reverse("etudes:planifier", args=[self.memoire.pk]),
                         self.donnees(), follow=True)
        soutenance = Soutenance.objects.get(memoire=self.memoire)
        membre = soutenance.membres.get(enseignant=self.encadreur)
        self.assertEqual(membre.role, RoleJury.ENCADREUR)
        self.assertEqual(membre.statut, StatutParticipation.ACCEPTE)

    def test_tout_enseignant_peut_etre_choisi(self):
        """Y compris celui dont le profil ne porte aucune responsabilité."""
        self.client.post(
            reverse("etudes:planifier", args=[self.memoire.pk]),
            self.donnees(membres=[self.jure1.pk, self.jure3.pk], president=self.jure1.pk),
            follow=True)
        soutenance = Soutenance.objects.get(memoire=self.memoire)
        self.assertTrue(soutenance.membres.filter(enseignant=self.jure3).exists())

    def test_jury_trop_petit_refuse(self):
        self.client.post(
            reverse("etudes:planifier", args=[self.memoire.pk]),
            self.donnees(membres=[self.jure1.pk], president=self.jure1.pk), follow=True)
        self.assertFalse(Soutenance.objects.filter(memoire=self.memoire).exists())

    def test_les_membres_sont_invites(self):
        self.client.post(reverse("etudes:planifier", args=[self.memoire.pk]),
                         self.donnees(), follow=True)
        for enseignant in (self.jure1, self.jure2):
            self.assertTrue(Notification.objects.pour(enseignant).exists(),
                            str(enseignant))

    def test_confirmation_quand_tous_ont_accepte(self):
        self.client.post(reverse("etudes:planifier", args=[self.memoire.pk]),
                         self.donnees(), follow=True)
        soutenance = Soutenance.objects.get(memoire=self.memoire)
        for membre in soutenance.membres.filter(statut=StatutParticipation.EN_ATTENTE):
            membre.accepter()
        soutenance.refresh_from_db()
        self.assertEqual(soutenance.statut, StatutSoutenance.CONFIRMEE)

        self.memoire.refresh_from_db()
        self.assertEqual(self.memoire.statut, StatutMemoire.SOUTENANCE_PLANIFIEE)

    def test_un_refus_empeche_la_confirmation(self):
        self.client.post(reverse("etudes:planifier", args=[self.memoire.pk]),
                         self.donnees(), follow=True)
        soutenance = Soutenance.objects.get(memoire=self.memoire)
        membres = list(soutenance.membres.filter(statut=StatutParticipation.EN_ATTENTE))
        membres[0].refuser("Indisponible.")
        membres[1].accepter()
        soutenance.refresh_from_db()
        self.assertEqual(soutenance.statut, StatutSoutenance.EN_COMPOSITION)

    def test_remplacement_d_un_membre_ayant_refuse(self):
        self.client.post(reverse("etudes:planifier", args=[self.memoire.pk]),
                         self.donnees(), follow=True)
        soutenance = Soutenance.objects.get(memoire=self.memoire)
        membres = list(soutenance.membres.filter(statut=StatutParticipation.EN_ATTENTE))
        refusant, autre = membres[0], membres[1]
        refusant.refuser("Indisponible.")
        autre.accepter()

        self.client.post(reverse("etudes:remplacer_membre", args=[refusant.pk]),
                         {"remplacant": self.jure3.pk}, follow=True)
        refusant.refresh_from_db()
        self.assertEqual(refusant.statut, StatutParticipation.REMPLACE)
        remplacant = soutenance.membres.get(enseignant=self.jure3)
        self.assertEqual(remplacant.remplace, refusant)

        remplacant.accepter()
        soutenance.refresh_from_db()
        self.assertEqual(soutenance.statut, StatutSoutenance.CONFIRMEE)

    def test_salle_deja_occupee_refusee(self):
        self.client.post(reverse("etudes:planifier", args=[self.memoire.pk]),
                         self.donnees(), follow=True)

        # Un second dossier, même salle, créneau qui chevauche.
        autre_etudiant = Utilisateur.objects.create_user(
            email="autre@lbs.com", password=MDP, nom="AUTRE", prenom="X",
            role=Role.ETUDIANT)
        ProfilEtudiant.objects.create(utilisateur=autre_etudiant,
                                      filiere=Filiere.MANAGEMENT)
        theme = Theme.objects.create(
            etudiant=autre_etudiant, titre="Un autre sujet parfaitement distinct",
            description="d", contexte="c", problematique="p", objectifs="o",
            mots_cles="m", statut=StatutTheme.VALIDE)
        autre = Memoire.objects.create(
            etudiant=autre_etudiant, theme=theme, encadreur=self.encadreur,
            annee_academique=self.annee, titre=theme.titre, resume="R" * 150,
            statut=StatutMemoire.VALIDE_RESP_ACADEMIQUE)

        reponse = self.client.post(
            reverse("etudes:planifier", args=[autre.pk]),
            self.donnees(heure_debut="09:30", heure_fin="10:30"), follow=True)
        self.assertContains(reponse, "déjà occupée")
        self.assertFalse(Soutenance.objects.filter(memoire=autre).exists())

    def test_cloture_et_mention(self):
        self.client.post(reverse("etudes:planifier", args=[self.memoire.pk]),
                         self.donnees(), follow=True)
        soutenance = Soutenance.objects.get(memoire=self.memoire)
        for membre in soutenance.membres.filter(statut=StatutParticipation.EN_ATTENTE):
            membre.accepter()

        self.client.post(reverse("etudes:cloturer_soutenance", args=[soutenance.pk]),
                         {"note_finale": "16.5", "deliberation": "Très bonne défense."},
                         follow=True)
        soutenance.refresh_from_db()
        self.assertEqual(soutenance.statut, StatutSoutenance.TENUE)
        self.assertEqual(soutenance.mention, "Très bien")
        self.memoire.refresh_from_db()
        self.assertEqual(self.memoire.statut, StatutMemoire.SOUTENU)

    def test_bareme_des_mentions(self):
        for note, attendue in [(18, "Très bien"), (15, "Bien"), (13, "Assez bien"),
                               (11, "Passable"), (8, "Insuffisant")]:
            self.assertEqual(mention_pour_note(note), attendue, note)


# ==========================================================================
# Espace Jury
# ==========================================================================
class EspaceJuryTest(BaseCycleTest):

    def setUp(self):
        super().setUp()
        self.memoire = self.memoire_depose()
        self.soutenance = Soutenance.objects.create(
            memoire=self.memoire,
            date_soutenance=timezone.localdate() + timedelta(days=15),
            heure_debut=time(9, 0), heure_fin=time(10, 0), salle=self.salle,
            planifiee_par=self.resp_etudes)
        self.participation = ParticipationJury.objects.create(
            soutenance=self.soutenance, enseignant=self.jure1, role=RoleJury.PRESIDENT)
        self.client.force_login(self.jure1)

    def test_liste_des_participations(self):
        reponse = self.client.get(reverse("jury:mes_soutenances"))
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, self.memoire.etudiant.nom)

    def test_avant_acceptation_le_document_reste_ferme(self):
        reponse = self.client.get(reverse("jury:detail", args=[self.participation.pk]))
        self.assertFalse(reponse.context["acces_complet"])
        version = self.memoire.versions.first()
        self.assertEqual(self.client.get(
            reverse("jury:telecharger", args=[version.pk])).status_code, 404)

    def test_apres_acceptation_le_document_s_ouvre(self):
        self.client.post(
            reverse("jury:repondre", args=[self.participation.pk, "accepter"]),
            follow=True)
        self.participation.refresh_from_db()
        self.assertEqual(self.participation.statut, StatutParticipation.ACCEPTE)

        reponse = self.client.get(reverse("jury:detail", args=[self.participation.pk]))
        self.assertTrue(reponse.context["acces_complet"])
        version = self.memoire.versions.first()
        self.assertEqual(self.client.get(
            reverse("jury:telecharger", args=[version.pk])).status_code, 200)

    def test_refus_sans_motif_refuse(self):
        self.client.post(
            reverse("jury:repondre", args=[self.participation.pk, "refuser"]),
            {"motif": ""}, follow=True)
        self.participation.refresh_from_db()
        self.assertEqual(self.participation.statut, StatutParticipation.EN_ATTENTE)

    def test_refus_previent_le_resp_etudes(self):
        self.client.post(
            reverse("jury:repondre", args=[self.participation.pk, "refuser"]),
            {"motif": "Indisponible."}, follow=True)
        self.assertTrue(Notification.objects.pour(self.resp_etudes).exists())

    def test_observations(self):
        self.participation.accepter()
        self.client.post(reverse("jury:observations", args=[self.participation.pk]),
                         {"observations": "Vérifier le chapitre 3."}, follow=True)
        self.participation.refresh_from_db()
        self.assertEqual(self.participation.observations, "Vérifier le chapitre 3.")

    def test_evaluation(self):
        self.participation.accepter()
        self.client.post(reverse("jury:evaluer", args=[self.participation.pk]),
                         {"note": "15.5", "commentaire": "Bonne maîtrise.",
                          "recommandations": "Revoir la conclusion."}, follow=True)
        evaluation = Evaluation.objects.get(participation=self.participation)
        self.assertEqual(float(evaluation.note), 15.5)
        self.assertEqual(evaluation.mention, "Bien")

    def test_note_hors_bareme_refusee(self):
        self.participation.accepter()
        self.client.post(reverse("jury:evaluer", args=[self.participation.pk]),
                         {"note": "25"}, follow=True)
        self.assertFalse(Evaluation.objects.filter(
            participation=self.participation).exists())

    def test_un_enseignant_ne_voit_pas_le_jury_d_un_autre(self):
        self.client.force_login(self.jure2)
        self.assertEqual(self.client.get(
            reverse("jury:detail", args=[self.participation.pk])).status_code, 404)

    def test_un_enseignant_sans_responsabilite_peut_sieger(self):
        """« Tout enseignant peut devenir jury » — même statut AUCUN."""
        participation = ParticipationJury.objects.create(
            soutenance=self.soutenance, enseignant=self.jure3, role=RoleJury.MEMBRE)
        self.client.force_login(self.jure3)
        self.assertEqual(self.client.get(
            reverse("jury:detail", args=[participation.pk])).status_code, 200)

    def test_un_seul_compte_pour_encadrer_et_sieger(self):
        """Le point central : pas de second compte pour un second rôle."""
        participation = ParticipationJury.objects.create(
            soutenance=self.soutenance, enseignant=self.encadreur,
            role=RoleJury.ENCADREUR, statut=StatutParticipation.ACCEPTE)
        self.client.force_login(self.encadreur)
        self.assertEqual(self.client.get(
            reverse("encadreur:tableau_de_bord")).status_code, 200)
        self.assertEqual(self.client.get(
            reverse("jury:detail", args=[participation.pk])).status_code, 200)
        self.assertEqual(
            Utilisateur.objects.filter(email=self.encadreur.email).count(), 1)


# ==========================================================================
# Espace Responsable Académique
# ==========================================================================
class EspaceAcademiqueTest(BaseCycleTest):

    def setUp(self):
        super().setUp()
        self.memoire = self.memoire_depose()
        valider_par_encadreur(self.memoire, self.encadreur)
        transmettre(self.memoire, self.resp_etudes)
        self.memoire.refresh_from_db()
        self.client.force_login(self.resp_academique)

    def test_tableau_de_bord(self):
        self.assertEqual(
            self.client.get(reverse("academique:tableau_de_bord")).status_code, 200)

    def test_validation(self):
        self.client.post(
            reverse("academique:decider", args=[self.memoire.pk, "valider"]),
            {"commentaire": "Conforme."}, follow=True)
        self.memoire.refresh_from_db()
        self.assertEqual(self.memoire.statut, StatutMemoire.VALIDE_RESP_ACADEMIQUE)

    def test_rejet_sans_motif_refuse(self):
        self.client.post(
            reverse("academique:decider", args=[self.memoire.pk, "rejeter"]),
            {"commentaire": ""}, follow=True)
        self.memoire.refresh_from_db()
        self.assertEqual(self.memoire.statut, StatutMemoire.TRANSMIS)

    def test_pas_de_decision_avant_transmission(self):
        autre = Memoire.objects.create(
            etudiant=self.etudiant, theme=Theme.objects.create(
                etudiant=self.etudiant, titre="Un second sujet bien distinct du premier",
                description="d", contexte="c", problematique="p", objectifs="o",
                mots_cles="m"),
            encadreur=self.encadreur,
            annee_academique=AnneeAcademique.objects.create(libelle="2026-2027"),
            titre="Un second mémoire", resume="R" * 150,
            statut=StatutMemoire.DEPOSE)
        self.client.post(reverse("academique:decider", args=[autre.pk, "valider"]),
                         follow=True)
        autre.refresh_from_db()
        self.assertEqual(autre.statut, StatutMemoire.DEPOSE)


# ==========================================================================
# Bibliothèque
# ==========================================================================
class BibliothequeTest(BaseCycleTest):

    def setUp(self):
        super().setUp()
        self.archive = MemoireArchive.objects.create(
            titre="L'impact de la microfinance sur l'entrepreneuriat féminin",
            auteur_nom="ADJAVON Afi", encadreur_nom="Dr. KOUASSI",
            annee="2022-2023", filiere="Management", resume="R" * 120,
            mots_cles="microfinance, Togo", fichier=pdf("ancien.pdf"),
            nom_original="ancien.pdf", taille_octets=2009,
            origine=MemoireArchive.Origine.IMPORT, archive_par=self.resp_etudes)

    def test_ouverte_a_tous_les_roles(self):
        for compte in (self.etudiant, self.encadreur, self.resp_etudes,
                       self.resp_academique):
            self.client.force_login(compte)
            self.assertEqual(
                self.client.get(reverse("archives:bibliotheque")).status_code, 200,
                str(compte))

    def test_fermee_aux_visiteurs_anonymes(self):
        reponse = self.client.get(reverse("archives:bibliotheque"))
        self.assertEqual(reponse.status_code, 302)
        self.assertIn("connexion", reponse.url)

    def test_recherche(self):
        self.client.force_login(self.etudiant)
        self.assertContains(
            self.client.get(reverse("archives:bibliotheque") + "?q=microfinance"),
            "ADJAVON")
        self.assertNotContains(
            self.client.get(reverse("archives:bibliotheque") + "?q=zzzz"), "ADJAVON")

    def test_consultation_incremente_le_compteur(self):
        self.client.force_login(self.etudiant)
        self.client.get(reverse("archives:detail", args=[self.archive.pk]))
        self.archive.refresh_from_db()
        self.assertEqual(self.archive.nb_consultations, 1)
        self.assertTrue(Consultation.objects.filter(
            archive=self.archive, action=Consultation.Action.CONSULTATION).exists())

    def test_telechargement_incremente_son_propre_compteur(self):
        self.client.force_login(self.etudiant)
        reponse = self.client.get(reverse("archives:telecharger", args=[self.archive.pk]))
        self.assertEqual(reponse.status_code, 200)
        self.archive.refresh_from_db()
        self.assertEqual(self.archive.nb_telechargements, 1)

    def test_memoire_restreint_masque_aux_etudiants(self):
        self.archive.niveau_acces = NiveauAcces.RESTREINT
        self.archive.save()

        self.client.force_login(self.etudiant)
        self.assertNotContains(
            self.client.get(reverse("archives:bibliotheque")), "ADJAVON")
        self.assertEqual(self.client.get(
            reverse("archives:detail", args=[self.archive.pk])).status_code, 404)

        self.client.force_login(self.encadreur)
        self.assertContains(
            self.client.get(reverse("archives:bibliotheque")), "ADJAVON")

    def test_archive_reste_lisible_sans_compte_etudiant(self):
        """
        Une fiche importée n'a pas de compte associé : elle doit tout de même
        s'afficher entièrement.
        """
        self.assertIsNone(self.archive.etudiant)
        self.client.force_login(self.etudiant)
        reponse = self.client.get(reverse("archives:detail", args=[self.archive.pk]))
        self.assertContains(reponse, "ADJAVON Afi")
        self.assertContains(reponse, "2022-2023")


# ==========================================================================
# Version finale, côté étudiant
# ==========================================================================
class VersionFinaleTest(BaseCycleTest):

    def setUp(self):
        super().setUp()
        self.memoire = self.memoire_depose()
        self.memoire.statut = StatutMemoire.SOUTENU
        self.memoire.save()
        self.client.force_login(self.etudiant)

    def test_depot_de_la_version_finale(self):
        self.client.post(reverse("memoires:version_finale"), {
            "fichier": pdf("finale.pdf"),
            "commentaire": "Chapitre 2 repris, bibliographie complétée, "
                           "annexes ajoutées comme demandé par le jury."},
            follow=True)
        self.memoire.refresh_from_db()
        self.assertEqual(self.memoire.statut, StatutMemoire.FINALE_DEPOSEE)
        finale = self.memoire.derniere_version_finale
        self.assertIsNotNone(finale)
        self.assertEqual(finale.numero, 2)
        # La version précédente est conservée.
        self.assertEqual(self.memoire.nb_versions, 2)

    def test_commentaire_trop_court_refuse(self):
        self.client.post(reverse("memoires:version_finale"),
                         {"fichier": pdf("finale.pdf"), "commentaire": "Corrigé."},
                         follow=True)
        self.memoire.refresh_from_db()
        self.assertEqual(self.memoire.statut, StatutMemoire.SOUTENU)

    def test_depot_impossible_avant_la_soutenance(self):
        self.memoire.statut = StatutMemoire.DEPOSE
        self.memoire.save()
        self.client.post(reverse("memoires:version_finale"), {
            "fichier": pdf("finale.pdf"), "commentaire": "C" * 60}, follow=True)
        self.memoire.refresh_from_db()
        self.assertEqual(self.memoire.nb_versions, 1)

    def test_l_encadreur_est_prevenu(self):
        Notification.objects.all().delete()
        self.client.post(reverse("memoires:version_finale"), {
            "fichier": pdf("finale.pdf"), "commentaire": "C" * 60}, follow=True)
        self.assertTrue(Notification.objects.pour(self.encadreur).exists())


# ==========================================================================
# Cloisonnement des espaces
# ==========================================================================
class CloisonnementTest(BaseCycleTest):

    def test_chaque_role_est_renvoye_vers_son_espace(self):
        interdits = [
            (self.etudiant, "etudes:tableau_de_bord", "/etudiant/"),
            (self.etudiant, "academique:tableau_de_bord", "/etudiant/"),
            (self.etudiant, "encadreur:tableau_de_bord", "/etudiant/"),
            (self.encadreur, "etudes:tableau_de_bord", "/encadreur/"),
            (self.encadreur, "academique:tableau_de_bord", "/encadreur/"),
            (self.resp_etudes, "academique:tableau_de_bord", "/etudes/"),
            (self.resp_academique, "etudes:tableau_de_bord", "/academique/"),
        ]
        for compte, route, attendu in interdits:
            self.client.force_login(compte)
            reponse = self.client.get(reverse(route), follow=True)
            self.assertTrue(
                reponse.redirect_chain[-1][0].startswith(attendu),
                f"{compte} a atteint {route}")

    def test_aiguillage_apres_connexion(self):
        attendus = [
            (self.etudiant, "/etudiant/"),
            (self.encadreur, "/encadreur/"),
            (self.resp_etudes, "/etudes/"),
            (self.resp_academique, "/academique/"),
        ]
        for compte, destination in attendus:
            self.client.logout()
            reponse = self.client.post(reverse("comptes:connexion"), {
                "email": compte.email, "mot_de_passe": MDP}, follow=True)
            self.assertTrue(reponse.redirect_chain[-1][0].startswith(destination),
                            f"{compte} → {reponse.redirect_chain[-1][0]}")
