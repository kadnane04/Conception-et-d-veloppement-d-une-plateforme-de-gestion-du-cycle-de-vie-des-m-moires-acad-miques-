from django.apps import AppConfig


class EtudesConfig(AppConfig):
    """Espace Responsable des Études : thèmes, transmission, soutenances, archivage."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.etudes"
    verbose_name = "Espace Responsable des Études"
