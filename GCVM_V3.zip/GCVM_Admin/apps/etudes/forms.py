"""Formulaires du Responsable des Études."""

from datetime import datetime, timedelta

from django import forms
from django.conf import settings

from apps.accounts.forms import styliser
from apps.accounts.models import Role, Utilisateur
from apps.archives.models import MemoireArchive, NiveauAcces, valider_archive
from apps.defenses.models import RoleJury, Salle, Soutenance


class DecisionThemeForm(forms.Form):
    """Validation ou rejet d'un thème. Le motif n'est exigé qu'en cas de rejet."""

    decision = forms.ChoiceField(
        choices=[("valider", "Valider"), ("rejeter", "Rejeter")],
        widget=forms.HiddenInput())
    motif = forms.CharField(
        label="Motif du rejet", required=False,
        widget=forms.Textarea(attrs={
            "rows": 4,
            "placeholder": "Expliquez ce qui doit être repris : périmètre, "
                           "terrain, problématique…"}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        styliser(self)

    def clean(self):
        donnees = super().clean()
        if donnees.get("decision") == "rejeter" and not (donnees.get("motif") or "").strip():
            self.add_error(
                "motif",
                "Le motif est obligatoire : l'étudiant doit savoir quoi corriger.")
        return donnees


class SoutenanceForm(forms.ModelForm):
    """
    Programmation d'une soutenance.

    Le jury est choisi ici, parmi **tous les enseignants** : il n'existe pas de
    rôle « Jury » distinct, conformément au cahier des charges.
    """

    membres = forms.ModelMultipleChoiceField(
        label="Membres du jury", queryset=Utilisateur.objects.none(),
        widget=forms.CheckboxSelectMultiple(),
        help_text="Tout enseignant peut siéger. L'encadreur est ajouté "
                  "automatiquement comme membre de droit.")
    president = forms.ModelChoiceField(
        label="Président du jury", queryset=Utilisateur.objects.none(),
        required=False, empty_label="— À désigner plus tard —")

    class Meta:
        model = Soutenance
        fields = ["date_soutenance", "heure_debut", "heure_fin", "salle"]
        widgets = {
            "date_soutenance": forms.DateInput(attrs={"type": "date"}),
            "heure_debut": forms.TimeInput(attrs={"type": "time"}),
            "heure_fin": forms.TimeInput(attrs={"type": "time"}),
        }

    def __init__(self, *args, memoire=None, **kwargs):
        self.memoire = memoire
        super().__init__(*args, **kwargs)

        enseignants = Utilisateur.objects.filter(
            role=Role.PROFESSEUR, is_active=True).select_related("profilprofesseur")
        if memoire is not None and memoire.encadreur_id:
            # L'encadreur siège de droit : il n'a pas à être coché.
            enseignants = enseignants.exclude(pk=memoire.encadreur_id)

        self.fields["membres"].queryset = enseignants
        self.fields["president"].queryset = enseignants
        self.fields["salle"].queryset = Salle.objects.filter(est_active=True)

        duree = settings.GCVM["DUREE_SOUTENANCE_MIN"]
        if not self.is_bound:
            self.fields["heure_debut"].initial = "09:00"
            depart = datetime(2000, 1, 1, 9, 0) + timedelta(minutes=duree)
            self.fields["heure_fin"].initial = depart.strftime("%H:%M")

        styliser(self)
        for nom in ("membres",):
            self.fields[nom].widget.attrs.pop("class", None)
            self.fields[nom].widget.attrs.pop("required", None)

    def clean(self):
        donnees = super().clean()
        membres = donnees.get("membres") or []
        president = donnees.get("president")

        # L'encadreur compte dans le quorum : il est membre de droit.
        total = len(membres) + (1 if self.memoire and self.memoire.encadreur_id else 0)
        minimum = settings.GCVM["NB_MIN_MEMBRES_JURY"]
        if total < minimum:
            self.add_error(
                "membres",
                f"Le jury doit compter au moins {minimum} membres, encadreur "
                f"compris. Vous en avez sélectionné {total}.")

        if president is not None and president not in membres:
            self.add_error(
                "president",
                "Le président doit figurer parmi les membres sélectionnés.")
        return donnees


class RemplacantForm(forms.Form):
    """Remplacement d'un membre qui a refusé."""

    remplacant = forms.ModelChoiceField(
        label="Enseignant remplaçant", queryset=Utilisateur.objects.none(),
        empty_label="— Choisissez un enseignant —")

    def __init__(self, *args, soutenance=None, **kwargs):
        super().__init__(*args, **kwargs)
        deja = soutenance.membres.values_list("enseignant_id", flat=True) if soutenance else []
        self.fields["remplacant"].queryset = Utilisateur.objects.filter(
            role=Role.PROFESSEUR, is_active=True).exclude(pk__in=list(deja))
        styliser(self)


class ResultatSoutenanceForm(forms.Form):
    """Clôture de la séance : note finale et délibération."""

    note_finale = forms.DecimalField(
        label="Note finale / 20", max_digits=4, decimal_places=2,
        min_value=0, max_value=20)
    deliberation = forms.CharField(
        label="Délibération du jury", required=False,
        widget=forms.Textarea(attrs={
            "rows": 3, "placeholder": "Appréciation d'ensemble, corrections exigées…"}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        styliser(self)


class ImportArchiveForm(forms.ModelForm):
    """
    Import d'un mémoire d'une promotion antérieure.

    Ces mémoires n'ont ni compte étudiant ni dossier dans la plateforme :
    l'auteur et l'encadreur sont saisis comme du texte.
    """

    class Meta:
        model = MemoireArchive
        fields = ["titre", "auteur_nom", "encadreur_nom", "annee", "filiere",
                  "resume", "mots_cles", "fichier", "niveau_acces"]
        widgets = {
            "titre": forms.TextInput(attrs={"placeholder": "Titre complet du mémoire"}),
            "auteur_nom": forms.TextInput(attrs={"placeholder": "NOM Prénom"}),
            "encadreur_nom": forms.TextInput(attrs={"placeholder": "NOM Prénom"}),
            "annee": forms.TextInput(attrs={"placeholder": "2022-2023"}),
            "filiere": forms.TextInput(attrs={"placeholder": "Management"}),
            "resume": forms.Textarea(attrs={"rows": 5}),
            "mots_cles": forms.TextInput(attrs={"placeholder": "gouvernance, PME, Togo"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["fichier"].help_text = (
            f"Format accepté : "
            f"{', '.join('.' + e for e in settings.GCVM['EXTENSIONS_AUTORISEES'])}. "
            f"Taille maximale : {settings.GCVM['TAILLE_MAX_DEPOT_MO']} Mo.")
        styliser(self)

    def clean_resume(self):
        resume = self.cleaned_data["resume"].strip()
        if len(resume) < 60:
            raise forms.ValidationError(
                "Le résumé doit faire au moins 60 caractères : c'est lui qui "
                "permet de retrouver le mémoire dans la bibliothèque.")
        return resume

    def save(self, commit=True, archive_par=None):
        import os
        archive = super().save(commit=False)
        archive.origine = MemoireArchive.Origine.IMPORT
        fichier = self.cleaned_data.get("fichier")
        if fichier is not None and hasattr(fichier, "size"):
            archive.taille_octets = fichier.size
            archive.nom_original = os.path.basename(fichier.name)[:255]
        if archive_par is not None and archive_par.pk:
            archive.archive_par = archive_par
        if commit:
            archive.save()
        return archive
