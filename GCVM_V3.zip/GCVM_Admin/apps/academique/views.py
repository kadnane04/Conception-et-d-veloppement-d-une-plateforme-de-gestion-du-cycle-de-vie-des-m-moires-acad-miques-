"""
Espace Responsable Académique.

Dernière validation avant la soutenance. Toute décision prise ici prévient
simultanément l'étudiant, l'encadreur et le Responsable des Études — c'est la
règle du cahier des charges, et elle est appliquée par les services de
`apps.memories`, pas répétée dans chaque vue.
"""

import os

from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render

from apps.accounts.gardes import resp_academique_requis
from apps.memories.models import Memoire, StatutMemoire, VersionMemoire
from apps.memories.services import rejeter_par_academique, valider_par_academique


@resp_academique_requis
def tableau_de_bord(requete):
    recus = Memoire.objects.filter(statut=StatutMemoire.TRANSMIS)
    valides = Memoire.objects.filter(statut__in=[
        StatutMemoire.VALIDE_RESP_ACADEMIQUE, StatutMemoire.SOUTENANCE_PLANIFIEE,
        StatutMemoire.SOUTENU, StatutMemoire.FINALE_DEPOSEE,
        StatutMemoire.FINALE_VALIDEE_ENCADREUR, StatutMemoire.ARCHIVE])
    rejetes = Memoire.objects.filter(statut=StatutMemoire.REJETE_RESP_ACADEMIQUE)

    cartes = [
        {"cle": "academique:memoires", "titre": "Mémoires reçus",
         "valeur": recus.count(), "icone": "bi-inbox", "ton": "bleu"},
        {"cle": "academique:memoires", "titre": "Mémoires validés",
         "valeur": valides.count(), "icone": "bi-patch-check", "ton": "bleu"},
        {"cle": "academique:memoires", "titre": "Mémoires rejetés",
         "valeur": rejetes.count(), "icone": "bi-x-octagon", "ton": "bleu"},
        {"cle": "archives:bibliotheque", "titre": "Total des dossiers",
         "valeur": Memoire.objects.count(), "icone": "bi-folder", "ton": "fonce"},
    ]

    return render(requete, "academique/tableau_de_bord.html", {
        "rubrique": "tdb", "cartes": cartes,
        "a_examiner": recus.select_related("etudiant", "encadreur", "theme")[:6],
        "derniers_traites": Memoire.objects.filter(
            date_validation_academique__isnull=False)
            .select_related("etudiant").order_by("-date_validation_academique")[:5],
    })


@resp_academique_requis
def memoires(requete):
    liste = (Memoire.objects.select_related("etudiant", "encadreur", "theme",
                                            "annee_academique")
             .exclude(statut__in=[StatutMemoire.BROUILLON, StatutMemoire.DEPOSE,
                                  StatutMemoire.REJETE_ENCADREUR])
             .order_by("-date_transmission", "-date_dernier_depot"))

    filtre = requete.GET.get("statut", StatutMemoire.TRANSMIS)
    if filtre:
        liste = liste.filter(statut=filtre)
    recherche = requete.GET.get("q", "").strip()
    if recherche:
        liste = liste.filter(Q(titre__icontains=recherche)
                             | Q(etudiant__nom__icontains=recherche)
                             | Q(etudiant__prenom__icontains=recherche))

    from django.conf import settings
    page = Paginator(liste, settings.GCVM["ELEMENTS_PAR_PAGE"]).get_page(
        requete.GET.get("page"))

    return render(requete, "academique/memoires.html", {
        "rubrique": "memoires", "page": page, "filtre": filtre,
        "recherche": recherche, "statuts": StatutMemoire.choices,
        "a_examiner": Memoire.objects.filter(statut=StatutMemoire.TRANSMIS).count(),
    })


@resp_academique_requis
def detail_memoire(requete, pk):
    memoire = get_object_or_404(
        Memoire.objects.select_related("etudiant", "etudiant__profiletudiant",
                                       "encadreur", "theme", "annee_academique"),
        pk=pk)
    return render(requete, "academique/detail_memoire.html", {
        "rubrique": "memoires", "memoire": memoire,
        "versions": memoire.versions.select_related("depose_par"),
        "decisions": memoire.decisions.select_related("auteur"),
    })


@resp_academique_requis
def decider(requete, pk, decision):
    memoire = get_object_or_404(Memoire, pk=pk)

    if requete.method != "POST":
        return redirect("academique:detail_memoire", pk=pk)

    if not memoire.attend_academique:
        messages.warning(
            requete,
            "Ce mémoire n'est pas en attente de votre décision : il doit avoir "
            "été transmis par le Responsable des Études.")
        return redirect("academique:detail_memoire", pk=pk)

    commentaire = requete.POST.get("commentaire", "").strip()

    if decision == "valider":
        valider_par_academique(memoire, requete.user, commentaire)
        messages.success(
            requete,
            "Mémoire validé. L'étudiant, l'encadreur et le Responsable des "
            "Études ont été prévenus ; la soutenance peut être programmée.")
    else:
        if not commentaire:
            messages.error(requete, "Le motif est obligatoire pour rejeter un mémoire.")
            return redirect("academique:detail_memoire", pk=pk)
        rejeter_par_academique(memoire, requete.user, commentaire)
        messages.info(
            requete,
            "Mémoire rejeté. L'étudiant, l'encadreur et le Responsable des "
            "Études ont reçu le motif.")

    return redirect("academique:detail_memoire", pk=pk)


@resp_academique_requis
def telecharger_version(requete, pk):
    version = get_object_or_404(
        VersionMemoire.objects.select_related("memoire"), pk=pk)
    if not version.fichier or not version.fichier.storage.exists(version.fichier.name):
        raise Http404("Le fichier de cette version est introuvable.")
    return FileResponse(
        version.fichier.open("rb"), as_attachment=True,
        filename=version.nom_original or os.path.basename(version.fichier.name))
