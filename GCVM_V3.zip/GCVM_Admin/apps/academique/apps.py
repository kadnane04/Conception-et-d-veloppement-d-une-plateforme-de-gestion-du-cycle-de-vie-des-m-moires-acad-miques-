from django.apps import AppConfig


class AcademiqueConfig(AppConfig):
    """Espace Responsable Académique : validation finale des mémoires transmis."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.academique"
    verbose_name = "Espace Responsable Académique"
