"""Routes de l'espace Responsable Académique."""

from django.urls import path

from . import views

app_name = "academique"

urlpatterns = [
    path("", views.tableau_de_bord, name="tableau_de_bord"),
    path("memoires/", views.memoires, name="memoires"),
    path("memoires/<int:pk>/", views.detail_memoire, name="detail_memoire"),
    path("memoires/<int:pk>/<slug:decision>/", views.decider, name="decider"),
    path("version/<int:pk>/telecharger/", views.telecharger_version,
         name="telecharger_version"),
]
