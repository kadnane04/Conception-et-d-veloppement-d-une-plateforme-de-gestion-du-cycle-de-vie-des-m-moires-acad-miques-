"""
Gardes d'accès aux espaces, réunis en un seul endroit.

Chaque espace applique exactement la même règle : un visiteur anonyme est
renvoyé vers la connexion, un utilisateur connecté mais d'un autre rôle vers
son propre espace. Centraliser ces gardes évite qu'un module en oublie un —
c'est précisément ce genre d'oubli qui ouvre une porte dérobée.

Le cas du jury est particulier et mérite d'être défendu : il n'existe **aucun
rôle « Jury »**. Un membre de jury est un enseignant. L'accès à l'espace Jury
est donc conditionné non par le rôle du compte, mais par le fait de siéger
dans au moins un jury.
"""

from functools import wraps

from django.contrib.auth.decorators import login_required, user_passes_test

from .models import Role


def _garde(test):
    """Fabrique un décorateur à partir d'un simple test sur l'utilisateur."""
    def decorateur(vue):
        @wraps(vue)
        def enveloppe(*args, **kwargs):
            protegee = login_required(
                user_passes_test(test, login_url="comptes:redirection")(vue))
            return protegee(*args, **kwargs)
        return enveloppe
    return decorateur


def est_role(role):
    def test(utilisateur):
        return utilisateur.is_authenticated and utilisateur.role == role
    return test


def est_membre_de_jury(utilisateur):
    """Enseignant siégeant dans au moins un jury — accepté, ou invité."""
    if not utilisateur.is_authenticated or utilisateur.role != Role.PROFESSEUR:
        return False
    return utilisateur.participations_jury.exists()


def est_enseignant(utilisateur):
    return utilisateur.is_authenticated and utilisateur.role == Role.PROFESSEUR


etudiant_requis = _garde(est_role(Role.ETUDIANT))
enseignant_requis = _garde(est_enseignant)
resp_etudes_requis = _garde(est_role(Role.RESP_ETUDES))
resp_academique_requis = _garde(est_role(Role.RESP_ACADEMIQUE))
administrateur_requis = _garde(est_role(Role.ADMINISTRATEUR))
jury_requis = _garde(est_membre_de_jury)


def connecte_requis(vue):
    """La bibliothèque est ouverte à tous les comptes, quel que soit le rôle."""
    @wraps(vue)
    def enveloppe(*args, **kwargs):
        return login_required(vue)(*args, **kwargs)
    return enveloppe
