"""
Formulaires de la plateforme.

Deux familles :

* l'authentification (connexion, mot de passe oublié, changement de mot de
  passe) ;
* la création et la modification des comptes par l'administrateur.

Un principe commun : **il n'existe aucune inscription publique**. Tous les
formulaires de création sont derrière une page réservée à l'administrateur.
"""

import secrets
import string

from django import forms
from django.contrib.auth import password_validation
from django.contrib.auth.forms import PasswordResetForm, SetPasswordForm

from .models import (
    Filiere, Grade, ProfilEtudiant, ProfilProfesseur,
    ProfilResponsableAcademique, ProfilResponsableEtudes, Role,
    StatutProfesseur, Utilisateur,
)

CLASSE_CHAMP = "form-control"
CLASSE_SELECT = "form-select"


def styliser(formulaire):
    """
    Applique les classes Bootstrap 5 aux widgets.

    Le style est posé côté Python plutôt que dans les gabarits : les classes
    restent alors cohérentes sur l'ensemble des formulaires sans avoir à les
    répéter champ par champ dans le HTML.
    """
    for nom, champ in formulaire.fields.items():
        widget = champ.widget
        if isinstance(widget, forms.CheckboxInput):
            widget.attrs.setdefault("class", "form-check-input")
            continue
        if isinstance(widget, (forms.Select, forms.SelectMultiple)):
            widget.attrs.setdefault("class", CLASSE_SELECT)
        else:
            widget.attrs.setdefault("class", CLASSE_CHAMP)
        if isinstance(widget, forms.DateInput):
            widget.input_type = "date"
        if champ.required:
            widget.attrs.setdefault("required", "required")


def generer_mot_de_passe(longueur=12):
    """Mot de passe initial aléatoire, proposé à l'administrateur."""
    alphabet = string.ascii_letters + string.digits + "@#%&*?"
    while True:
        candidat = "".join(secrets.choice(alphabet) for _ in range(longueur))
        if (any(c.islower() for c in candidat) and any(c.isupper() for c in candidat)
                and any(c.isdigit() for c in candidat)):
            return candidat


# ==========================================================================
# Authentification
# ==========================================================================
class ConnexionForm(forms.Form):
    """Page de connexion : email + mot de passe."""

    email = forms.EmailField(
        label="Adresse email",
        widget=forms.EmailInput(attrs={
            "placeholder": "prenom.nom@lbs.com",
            "autocomplete": "email", "autofocus": "autofocus",
        }),
    )
    mot_de_passe = forms.CharField(
        label="Mot de passe",
        widget=forms.PasswordInput(attrs={
            "placeholder": "Votre mot de passe", "autocomplete": "current-password",
        }),
    )
    se_souvenir = forms.BooleanField(label="Rester connecté", required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        styliser(self)

    def clean_email(self):
        return self.cleaned_data["email"].strip().lower()


class DemandeReinitialisationForm(PasswordResetForm):
    """
    Étape 1 du parcours « mot de passe oublié » : saisie de l'email.

    La réponse affichée est volontairement la même que le compte existe ou
    non : afficher « cet email est inconnu » permettrait à un tiers de savoir
    qui possède un compte sur la plateforme.
    """

    email = forms.EmailField(
        label="Adresse email du compte",
        widget=forms.EmailInput(attrs={"placeholder": "prenom.nom@lbs.com",
                                       "autocomplete": "email", "autofocus": "autofocus"}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        styliser(self)

    def get_users(self, email):
        """Seuls les comptes actifs reçoivent un lien de réinitialisation."""
        for utilisateur in Utilisateur.objects.filter(email__iexact=email.strip(), is_active=True):
            if utilisateur.has_usable_password():
                yield utilisateur


class NouveauMotDePasseForm(SetPasswordForm):
    """Étape finale : saisie du nouveau mot de passe."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["new_password1"].label = "Nouveau mot de passe"
        self.fields["new_password2"].label = "Confirmez le nouveau mot de passe"
        styliser(self)


class ChangementMotDePasseForm(forms.Form):
    """Changement volontaire depuis la page Profil."""

    mot_de_passe_actuel = forms.CharField(
        label="Mot de passe actuel", widget=forms.PasswordInput())
    nouveau = forms.CharField(label="Nouveau mot de passe", widget=forms.PasswordInput())
    confirmation = forms.CharField(
        label="Confirmez le nouveau mot de passe", widget=forms.PasswordInput())

    def __init__(self, utilisateur, *args, **kwargs):
        self.utilisateur = utilisateur
        super().__init__(*args, **kwargs)
        styliser(self)

    def clean_mot_de_passe_actuel(self):
        valeur = self.cleaned_data["mot_de_passe_actuel"]
        if not self.utilisateur.check_password(valeur):
            raise forms.ValidationError("Le mot de passe actuel est incorrect.")
        return valeur

    def clean(self):
        donnees = super().clean()
        nouveau, confirmation = donnees.get("nouveau"), donnees.get("confirmation")
        if nouveau and confirmation and nouveau != confirmation:
            self.add_error("confirmation", "Les deux mots de passe ne correspondent pas.")
        elif nouveau:
            password_validation.validate_password(nouveau, self.utilisateur)
        return donnees

    def enregistrer(self):
        self.utilisateur.set_password(self.cleaned_data["nouveau"])
        self.utilisateur.save(update_fields=["password"])
        return self.utilisateur


class ProfilForm(forms.ModelForm):
    """Modification par l'utilisateur de ses propres coordonnées."""

    class Meta:
        model = Utilisateur
        fields = ["nom", "prenom", "date_naissance", "telephone"]
        widgets = {"date_naissance": forms.DateInput(attrs={"type": "date"})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        styliser(self)


# ==========================================================================
# Création et modification des comptes par l'administrateur
# ==========================================================================
class BaseCompteForm(forms.Form):
    """
    Socle des quatre formulaires d'ajout.

    Chaque sous-classe déclare son rôle, son modèle de profil et les champs
    qu'elle y écrit. Le compte et son profil sont créés dans la même
    transaction par la vue appelante.
    """

    role = None
    modele_profil = None
    libelle = "utilisateur"

    nom = forms.CharField(label="Nom", max_length=80)
    prenom = forms.CharField(label="Prénom", max_length=80)
    date_naissance = forms.DateField(
        label="Date de naissance", required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    email = forms.EmailField(label="Adresse email")
    telephone = forms.CharField(label="Téléphone", max_length=30, required=False)
    mot_de_passe = forms.CharField(
        label="Mot de passe initial",
        widget=forms.TextInput(attrs={"autocomplete": "off"}),
        help_text="Communiqué à l'intéressé, qui pourra le changer depuis son profil.",
    )

    def __init__(self, *args, instance=None, **kwargs):
        self.instance = instance
        super().__init__(*args, **kwargs)
        if instance is not None:
            # En modification, le mot de passe n'est pas redemandé : il se
            # réinitialise par une action dédiée dans la page de gestion.
            self.fields.pop("mot_de_passe", None)
        else:
            self.fields["mot_de_passe"].initial = generer_mot_de_passe()
        styliser(self)

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        existants = Utilisateur.objects.filter(email=email)
        if self.instance is not None:
            existants = existants.exclude(pk=self.instance.pk)
        if existants.exists():
            raise forms.ValidationError("Un compte utilise déjà cette adresse email.")
        return email

    def clean_nom(self):
        return self.cleaned_data["nom"].strip()

    def clean_prenom(self):
        return self.cleaned_data["prenom"].strip()

    def clean_mot_de_passe(self):
        valeur = self.cleaned_data["mot_de_passe"]
        password_validation.validate_password(valeur)
        return valeur

    def champs_profil(self):
        """Valeurs à écrire dans le profil. Redéfini par chaque sous-classe."""
        return {}

    def enregistrer(self, auteur=None):
        donnees = self.cleaned_data
        champs_compte = {
            "nom": donnees["nom"],
            "prenom": donnees["prenom"],
            "date_naissance": donnees.get("date_naissance"),
            "telephone": donnees.get("telephone", ""),
        }

        if self.instance is None:
            utilisateur = Utilisateur.objects.create_user(
                email=donnees["email"], password=donnees["mot_de_passe"],
                role=self.role, cree_par=auteur if (auteur and auteur.pk) else None,
                **champs_compte,
            )
        else:
            utilisateur = self.instance
            utilisateur.email = donnees["email"]
            for champ, valeur in champs_compte.items():
                setattr(utilisateur, champ, valeur)
            utilisateur.save()

        if self.modele_profil is not None:
            # Le profil est constitué en mémoire puis enregistré une seule
            # fois. Un get_or_create() insérerait une ligne incomplète avant
            # que les champs obligatoires (filière, grade…) ne soient
            # renseignés, ce que la contrainte NOT NULL refuserait.
            profil = (self.modele_profil.objects.filter(utilisateur=utilisateur).first()
                      or self.modele_profil(utilisateur=utilisateur))
            for champ, valeur in self.champs_profil().items():
                setattr(profil, champ, valeur)
            profil.save()

        return utilisateur


class EtudiantForm(BaseCompteForm):
    role = Role.ETUDIANT
    modele_profil = ProfilEtudiant
    libelle = "étudiant"

    filiere = forms.ChoiceField(label="Filière", choices=Filiere.choices)
    matricule = forms.CharField(label="Matricule", max_length=30, required=False)

    def champs_profil(self):
        return {
            "filiere": self.cleaned_data["filiere"],
            "matricule": self.cleaned_data.get("matricule", "").strip(),
        }


class ProfesseurForm(BaseCompteForm):
    role = Role.PROFESSEUR
    modele_profil = ProfilProfesseur
    libelle = "professeur"

    grade = forms.ChoiceField(label="Grade", choices=Grade.choices)
    specialite = forms.CharField(label="Spécialité", max_length=120)
    email_professionnel = forms.EmailField(
        label="Email professionnel", required=False,
        help_text="Affiché aux étudiants sur la fiche de l'encadreur. "
                  "À défaut, l'email de connexion est utilisé.")
    domaines_recherche = forms.CharField(
        label="Domaines de recherche", required=False,
        widget=forms.Textarea(attrs={
            "rows": 3, "placeholder": "Gouvernance d'entreprise, PME africaines, RSE"}),
        help_text="Séparés par des virgules ou un par ligne.")
    statut = forms.ChoiceField(
        label="Responsabilités", choices=StatutProfesseur.choices,
        initial=StatutProfesseur.AUCUN, required=False,
        help_text="Un professeur n'a qu'un seul compte, quelles que soient "
                  "ses responsabilités. Ce champ reste modifiable ensuite.",
    )
    quota_encadrement = forms.IntegerField(
        label="Nombre maximum de mémoires encadrés", min_value=0, max_value=30,
        initial=5, required=False,
    )

    def champs_profil(self):
        return {
            "grade": self.cleaned_data["grade"],
            "specialite": self.cleaned_data["specialite"].strip(),
            "email_professionnel": self.cleaned_data.get("email_professionnel", ""),
            "domaines_recherche": self.cleaned_data.get("domaines_recherche", "").strip(),
            "statut": self.cleaned_data.get("statut") or StatutProfesseur.AUCUN,
            "quota_encadrement": self.cleaned_data.get("quota_encadrement") or 5,
        }


class ResponsableEtudesForm(BaseCompteForm):
    role = Role.RESP_ETUDES
    modele_profil = ProfilResponsableEtudes
    libelle = "responsable des études"

    grade = forms.ChoiceField(label="Grade", choices=Grade.choices)

    def champs_profil(self):
        return {"grade": self.cleaned_data["grade"]}


class ResponsableAcademiqueForm(BaseCompteForm):
    role = Role.RESP_ACADEMIQUE
    modele_profil = ProfilResponsableAcademique
    libelle = "responsable académique"

    grade = forms.ChoiceField(label="Grade", choices=Grade.choices)

    def champs_profil(self):
        return {"grade": self.cleaned_data["grade"]}


class AdministrateurForm(BaseCompteForm):
    role = Role.ADMINISTRATEUR
    modele_profil = None
    libelle = "administrateur"


# Table de correspondance utilisée par les vues : une seule vue d'ajout et une
# seule vue de modification servent les cinq rôles.
FORMULAIRES_PAR_ROLE = {
    Role.ETUDIANT: EtudiantForm,
    Role.PROFESSEUR: ProfesseurForm,
    Role.RESP_ETUDES: ResponsableEtudesForm,
    Role.RESP_ACADEMIQUE: ResponsableAcademiqueForm,
    Role.ADMINISTRATEUR: AdministrateurForm,
}
