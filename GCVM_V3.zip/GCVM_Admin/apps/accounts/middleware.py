"""Mise à jour du champ « dernier accès »."""

from django.contrib.auth import get_user_model
from django.utils import timezone


class DernierAccesMiddleware:
    """
    Écrit la date du dernier accès, au plus une fois par tranche de 5 minutes.

    Écrire à chaque requête alourdirait inutilement la base ; une précision de
    cinq minutes suffit largement à l'usage qui en est fait (affichage dans les
    tableaux de gestion).
    """

    INTERVALLE = 300  # secondes

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, requete):
        utilisateur = getattr(requete, "user", None)
        if utilisateur is not None and utilisateur.is_authenticated:
            maintenant = timezone.now()
            precedent = utilisateur.dernier_acces
            if precedent is None or (maintenant - precedent).total_seconds() > self.INTERVALLE:
                # get_user_model() plutôt que type(utilisateur) : request.user est
                # un objet paresseux, dont la classe réelle n'est pas le modèle.
                get_user_model().objects.filter(pk=utilisateur.pk).update(
                    dernier_acces=maintenant)
                utilisateur.dernier_acces = maintenant
        return self.get_response(requete)
