"""Variables communes à tous les gabarits."""

from django.conf import settings


def contexte_plateforme(requete):
    return {
        "ETABLISSEMENT": settings.GCVM["NOM_ETABLISSEMENT"],
        "SIGLE": settings.GCVM["SIGLE"],
    }


def compteurs_menu(requete):
    """
    Pastilles du menu latéral : ce qui attend une action de l'utilisateur.

    Elles sont calculées ici plutôt que dans chaque vue, pour que le menu dise
    la même chose sur toutes les pages. Une seule requête par compteur, et
    uniquement pour le rôle concerné : un étudiant ne paie pas le comptage des
    thèmes à valider.
    """
    utilisateur = getattr(requete, "user", None)
    if utilisateur is None or not utilisateur.is_authenticated:
        return {}

    contexte = {}

    if utilisateur.est_professeur:
        from apps.defenses.models import ParticipationJury, StatutParticipation
        from apps.memories.models import Memoire, StatutMemoire
        from apps.supervision.models import StatutDemande

        contexte["nb_demandes_encadrement"] = utilisateur.demandes_recues.filter(
            statut=StatutDemande.EN_ATTENTE).count()
        contexte["nb_memoires_a_valider"] = Memoire.objects.filter(
            encadreur=utilisateur,
            statut__in=[StatutMemoire.DEPOSE, StatutMemoire.FINALE_DEPOSEE]).count()
        participations = ParticipationJury.objects.filter(enseignant=utilisateur)
        contexte["nb_jurys"] = participations.exclude(
            statut=StatutParticipation.REMPLACE).count()
        contexte["nb_invitations_jury"] = participations.filter(
            statut=StatutParticipation.EN_ATTENTE).count()

    elif utilisateur.est_resp_etudes:
        from apps.memories.models import Memoire, StatutMemoire
        from apps.themes.models import StatutTheme, Theme

        contexte["nb_themes_attente"] = Theme.objects.filter(
            statut=StatutTheme.EN_ATTENTE).count()
        contexte["nb_a_transmettre"] = Memoire.objects.filter(
            statut=StatutMemoire.VALIDE_ENCADREUR).count()

    elif utilisateur.est_resp_academique:
        from apps.memories.models import Memoire, StatutMemoire

        contexte["nb_a_examiner"] = Memoire.objects.filter(
            statut=StatutMemoire.TRANSMIS).count()

    return contexte
