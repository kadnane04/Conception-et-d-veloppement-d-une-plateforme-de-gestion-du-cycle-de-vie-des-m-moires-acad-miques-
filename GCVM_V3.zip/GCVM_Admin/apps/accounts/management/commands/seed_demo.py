"""
Jeu de données de démonstration.

Toutes les personnes créées ici sont **fictives** : ni les noms, ni les
adresses email, ni les mots de passe ne correspondent à des personnes ou à des
comptes réels. Le jeu sert uniquement à montrer l'application remplie, par
exemple le jour de la soutenance.

    python manage.py seed_demo
    python manage.py seed_demo --reset      (repart d'une base vide)
"""

import unicodedata
from datetime import date

from django.conf import settings
from django.core.management.base import BaseCommand
from django.db import transaction

from django.core.files.base import ContentFile
from django.utils import timezone

from apps.accounts.models import (
    Activite, Filiere, Grade, JournalActivite, ProfilEtudiant, ProfilProfesseur,
    ProfilResponsableAcademique, ProfilResponsableEtudes, Role,
    StatutProfesseur, Utilisateur,
)
from apps.memories.models import AnneeAcademique, Memoire, StatutMemoire, VersionMemoire
from apps.notifications.models import Notification, TypeNotification
from apps.supervision.models import DemandeEncadrement
from apps.themes.models import CategorieTheme, StatutTheme, Theme

MOT_DE_PASSE = "Demo@2026"


def adresse(prenom, nom):
    """prenom.nom@lbs.com, accents retirés — une adresse email reste en ASCII."""
    brut = f"{prenom}.{nom}".lower().replace(" ", "-")
    sans_accent = "".join(
        c for c in unicodedata.normalize("NFD", brut)
        if unicodedata.category(c) != "Mn")
    return f"{sans_accent}@lbs.com"

ETUDIANTS = [
    ("KOSSI", "Ama", date(2002, 4, 11), Filiere.MANAGEMENT, "LBS-2026-001"),
    ("TETTEH", "Kwami", date(2001, 11, 27), Filiere.SYSTEME_INFORMATION, "LBS-2026-002"),
    ("AMEGAN", "Sena", date(2002, 2, 3), Filiere.MANAGEMENT, "LBS-2026-003"),
    ("GBEDEMAH", "Esi", date(2003, 7, 19), Filiere.SYSTEME_INFORMATION, "LBS-2026-004"),
    ("LAWSON", "Koffi", date(2002, 9, 5), Filiere.MANAGEMENT, "LBS-2026-005"),
    ("DOSSEH", "Akouvi", date(2001, 6, 14), Filiere.SYSTEME_INFORMATION, "LBS-2026-006"),
]

PROFESSEURS = [
    # Le troisième cumule encadrement et jury : c'est le cas à montrer.
    ("MENSAH", "Yao", Grade.MAITRE_CONFERENCES, "Systèmes d'information", StatutProfesseur.ENCADREUR),
    ("AFI", "Sena", Grade.DOCTEUR, "Contrôle de gestion", StatutProfesseur.JURY),
    ("BAWA", "Komi", Grade.PROFESSEUR_TITULAIRE, "Management stratégique", StatutProfesseur.ENCADREUR_JURY),
    ("AGBOKA", "Mawulé", Grade.MAITRE_ASSISTANT, "Marketing digital", StatutProfesseur.ENCADREUR),
    ("SOSSOU", "Afiwa", Grade.EXPERT_PROFESSIONNEL, "Audit et contrôle interne", StatutProfesseur.AUCUN),
]


class Command(BaseCommand):
    help = "Crée un jeu de comptes fictifs pour la démonstration."

    def add_arguments(self, parseur):
        parseur.add_argument(
            "--reset", action="store_true",
            help="Supprime d'abord tous les comptes sauf l'administrateur initial.")

    @transaction.atomic
    def handle(self, *args, **options):
        email_admin = settings.GCVM["ADMIN_INITIAL_EMAIL"].strip().lower()

        if options["reset"]:
            supprimes = Utilisateur.objects.exclude(email=email_admin).delete()[0]
            JournalActivite.objects.all().delete()
            self.stdout.write(f"  {supprimes} enregistrement(s) supprimé(s).")

        admin = Utilisateur.objects.filter(email=email_admin).first()

        cree = 0
        for nom, prenom, naissance, filiere, matricule in ETUDIANTS:
            email = adresse(prenom, nom)
            if Utilisateur.objects.filter(email=email).exists():
                continue
            utilisateur = Utilisateur.objects.create_user(
                email=email, password=MOT_DE_PASSE, nom=nom, prenom=prenom,
                date_naissance=naissance, role=Role.ETUDIANT, cree_par=admin)
            ProfilEtudiant.objects.create(
                utilisateur=utilisateur, filiere=filiere, matricule=matricule)
            JournalActivite.enregistrer(
                admin, Activite.CREATION_COMPTE,
                f"Création du compte étudiant de {utilisateur.nom_complet}", cible=utilisateur)
            cree += 1

        for nom, prenom, grade, specialite, statut in PROFESSEURS:
            email = adresse(prenom, nom)
            if Utilisateur.objects.filter(email=email).exists():
                continue
            utilisateur = Utilisateur.objects.create_user(
                email=email, password=MOT_DE_PASSE, nom=nom, prenom=prenom,
                date_naissance=date(1975, 1, 1), role=Role.PROFESSEUR, cree_par=admin)
            ProfilProfesseur.objects.create(
                utilisateur=utilisateur, grade=grade, specialite=specialite, statut=statut)
            JournalActivite.enregistrer(
                admin, Activite.CREATION_COMPTE,
                f"Création du compte professeur de {utilisateur.nom_complet}", cible=utilisateur)
            cree += 1

        responsables = [
            ("ATTISSO", "Yawa", Role.RESP_ETUDES, ProfilResponsableEtudes, Grade.DOCTEUR),
            ("KPODAR", "Elom", Role.RESP_ACADEMIQUE, ProfilResponsableAcademique,
             Grade.PROFESSEUR_TITULAIRE),
        ]
        for nom, prenom, role, modele, grade in responsables:
            email = adresse(prenom, nom)
            if Utilisateur.objects.filter(email=email).exists():
                continue
            utilisateur = Utilisateur.objects.create_user(
                email=email, password=MOT_DE_PASSE, nom=nom, prenom=prenom,
                date_naissance=date(1980, 5, 20), role=role, cree_par=admin)
            modele.objects.create(utilisateur=utilisateur, grade=grade)
            JournalActivite.enregistrer(
                admin, Activite.CREATION_COMPTE,
                f"Création du compte de {utilisateur.nom_complet}", cible=utilisateur)
            cree += 1

        # Un compte désactivé, pour montrer les deux états dans la liste.
        desactive = Utilisateur.objects.filter(email="koffi.lawson@lbs.com").first()
        if desactive and desactive.is_active:
            desactive.is_active = False
            desactive.save(update_fields=["is_active"])
            JournalActivite.enregistrer(
                admin, Activite.DESACTIVATION,
                f"Désactivation du compte de {desactive.nom_complet}", cible=desactive)

        self._guide(admin)
        self._parcours_etudiants(admin)

        self.stdout.write(self.style.SUCCESS(f"\n  {cree} compte(s) fictif(s) créé(s)."))
        self.stdout.write("\n  COMPTES DE DÉMONSTRATION")
        self.stdout.write(f"    Administrateur                  {email_admin} "
                          f"/ {settings.GCVM['ADMIN_INITIAL_MOT_DE_PASSE']}")
        self.stdout.write(f"    Tous les autres comptes         mot de passe : {MOT_DE_PASSE}")
        self.stdout.write("    Professeur encadreur + jury     komi.bawa@lbs.com")
        self.stdout.write("    Compte désactivé (démo)         koffi.lawson@lbs.com")
        self.stdout.write("\n  PARCOURS ÉTUDIANTS PRÉPARÉS (pour la démonstration)")
        self.stdout.write("    Rien de commencé                esi.gbedemah@lbs.com")
        self.stdout.write("    Thème en attente                sena.amegan@lbs.com")
        self.stdout.write("    Thème rejeté (motif visible)    akouvi.dosseh@lbs.com")
        self.stdout.write("    Thème validé, encadreur attendu kwami.tetteh@lbs.com")
        self.stdout.write("    Mémoire déposé, 2 versions      ama.kossi@lbs.com\n")

    # ----------------------------------------------------------------------
    def _guide(self, admin):
        """Dépose un guide de rédaction fictif, pour que le bouton du tableau
        de bord étudiant soit démontrable."""
        from apps.administration.models import DocumentInstitutionnel

        if DocumentInstitutionnel.guide_en_vigueur() is not None:
            return

        # Un PDF minimal mais valide : il s'ouvre réellement dans un lecteur.
        texte = ("Guide de redaction du memoire - Lome Business School "
                 "(document de demonstration)")
        contenu = self._pdf_minimal(texte)
        document = DocumentInstitutionnel(
            titre="Guide de rédaction du mémoire — édition 2026",
            description="Structure attendue, normes de présentation et "
                        "règles de citation.",
            categorie=DocumentInstitutionnel.Categorie.GUIDE_REDACTION,
            nom_original="guide_redaction_memoire_2026.pdf",
            taille_octets=len(contenu), depose_par=admin, est_publie=True)
        document.fichier.save("guide_redaction_memoire_2026.pdf",
                              ContentFile(contenu), save=False)
        document.save()

    @staticmethod
    def _pdf_minimal(texte):
        """Construit un PDF d'une page, lisible par n'importe quel lecteur."""
        flux = f"BT /F1 12 Tf 60 760 Td ({texte}) Tj ET".encode("latin-1", "replace")
        objets = [
            b"<< /Type /Catalog /Pages 2 0 R >>",
            b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            b"/Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
            b"<< /Length " + str(len(flux)).encode() + b" >>\nstream\n" + flux + b"\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        ]
        sortie = bytearray(b"%PDF-1.4\n")
        positions = []
        for numero, corps in enumerate(objets, start=1):
            positions.append(len(sortie))
            sortie += f"{numero} 0 obj\n".encode() + corps + b"\nendobj\n"
        depart = len(sortie)
        sortie += f"xref\n0 {len(objets) + 1}\n".encode() + b"0000000000 65535 f \n"
        for position in positions:
            sortie += f"{position:010d} 00000 n \n".encode()
        sortie += (f"trailer\n<< /Size {len(objets) + 1} /Root 1 0 R >>\n"
                   f"startxref\n{depart}\n%%EOF\n").encode()
        return bytes(sortie)

    # ----------------------------------------------------------------------
    def _parcours_etudiants(self, admin):
        """
        Place chaque étudiant à une étape différente du cycle.

        L'intérêt pour la soutenance : chaque écran de l'espace Étudiant peut
        être montré sans avoir à jouer le parcours en direct.
        """
        annee, _ = AnneeAcademique.objects.get_or_create(
            libelle="2025-2026", defaults={"est_active": True})

        def etudiant(email):
            return Utilisateur.objects.filter(email=email).first()

        def categorie(nom):
            return CategorieTheme.objects.filter(nom=nom).first()

        def creer_theme(compte, titre, statut, noms_categories, motif=""):
            if compte is None or compte.themes.exists():
                return compte.themes.first() if compte else None
            theme = Theme.objects.create(
                etudiant=compte, titre=titre,
                description="Ce mémoire étudie la question annoncée par le titre, "
                            "à partir d'un terrain togolais.",
                contexte="Le secteur concerné connaît des mutations rapides, "
                         "peu documentées dans le contexte local.",
                problematique="Dans quelle mesure le phénomène étudié influence-t-il "
                              "la performance des organisations observées ?",
                objectifs="Objectif général : mesurer cette influence.\n"
                          "OS1 : décrire les pratiques actuelles.\n"
                          "OS2 : identifier les facteurs déterminants.\n"
                          "OS3 : formuler des recommandations.",
                mots_cles="performance, Togo, organisation",
                statut=statut,
                date_decision=timezone.now() if statut != StatutTheme.EN_ATTENTE else None,
                decide_par=admin if statut != StatutTheme.EN_ATTENTE else None,
                motif_rejet=motif)
            for nom in noms_categories:
                cat = categorie(nom)
                if cat:
                    theme.categories.add(cat)
            return theme

        # 1. Thème en attente de décision
        amegan = etudiant("sena.amegan@lbs.com")
        creer_theme(amegan,
                    "Gouvernance des données clients dans les banques togolaises",
                    StatutTheme.EN_ATTENTE, ["Systèmes d'Information", "Gestion"])
        if amegan:
            Notification.objects.get_or_create(
                destinataire=amegan, type_notification=TypeNotification.THEME_SOUMIS,
                titre="Votre thème a été soumis",
                defaults={"message": "Il est en attente de validation par le "
                                     "Responsable des Études.",
                          "lien": "/themes/mes-themes/"})

        # 2. Thème rejeté, avec un motif lisible
        dosseh = etudiant("akouvi.dosseh@lbs.com")
        creer_theme(dosseh,
                    "L'intelligence artificielle dans l'entreprise",
                    StatutTheme.REJETE, ["Intelligence Artificielle"],
                    motif="Sujet trop large et sans terrain identifié. Précisez le "
                          "secteur, la population étudiée et la période d'observation.")
        if dosseh:
            Notification.objects.get_or_create(
                destinataire=dosseh, type_notification=TypeNotification.THEME_REJETE,
                titre="Votre thème a été rejeté",
                defaults={"message": "Consultez le motif dans l'historique de vos thèmes.",
                          "lien": "/themes/mes-themes/"})

        # 3. Thème validé, en attente d'un encadreur
        tetteh = etudiant("kwami.tetteh@lbs.com")
        creer_theme(tetteh,
                    "Sécurisation des paiements mobiles chez les commerçants de Lomé",
                    StatutTheme.VALIDE, ["Cybersécurité", "Systèmes d'Information"])
        if tetteh:
            Notification.objects.get_or_create(
                destinataire=tetteh, type_notification=TypeNotification.THEME_VALIDE,
                titre="Votre thème a été validé",
                defaults={"message": "Vous pouvez maintenant choisir un encadreur.",
                          "lien": "/encadrement/encadreurs/"})

        # 4. Parcours complet : thème validé, encadreur accepté, mémoire déposé
        kossi = etudiant("ama.kossi@lbs.com")
        encadreur = etudiant("yao.mensah@lbs.com")
        theme_kossi = creer_theme(
            kossi, "Contribution du contrôle de gestion à la performance des PME togolaises",
            StatutTheme.VALIDE, ["Gestion", "Finance"])

        if kossi and encadreur and theme_kossi and not kossi.demandes_encadrement.exists():
            demande = DemandeEncadrement.objects.create(
                etudiant=kossi, encadreur=encadreur, theme=theme_kossi,
                message="Votre spécialité correspond à mon sujet.")
            demande.accepter()
            Notification.objects.create(
                destinataire=kossi, type_notification=TypeNotification.ENCADREUR_ACCEPTE,
                titre="Votre encadreur a accepté votre demande",
                message=f"{encadreur.nom_complet} encadrera votre mémoire.",
                lien="/encadrement/mes-demandes/")

        if kossi and theme_kossi and not kossi.memoires.exists():
            memoire = Memoire.objects.create(
                etudiant=kossi, theme=theme_kossi, encadreur=encadreur,
                annee_academique=annee, titre=theme_kossi.titre,
                resume="Ce travail mesure la contribution du contrôle de gestion à "
                       "la performance des PME togolaises. Il s'appuie sur une enquête "
                       "menée auprès d'un échantillon d'entreprises de Lomé et sur "
                       "l'analyse de leurs états financiers sur trois exercices.",
                statut=StatutMemoire.DEPOSE, date_dernier_depot=timezone.now())

            for numero, note in [(1, "Première version complète."),
                                 (2, "Corrections du chapitre 2 et mise à jour des annexes.")]:
                contenu = (b"%PDF-1.4\n% Document de demonstration GCVM\n"
                           + b"0" * 4096)
                version = VersionMemoire(
                    memoire=memoire, numero=numero, taille_octets=len(contenu),
                    nom_original=f"memoire_kossi_v{numero}.pdf",
                    commentaire=note, depose_par=kossi)
                version.fichier.save(f"memoire_kossi_v{numero}.pdf",
                                     ContentFile(contenu), save=False)
                version.save()

            Notification.objects.create(
                destinataire=kossi, type_notification=TypeNotification.MEMOIRE_DEPOSE,
                titre="Version 2 déposée",
                message="Votre mémoire a été transmis à votre encadreur.",
                lien="/memoire/")
