"""
Jeu de démonstration du cycle complet.

Prolonge `seed_demo` : il place quelques dossiers **à chaque étape du cycle**,
des salles, une soutenance confirmée, une soutenance dont un jury a refusé, une
soutenance déjà tenue, et deux mémoires importés de promotions antérieures.

Toutes les personnes et tous les documents sont **fictifs**.

    python manage.py seed_demo
    python manage.py seed_cycle
"""

from datetime import date, time, timedelta

from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from apps.accounts.models import Role, Utilisateur
from apps.archives.models import MemoireArchive, NiveauAcces
from apps.defenses.models import (
    Evaluation, ParticipationJury, RoleJury, Salle, Soutenance, StatutParticipation,
    StatutSoutenance, mention_pour_note,
)
from apps.memories.models import (
    AnneeAcademique, DecisionMemoire, Memoire, StatutMemoire, VersionMemoire,
)
from apps.notifications.models import Notification, TypeNotification
from apps.supervision.models import DemandeEncadrement, StatutDemande
from apps.themes.models import CategorieTheme, StatutTheme, Theme

SALLES = [
    ("Amphi A", "Bâtiment principal", 120),
    ("Salle 201", "Bâtiment principal", 40),
    ("Salle 305", "Aile des Sciences de gestion", 30),
]

# (email étudiant, titre du mémoire, statut visé)
DOSSIERS = [
    ("sena.amegan@lbs.com",
     "Gouvernance des données clients dans les banques togolaises",
     StatutMemoire.VALIDE_ENCADREUR),
    ("akouvi.dosseh@lbs.com",
     "Digitalisation de la chaîne logistique du port de Lomé",
     StatutMemoire.TRANSMIS),
    ("kwami.tetteh@lbs.com",
     "Sécurisation des paiements mobiles chez les commerçants de Lomé",
     StatutMemoire.VALIDE_RESP_ACADEMIQUE),
]

ANCIENS = [
    ("L'impact de la microfinance sur l'entrepreneuriat féminin au Togo",
     "ADJAVON Afi", "Dr. KOUASSI Edem", "2022-2023", "Management",
     "Ce mémoire étudie l'effet des institutions de microfinance sur la création "
     "et la survie des entreprises dirigées par des femmes à Lomé. L'enquête "
     "porte sur 120 bénéficiaires suivies sur trois ans.",
     "microfinance, entrepreneuriat, femmes, Togo"),
    ("Mise en place d'un système d'information décisionnel dans une PME de "
     "distribution",
     "SEDDOH Kokou", "Pr. AMEGAH Yawo", "2021-2022", "Système d'information",
     "Le travail décrit la conception et le déploiement d'un entrepôt de données "
     "et de tableaux de bord dans une PME de distribution alimentaire, puis "
     "mesure l'effet sur les délais de décision.",
     "business intelligence, PME, entrepôt de données"),
]


class Command(BaseCommand):
    help = "Place des dossiers à chaque étape du cycle (données fictives)."

    def add_arguments(self, parseur):
        parseur.add_argument(
            "--reset", action="store_true",
            help="Efface d'abord soutenances, archives et dossiers de démonstration.")

    @transaction.atomic
    def handle(self, *args, **options):
        if options["reset"]:
            Soutenance.objects.all().delete()
            MemoireArchive.objects.all().delete()
            self.stdout.write("  Soutenances et archives effacées.")

        annee = AnneeAcademique.objects.filter(est_active=True).first()
        if annee is None:
            self.stdout.write(self.style.ERROR(
                "  Aucune année académique active. Lancez d'abord seed_demo."))
            return

        resp_etudes = Utilisateur.objects.filter(role=Role.RESP_ETUDES).first()
        resp_academique = Utilisateur.objects.filter(role=Role.RESP_ACADEMIQUE).first()
        if resp_etudes is None or resp_academique is None:
            self.stdout.write(self.style.ERROR(
                "  Comptes responsables absents. Lancez d'abord seed_demo."))
            return

        for nom, batiment, capacite in SALLES:
            Salle.objects.get_or_create(
                nom=nom, defaults={"batiment": batiment, "capacite": capacite})

        encadreurs = list(Utilisateur.objects.filter(
            role=Role.PROFESSEUR, is_active=True).order_by("nom"))
        if len(encadreurs) < 4:
            self.stdout.write(self.style.ERROR(
                "  Il faut au moins quatre professeurs. Lancez seed_demo."))
            return

        cree = 0
        for index, (email, titre, cible) in enumerate(DOSSIERS):
            etudiant = Utilisateur.objects.filter(email=email).first()
            if etudiant is None or etudiant.memoires.exists():
                continue
            encadreur = encadreurs[index % len(encadreurs)]
            self._dossier(etudiant, encadreur, titre, cible, annee,
                          resp_etudes, resp_academique)
            cree += 1

        self._soutenances(resp_etudes, encadreurs)
        self._anciens(resp_etudes)

        self.stdout.write(self.style.SUCCESS(
            f"\n  {cree} dossier(s) placé(s) dans le cycle."))
        self.stdout.write("\n  OÙ EN EST CHAQUE DOSSIER")
        for memoire in Memoire.objects.select_related("etudiant").order_by("pk"):
            self.stdout.write(
                f"    {memoire.etudiant.email:32} {memoire.get_statut_display()}")
        self.stdout.write(
            f"\n  Bibliothèque : {MemoireArchive.objects.count()} mémoire(s), "
            f"dont {MemoireArchive.objects.filter(origine='IMPORT').count()} importé(s).")
        self.stdout.write(
            f"  Soutenances  : {Soutenance.objects.count()}\n")

    # ----------------------------------------------------------------------
    def _pdf(self, texte):
        """PDF d'une page, réellement lisible par un lecteur."""
        flux = f"BT /F1 12 Tf 60 760 Td ({texte}) Tj ET".encode("latin-1", "replace")
        objets = [
            b"<< /Type /Catalog /Pages 2 0 R >>",
            b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            b"/Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
            b"<< /Length " + str(len(flux)).encode() + b" >>\nstream\n" + flux + b"\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        ]
        sortie = bytearray(b"%PDF-1.4\n")
        positions = []
        for numero, corps in enumerate(objets, start=1):
            positions.append(len(sortie))
            sortie += f"{numero} 0 obj\n".encode() + corps + b"\nendobj\n"
        depart = len(sortie)
        sortie += f"xref\n0 {len(objets) + 1}\n".encode() + b"0000000000 65535 f \n"
        for position in positions:
            sortie += f"{position:010d} 00000 n \n".encode()
        sortie += (f"trailer\n<< /Size {len(objets) + 1} /Root 1 0 R >>\n"
                   f"startxref\n{depart}\n%%EOF\n").encode()
        return bytes(sortie)

    def _version(self, memoire, numero, note, auteur, finale=False):
        contenu = self._pdf(f"Memoire de {memoire.etudiant.nom_complet} - version {numero}")
        version = VersionMemoire(
            memoire=memoire, numero=numero, taille_octets=len(contenu),
            nom_original=f"memoire_v{numero}.pdf", commentaire=note,
            depose_par=auteur, est_finale=finale)
        version.fichier.save(f"memoire_{memoire.pk}_v{numero}.pdf",
                             ContentFile(contenu), save=False)
        version.save()
        return version

    def _dossier(self, etudiant, encadreur, titre, cible, annee,
                 resp_etudes, resp_academique):
        """Crée thème, encadrement, mémoire et décisions jusqu'au statut visé."""
        theme = etudiant.themes.filter(statut=StatutTheme.VALIDE).first()
        if theme is None:
            theme = Theme.objects.create(
                etudiant=etudiant, titre=titre,
                description="Ce mémoire traite le sujet annoncé par son titre, "
                            "sur un terrain togolais.",
                contexte="Le secteur étudié connaît des mutations rapides.",
                problematique="Dans quelle mesure le phénomène observé "
                              "influence-t-il la performance des organisations ?",
                objectifs="Objectif général : mesurer cette influence.",
                mots_cles="performance, Togo, organisation",
                statut=StatutTheme.VALIDE, date_decision=timezone.now(),
                decide_par=resp_etudes)
            categorie = CategorieTheme.objects.filter(nom="Gestion").first()
            if categorie:
                theme.categories.add(categorie)

        if not etudiant.demandes_encadrement.filter(statut=StatutDemande.ACCEPTE).exists():
            demande = DemandeEncadrement.objects.create(
                etudiant=etudiant, encadreur=encadreur, theme=theme)
            demande.accepter()

        memoire = Memoire.objects.create(
            etudiant=etudiant, theme=theme, encadreur=encadreur,
            annee_academique=annee, titre=titre,
            resume="Ce travail mesure l'effet du phénomène étudié sur la "
                   "performance des organisations observées. Il repose sur une "
                   "enquête de terrain menée à Lomé et sur l'analyse de données "
                   "recueillies sur trois exercices consécutifs.",
            statut=StatutMemoire.DEPOSE, date_dernier_depot=timezone.now())
        self._version(memoire, 1, "Première version complète.", etudiant)
        DecisionMemoire.tracer(
            memoire, etudiant, DecisionMemoire.Etape.ETUDIANT,
            DecisionMemoire.Sens.DEPOT, "Mémoire déposé (version 1)")

        ordre = [StatutMemoire.DEPOSE, StatutMemoire.VALIDE_ENCADREUR,
                 StatutMemoire.TRANSMIS, StatutMemoire.VALIDE_RESP_ACADEMIQUE]
        if cible not in ordre:
            return memoire

        if ordre.index(cible) >= 1:
            memoire.statut = StatutMemoire.VALIDE_ENCADREUR
            memoire.date_validation_encadreur = timezone.now()
            memoire.commentaire_encadreur = "Travail sérieux, méthodologie solide."
            memoire.save()
            DecisionMemoire.tracer(
                memoire, encadreur, DecisionMemoire.Etape.ENCADREUR,
                DecisionMemoire.Sens.VALIDATION,
                f"Mémoire validé par l'encadreur {encadreur.nom_complet}",
                memoire.commentaire_encadreur)

        if ordre.index(cible) >= 2:
            memoire.statut = StatutMemoire.TRANSMIS
            memoire.date_transmission = timezone.now()
            memoire.transmis_par = resp_etudes
            memoire.save()
            DecisionMemoire.tracer(
                memoire, resp_etudes, DecisionMemoire.Etape.RESP_ETUDES,
                DecisionMemoire.Sens.TRANSMISSION,
                "Dossier transmis au Responsable Académique")

        if ordre.index(cible) >= 3:
            memoire.statut = StatutMemoire.VALIDE_RESP_ACADEMIQUE
            memoire.date_validation_academique = timezone.now()
            memoire.save()
            DecisionMemoire.tracer(
                memoire, resp_academique, DecisionMemoire.Etape.RESP_ACADEMIQUE,
                DecisionMemoire.Sens.VALIDATION,
                "Mémoire validé par le Responsable Académique")

        return memoire

    # ----------------------------------------------------------------------
    def _soutenances(self, resp_etudes, encadreurs):
        """Une soutenance confirmée, une avec un refus, une déjà tenue."""
        salles = list(Salle.objects.all())
        if not salles:
            return

        candidats = list(Memoire.objects.filter(
            statut=StatutMemoire.VALIDE_RESP_ACADEMIQUE, soutenance__isnull=True))
        if not candidats:
            return

        memoire = candidats[0]
        jour = timezone.localdate() + timedelta(days=21)
        soutenance = Soutenance.objects.create(
            memoire=memoire, date_soutenance=jour,
            heure_debut=time(9, 0), heure_fin=time(10, 0),
            salle=salles[0], planifiee_par=resp_etudes)

        autres = [e for e in encadreurs if e.pk != memoire.encadreur_id][:3]
        if memoire.encadreur:
            ParticipationJury.objects.create(
                soutenance=soutenance, enseignant=memoire.encadreur,
                role=RoleJury.ENCADREUR, statut=StatutParticipation.ACCEPTE,
                date_reponse=timezone.now())

        roles = [RoleJury.PRESIDENT, RoleJury.RAPPORTEUR, RoleJury.MEMBRE]
        for position, enseignant in enumerate(autres):
            participation = ParticipationJury.objects.create(
                soutenance=soutenance, enseignant=enseignant,
                role=roles[position % len(roles)])
            if position == 0:
                # Un refus, pour montrer le remplacement.
                participation.refuser("Indisponible à cette date.")
                Notification.envoyer(
                    resp_etudes, TypeNotification.JURY_REPONSE,
                    "Un membre du jury a refusé",
                    f"{enseignant.nom_complet} ne peut pas siéger. Un remplaçant "
                    f"doit être désigné.", f"/etudes/soutenances/{soutenance.pk}/")
            else:
                participation.accepter()
                Notification.envoyer(
                    enseignant, TypeNotification.JURY_INVITATION,
                    "Vous avez été sélectionné comme membre du jury",
                    f"Soutenance de {memoire.etudiant.nom_complet} le "
                    f"{jour:%d/%m/%Y}.", "/jury/")

        soutenance.rafraichir_statut()

    # ----------------------------------------------------------------------
    def _anciens(self, resp_etudes):
        """Deux mémoires de promotions antérieures, importés à la main."""
        for titre, auteur, encadreur, annee, filiere, resume, mots in ANCIENS:
            if MemoireArchive.objects.filter(titre=titre).exists():
                continue
            contenu = self._pdf(f"{titre} - {auteur} ({annee})")
            archive = MemoireArchive(
                titre=titre, auteur_nom=auteur, encadreur_nom=encadreur,
                annee=annee, filiere=filiere, resume=resume, mots_cles=mots,
                origine=MemoireArchive.Origine.IMPORT,
                niveau_acces=NiveauAcces.INTERNE,
                nom_original=f"{annee}-{auteur.split()[0].lower()}.pdf",
                taille_octets=len(contenu), archive_par=resp_etudes)
            archive.fichier.save(archive.nom_original, ContentFile(contenu), save=False)
            archive.save()
