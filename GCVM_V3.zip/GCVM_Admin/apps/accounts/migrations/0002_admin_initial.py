"""
Création du compte administrateur initial.

La plateforme n'a pas d'inscription publique : sans ce compte, personne ne
pourrait jamais se connecter, et donc personne ne pourrait créer de comptes.
C'est l'amorçage du système.

Le placer dans une migration plutôt que dans une commande séparée garantit
qu'il existe dès le premier `migrate`, sans geste supplémentaire.

Le mot de passe est haché par Django au moment de l'écriture ; il ne figure
en clair ni dans la base ni dans ce fichier — sa valeur vient des réglages,
donc du fichier .env (voir .env.example).
"""

from django.conf import settings
from django.contrib.auth.hashers import make_password
from django.db import migrations
from django.utils import timezone


def creer_admin(apps, schema_editor):
    Utilisateur = apps.get_model("accounts", "Utilisateur")

    email = settings.GCVM["ADMIN_INITIAL_EMAIL"].strip().lower()
    if Utilisateur.objects.filter(email=email).exists():
        return

    Utilisateur.objects.create(
        email=email,
        # make_password applique l'algorithme configuré (PBKDF2-SHA256).
        password=make_password(settings.GCVM["ADMIN_INITIAL_MOT_DE_PASSE"]),
        nom="Admin",
        prenom="Admin",
        role="ADMINISTRATEUR",
        is_active=True,
        is_staff=True,
        is_superuser=True,
        # « Date de création : date du premier lancement du système. »
        date_creation=timezone.now(),
    )


def supprimer_admin(apps, schema_editor):
    Utilisateur = apps.get_model("accounts", "Utilisateur")
    Utilisateur.objects.filter(
        email=settings.GCVM["ADMIN_INITIAL_EMAIL"].strip().lower()
    ).delete()


class Migration(migrations.Migration):

    dependencies = [("accounts", "0001_initial")]

    operations = [migrations.RunPython(creer_admin, supprimer_admin)]
