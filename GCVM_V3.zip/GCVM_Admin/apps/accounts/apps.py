from django.apps import AppConfig


class AccountsConfig(AppConfig):
    """Comptes, rôles, authentification et journal d'activité."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.accounts"
    verbose_name = "Comptes et authentification"
