"""
Modèle utilisateur de la plateforme GCVM.

Deux décisions structurantes sont prises ici.

1. **Un modèle utilisateur personnalisé plutôt que le `User` de Django.**
   L'identifiant de connexion est l'email, pas un nom d'utilisateur, et les
   comptes portent des attributs propres à l'établissement (date de naissance,
   rôle). Un modèle personnalisé posé dès la première migration évite une
   refonte ultérieure, opération réputée douloureuse sous Django.

2. **Une table mère et une table par profil.**
   `Utilisateur` porte ce qui est commun à tout le monde ; `ProfilEtudiant`,
   `ProfilProfesseur`, `ProfilResponsableEtudes` et `ProfilResponsableAcademique`
   portent ce qui est propre à chaque rôle, reliés par un `OneToOneField` dont
   la clé primaire est celle de l'utilisateur.

   C'est la traduction relationnelle de la généralisation du diagramme de
   classes. Elle préserve deux choses qu'aucune autre stratégie ne préserve
   ensemble : l'unicité de l'email sur l'ensemble des comptes, et les
   contraintes NOT NULL sur les attributs spécifiques (un étudiant a
   forcément une filière, un professeur a forcément un grade).

3. **Les rôles Encadreur et Jury ne sont pas des comptes.**
   Un professeur possède un seul compte, quel que soit le nombre de
   responsabilités qu'il exerce. Ces responsabilités sont portées par le champ
   `ProfilProfesseur.statut`, modifiable à tout moment par l'administrateur.
   Les modules à venir y ajouteront des associations (encadrement d'un mémoire
   donné, participation à un jury donné) sans toucher à cette structure.
"""

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.utils import timezone


class Role(models.TextChoices):
    """Les cinq rôles de la plateforme."""

    ADMINISTRATEUR = "ADMINISTRATEUR", "Administrateur"
    ETUDIANT = "ETUDIANT", "Étudiant"
    PROFESSEUR = "PROFESSEUR", "Professeur"
    RESP_ETUDES = "RESP_ETUDES", "Responsable des études"
    RESP_ACADEMIQUE = "RESP_ACADEMIQUE", "Responsable académique"


class GestionnaireUtilisateur(BaseUserManager):
    """Création des comptes. L'email tient lieu d'identifiant."""

    use_in_migrations = True

    def _creer(self, email, mot_de_passe, **champs):
        if not email:
            raise ValueError("L'adresse email est obligatoire.")
        email = self.normalize_email(email).strip().lower()
        utilisateur = self.model(email=email, **champs)
        # set_password applique le hachage configuré par Django (PBKDF2-SHA256).
        # Le mot de passe en clair ne touche jamais la base.
        utilisateur.set_password(mot_de_passe)
        utilisateur.full_clean(exclude=["password", "last_login"])
        utilisateur.save(using=self._db)
        return utilisateur

    def create_user(self, email, password=None, **champs):
        champs.setdefault("role", Role.ETUDIANT)
        champs.setdefault("is_staff", False)
        champs.setdefault("is_superuser", False)
        return self._creer(email, password, **champs)

    def create_superuser(self, email, password=None, **champs):
        champs.setdefault("role", Role.ADMINISTRATEUR)
        champs.setdefault("is_staff", True)
        champs.setdefault("is_superuser", True)
        champs.setdefault("nom", "Admin")
        champs.setdefault("prenom", "Admin")
        if not champs.get("is_staff") or not champs.get("is_superuser"):
            raise ValueError("Un superutilisateur doit avoir is_staff et is_superuser à True.")
        return self._creer(email, password, **champs)


class Utilisateur(AbstractBaseUser, PermissionsMixin):
    """Compte de la plateforme. Un compte, une personne, un rôle."""

    nom = models.CharField("Nom", max_length=80)
    prenom = models.CharField("Prénom", max_length=80)
    email = models.EmailField("Adresse email", unique=True)
    date_naissance = models.DateField("Date de naissance", null=True, blank=True)
    telephone = models.CharField("Téléphone", max_length=30, blank=True)
    role = models.CharField("Rôle", max_length=20, choices=Role.choices)

    is_active = models.BooleanField(
        "Compte actif", default=True,
        help_text="Un compte désactivé ne peut plus se connecter mais reste consultable.",
    )
    is_staff = models.BooleanField("Accès à l'administration Django", default=False)

    date_creation = models.DateTimeField("Date de création", default=timezone.now)
    dernier_acces = models.DateTimeField("Dernier accès", null=True, blank=True)

    cree_par = models.ForeignKey(
        "self", verbose_name="Créé par", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="comptes_crees",
    )

    objects = GestionnaireUtilisateur()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["nom", "prenom"]

    class Meta:
        verbose_name = "Utilisateur"
        verbose_name_plural = "Utilisateurs"
        ordering = ["nom", "prenom"]
        indexes = [
            models.Index(fields=["role", "is_active"]),
            models.Index(fields=["-date_creation"]),
        ]

    def __str__(self):
        return f"{self.nom.upper()} {self.prenom}"

    # -- Identité ----------------------------------------------------------
    def get_full_name(self):
        return f"{self.prenom} {self.nom.upper()}"

    def get_short_name(self):
        return self.prenom

    @property
    def nom_complet(self):
        return self.get_full_name()

    @property
    def initiales(self):
        return f"{self.prenom[:1]}{self.nom[:1]}".upper()

    def save(self, *args, **kwargs):
        if self.email:
            self.email = self.email.strip().lower()
        super().save(*args, **kwargs)

    # -- Rôle --------------------------------------------------------------
    @property
    def est_administrateur(self):
        return self.role == Role.ADMINISTRATEUR

    @property
    def est_etudiant(self):
        return self.role == Role.ETUDIANT

    @property
    def est_professeur(self):
        return self.role == Role.PROFESSEUR

    @property
    def est_resp_etudes(self):
        return self.role == Role.RESP_ETUDES

    @property
    def est_resp_academique(self):
        return self.role == Role.RESP_ACADEMIQUE

    @property
    def profil(self):
        """Le profil correspondant au rôle, ou None s'il n'existe pas encore."""
        relation = {
            Role.ETUDIANT: "profiletudiant",
            Role.PROFESSEUR: "profilprofesseur",
            Role.RESP_ETUDES: "profilresponsableetudes",
            Role.RESP_ACADEMIQUE: "profilresponsableacademique",
        }.get(self.role)
        if not relation:
            return None
        return getattr(self, relation, None)


# --------------------------------------------------------------------------
# Profils
# --------------------------------------------------------------------------
class ProfilBase(models.Model):
    """Socle commun aux quatre profils : la clé primaire est l'utilisateur."""

    # related_name = "%(class)s" : chaque sous-classe obtient automatiquement
    # son propre accesseur inverse (utilisateur.profiletudiant, etc.), ce qui
    # évite de redéfinir le champ dans chacune d'elles.
    utilisateur = models.OneToOneField(
        Utilisateur, verbose_name="Utilisateur",
        on_delete=models.CASCADE, primary_key=True,
        related_name="%(class)s",
    )

    class Meta:
        abstract = True

    def __str__(self):
        return str(self.utilisateur)


class Filiere(models.TextChoices):
    """Filières ouvertes au mémoire à LBS."""

    MANAGEMENT = "MANAGEMENT", "Management"
    SYSTEME_INFORMATION = "SYSTEME_INFORMATION", "Système d'information"


class ProfilEtudiant(ProfilBase):
    filiere = models.CharField("Filière", max_length=30, choices=Filiere.choices)
    matricule = models.CharField("Matricule", max_length=30, blank=True)

    class Meta:
        verbose_name = "Profil étudiant"
        verbose_name_plural = "Profils étudiants"


class Grade(models.TextChoices):
    """Grades académiques et administratifs."""

    DOCTORANT = "DOCTORANT", "Doctorant"
    DOCTEUR = "DOCTEUR", "Docteur"
    ASSISTANT = "ASSISTANT", "Assistant"
    MAITRE_ASSISTANT = "MAITRE_ASSISTANT", "Maître-assistant"
    MAITRE_CONFERENCES = "MAITRE_CONFERENCES", "Maître de conférences"
    PROFESSEUR_TITULAIRE = "PROFESSEUR_TITULAIRE", "Professeur titulaire"
    EXPERT_PROFESSIONNEL = "EXPERT_PROFESSIONNEL", "Expert professionnel"


class StatutProfesseur(models.TextChoices):
    """
    Responsabilités qu'un professeur peut exercer.

    Ce champ, et non un second compte, est ce qui distingue un encadreur d'un
    membre de jury. Un professeur qui cumule les deux garde un compte unique.
    """

    AUCUN = "AUCUN", "Aucune responsabilité pour l'instant"
    ENCADREUR = "ENCADREUR", "Encadreur"
    JURY = "JURY", "Membre de jury"
    ENCADREUR_JURY = "ENCADREUR_JURY", "Encadreur et membre de jury"


class ProfilProfesseur(ProfilBase):
    grade = models.CharField("Grade", max_length=30, choices=Grade.choices)
    specialite = models.CharField("Spécialité", max_length=120)
    # Renseignements consultés par l'étudiant au moment de choisir son
    # encadreur. Facultatifs : un compte reste créable sans eux.
    email_professionnel = models.EmailField("Email professionnel", blank=True)
    domaines_recherche = models.TextField(
        "Domaines de recherche", blank=True,
        help_text="Un domaine par ligne, ou séparés par des virgules.")
    statut = models.CharField(
        "Responsabilités", max_length=20,
        choices=StatutProfesseur.choices, default=StatutProfesseur.AUCUN,
        help_text="Détermine les espaces auxquels le professeur aura accès. "
                  "Modifiable à tout moment, sans créer de second compte.",
    )
    quota_encadrement = models.PositiveSmallIntegerField(
        "Nombre maximum de mémoires encadrés", default=5,
    )

    class Meta:
        verbose_name = "Profil professeur"
        verbose_name_plural = "Profils professeurs"

    @property
    def est_encadreur(self):
        return self.statut in {StatutProfesseur.ENCADREUR, StatutProfesseur.ENCADREUR_JURY}

    @property
    def est_jury(self):
        return self.statut in {StatutProfesseur.JURY, StatutProfesseur.ENCADREUR_JURY}

    @property
    def liste_domaines(self):
        """Les domaines de recherche, quel que soit le séparateur employé."""
        brut = (self.domaines_recherche or "").replace(";", ",").replace("\n", ",")
        return [d.strip() for d in brut.split(",") if d.strip()]

    @property
    def contact(self):
        """L'email professionnel s'il est renseigné, sinon celui du compte."""
        return self.email_professionnel or self.utilisateur.email

    @property
    def nb_encadrements_en_cours(self):
        """Demandes d'encadrement acceptées et non encore closes."""
        from apps.supervision.models import DemandeEncadrement, StatutDemande
        return DemandeEncadrement.objects.filter(
            encadreur=self.utilisateur, statut=StatutDemande.ACCEPTE).count()

    @property
    def places_restantes(self):
        return max(self.quota_encadrement - self.nb_encadrements_en_cours, 0)

    @property
    def est_disponible(self):
        return self.est_encadreur and self.places_restantes > 0


class ProfilResponsableEtudes(ProfilBase):
    grade = models.CharField("Grade", max_length=30, choices=Grade.choices)

    class Meta:
        verbose_name = "Profil responsable des études"
        verbose_name_plural = "Profils responsables des études"


class ProfilResponsableAcademique(ProfilBase):
    grade = models.CharField("Grade", max_length=30, choices=Grade.choices)

    class Meta:
        verbose_name = "Profil responsable académique"
        verbose_name_plural = "Profils responsables académiques"


# --------------------------------------------------------------------------
# Journal d'activité
# --------------------------------------------------------------------------
class Activite(models.TextChoices):
    CONNEXION = "CONNEXION", "Connexion"
    DECONNEXION = "DECONNEXION", "Déconnexion"
    CREATION_COMPTE = "CREATION_COMPTE", "Création d'un compte"
    MODIFICATION_COMPTE = "MODIFICATION_COMPTE", "Modification d'un compte"
    DESACTIVATION = "DESACTIVATION", "Désactivation d'un compte"
    REACTIVATION = "REACTIVATION", "Réactivation d'un compte"
    SUPPRESSION = "SUPPRESSION", "Suppression d'un compte"
    REINIT_MOT_DE_PASSE = "REINIT_MOT_DE_PASSE", "Réinitialisation d'un mot de passe"
    CHANGEMENT_STATUT = "CHANGEMENT_STATUT", "Changement de responsabilités"


class JournalActivite(models.Model):
    """
    Trace des actions menées sur la plateforme.

    Alimente la section « activités récentes » du tableau de bord et permet de
    répondre à la question « qui a fait quoi, quand ».
    """

    auteur = models.ForeignKey(
        Utilisateur, verbose_name="Auteur", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="activites",
    )
    type_activite = models.CharField("Type", max_length=30, choices=Activite.choices)
    cible = models.ForeignKey(
        Utilisateur, verbose_name="Compte concerné", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="activites_subies",
    )
    # Le libellé est figé au moment de l'écriture : il reste lisible même si le
    # compte concerné est supprimé par la suite.
    libelle = models.CharField("Description", max_length=255)
    horodatage = models.DateTimeField("Date", default=timezone.now)
    adresse_ip = models.GenericIPAddressField("Adresse IP", null=True, blank=True)

    class Meta:
        verbose_name = "Activité"
        verbose_name_plural = "Journal d'activité"
        ordering = ["-horodatage"]
        indexes = [models.Index(fields=["-horodatage"])]

    def __str__(self):
        return f"{self.horodatage:%d/%m/%Y %H:%M} — {self.libelle}"

    @classmethod
    def enregistrer(cls, auteur, type_activite, libelle, cible=None, requete=None):
        adresse = None
        if requete is not None:
            adresse = requete.META.get("REMOTE_ADDR")
        return cls.objects.create(
            auteur=auteur if (auteur and auteur.pk) else None,
            type_activite=type_activite,
            cible=cible,
            libelle=libelle[:255],
            adresse_ip=adresse,
        )
