"""
Backend d'authentification par email.

Django s'authentifie par défaut sur un `username`. Notre modèle n'en a pas :
l'identifiant est l'email. Ce backend fait la correspondance, et refuse
explicitement les comptes désactivés.
"""

from django.contrib.auth import get_user_model
from django.contrib.auth.backends import ModelBackend


class BackendEmail(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        Utilisateur = get_user_model()
        email = (username or kwargs.get("email") or "").strip().lower()
        if not email or password is None:
            return None
        try:
            utilisateur = Utilisateur.objects.get(email=email)
        except Utilisateur.DoesNotExist:
            # Un hachage est tout de même calculé : sans cela, le temps de
            # réponse révélerait l'existence ou non du compte.
            Utilisateur().set_password(password)
            return None
        if utilisateur.check_password(password) and self.user_can_authenticate(utilisateur):
            return utilisateur
        return None
