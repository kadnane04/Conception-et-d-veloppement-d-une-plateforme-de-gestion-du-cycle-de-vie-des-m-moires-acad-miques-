"""
Vues d'authentification et espace personnel.

Aucune vue d'inscription : la seule manière d'obtenir un compte est qu'un
administrateur le crée.
"""

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import (
    PasswordResetCompleteView, PasswordResetConfirmView,
    PasswordResetDoneView, PasswordResetView,
)
from django.shortcuts import redirect, render
from django.urls import reverse_lazy

from .forms import (
    ChangementMotDePasseForm, ConnexionForm, DemandeReinitialisationForm,
    NouveauMotDePasseForm, ProfilForm,
)
from .models import Activite, JournalActivite, Role

# Où atterrit chaque rôle après connexion. Une seule table, pour que
# l'aiguillage ne se disperse pas dans plusieurs vues.
ESPACES = {
    Role.ADMINISTRATEUR: "administration:tableau_de_bord",
    Role.ETUDIANT: "etudiant:tableau_de_bord",
    Role.PROFESSEUR: "encadreur:tableau_de_bord",
    Role.RESP_ETUDES: "etudes:tableau_de_bord",
    Role.RESP_ACADEMIQUE: "academique:tableau_de_bord",
}


def connexion(requete):
    """Page de connexion."""
    if requete.user.is_authenticated:
        return redirect("comptes:redirection")

    formulaire = ConnexionForm(requete.POST or None)

    if requete.method == "POST" and formulaire.is_valid():
        email = formulaire.cleaned_data["email"]
        utilisateur = authenticate(
            requete, username=email,
            password=formulaire.cleaned_data["mot_de_passe"],
        )
        if utilisateur is None:
            # Message unique : il ne dit pas si c'est l'email ou le mot de
            # passe qui est en cause, ni si le compte existe.
            formulaire.add_error(
                None, "Adresse email ou mot de passe incorrect. "
                      "Si votre compte a été désactivé, contactez l'administration.")
        else:
            login(requete, utilisateur)
            if not formulaire.cleaned_data.get("se_souvenir"):
                requete.session.set_expiry(0)   # expire à la fermeture du navigateur
            JournalActivite.enregistrer(
                utilisateur, Activite.CONNEXION,
                f"Connexion de {utilisateur.nom_complet}", requete=requete)
            messages.success(requete, f"Bienvenue, {utilisateur.prenom}.")
            suite = requete.GET.get("next")
            return redirect(suite or "comptes:redirection")

    return render(requete, "comptes/connexion.html", {"formulaire": formulaire})


def deconnexion(requete):
    if requete.user.is_authenticated:
        JournalActivite.enregistrer(
            requete.user, Activite.DECONNEXION,
            f"Déconnexion de {requete.user.nom_complet}", requete=requete)
    logout(requete)
    messages.info(requete, "Vous avez été déconnecté.")
    return redirect("comptes:connexion")


@login_required
def redirection(requete):
    """
    Aiguillage après connexion.

    Chaque rôle a désormais son espace. La page d'attente ne sert plus que de
    filet : un rôle inconnu y aboutit plutôt que sur une erreur.
    """
    return redirect(ESPACES.get(requete.user.role, "comptes:espace_en_preparation"))


@login_required
def espace_en_preparation(requete):
    destination = ESPACES.get(requete.user.role)
    if destination:
        return redirect(destination)
    return render(requete, "comptes/espace_en_preparation.html", {
        "role_libelle": Role(requete.user.role).label,
    })


@login_required
def mon_profil(requete):
    formulaire = ProfilForm(requete.POST or None, instance=requete.user)
    if requete.method == "POST" and formulaire.is_valid():
        formulaire.save()
        messages.success(requete, "Vos informations ont été mises à jour.")
        return redirect("comptes:mon_profil")
    return render(requete, "comptes/mon_profil.html", {
        "formulaire": formulaire, "rubrique": "profil",
    })


@login_required
def changer_mot_de_passe(requete):
    formulaire = ChangementMotDePasseForm(requete.user, requete.POST or None)
    if requete.method == "POST" and formulaire.is_valid():
        formulaire.enregistrer()
        # Sans cet appel, changer son mot de passe déconnecte l'utilisateur :
        # la session est signée avec l'ancien hachage.
        update_session_auth_hash(requete, requete.user)
        JournalActivite.enregistrer(
            requete.user, Activite.REINIT_MOT_DE_PASSE,
            "Changement de son propre mot de passe", cible=requete.user, requete=requete)
        messages.success(requete, "Votre mot de passe a été changé.")
        return redirect("comptes:mon_profil")
    return render(requete, "comptes/changer_mot_de_passe.html", {
        "formulaire": formulaire, "rubrique": "profil",
    })


# --------------------------------------------------------------------------
# Mot de passe oublié — les quatre étapes
# --------------------------------------------------------------------------
class DemandeReinitialisation(PasswordResetView):
    """Étape 1 : l'utilisateur saisit son email."""

    template_name = "registration/mot_de_passe_demande.html"
    email_template_name = "registration/mot_de_passe_email.txt"
    subject_template_name = "registration/mot_de_passe_sujet.txt"
    form_class = DemandeReinitialisationForm
    success_url = reverse_lazy("comptes:mot_de_passe_envoye")


class ReinitialisationEnvoyee(PasswordResetDoneView):
    """Étape 2 : confirmation de l'envoi."""

    template_name = "registration/mot_de_passe_envoye.html"


class ReinitialisationConfirmation(PasswordResetConfirmView):
    """Étape 3 : saisie du nouveau mot de passe, via le lien reçu."""

    template_name = "registration/mot_de_passe_nouveau.html"
    form_class = NouveauMotDePasseForm
    success_url = reverse_lazy("comptes:mot_de_passe_termine")


class ReinitialisationTerminee(PasswordResetCompleteView):
    """Étape 4 : confirmation finale."""

    template_name = "registration/mot_de_passe_termine.html"
