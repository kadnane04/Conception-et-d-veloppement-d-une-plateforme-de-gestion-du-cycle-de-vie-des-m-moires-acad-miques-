"""
Enregistrement dans l'administration Django.

L'administration native reste un filet de sécurité technique ; la gestion
quotidienne des comptes passe par le module Administrateur de la plateforme.
"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import (
    JournalActivite, ProfilEtudiant, ProfilProfesseur,
    ProfilResponsableAcademique, ProfilResponsableEtudes, Utilisateur,
)


@admin.register(Utilisateur)
class UtilisateurAdmin(UserAdmin):
    ordering = ["nom", "prenom"]
    list_display = ["email", "nom", "prenom", "role", "is_active", "date_creation"]
    list_filter = ["role", "is_active"]
    search_fields = ["email", "nom", "prenom"]
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("Identité", {"fields": ("nom", "prenom", "date_naissance", "telephone")}),
        ("Rôle et accès", {"fields": ("role", "is_active", "is_staff", "is_superuser")}),
        ("Dates", {"fields": ("date_creation", "dernier_acces", "last_login")}),
    )
    readonly_fields = ["date_creation", "dernier_acces", "last_login"]
    add_fieldsets = (
        (None, {"classes": ("wide",),
                "fields": ("email", "nom", "prenom", "role", "password1", "password2")}),
    )


admin.site.register([ProfilEtudiant, ProfilProfesseur,
                     ProfilResponsableEtudes, ProfilResponsableAcademique])


@admin.register(JournalActivite)
class JournalActiviteAdmin(admin.ModelAdmin):
    list_display = ["horodatage", "type_activite", "libelle", "auteur"]
    list_filter = ["type_activite"]
    search_fields = ["libelle"]


admin.site.site_header = "GCVM — administration technique"
admin.site.site_title = "GCVM"
