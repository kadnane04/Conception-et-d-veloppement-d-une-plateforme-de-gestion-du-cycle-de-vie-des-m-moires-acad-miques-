"""
Tests du modèle utilisateur et de l'authentification.

Chaque test vérifie une règle énoncée dans le cahier des charges, et non une
ligne de code : c'est ce qui rend la suite utile quand le code change.
"""

from django.contrib.auth import get_user_model
from django.core import mail
from django.test import TestCase
from django.urls import reverse

from .models import (
    Activite, Filiere, Grade, JournalActivite, ProfilEtudiant, ProfilProfesseur,
    Role, StatutProfesseur, Utilisateur,
)

MDP = "Plateforme@2026"


def creer_admin(email="admin.test@lbs.com"):
    return Utilisateur.objects.create_user(
        email=email, password=MDP, nom="Admin", prenom="Test",
        role=Role.ADMINISTRATEUR, is_staff=True, is_superuser=True)


class ModeleUtilisateurTest(TestCase):

    def test_email_sert_d_identifiant(self):
        self.assertEqual(get_user_model().USERNAME_FIELD, "email")

    def test_email_unique_tous_roles_confondus(self):
        Utilisateur.objects.create_user(
            email="doublon@lbs.com", password=MDP, nom="A", prenom="B", role=Role.ETUDIANT)
        with self.assertRaises(Exception):
            Utilisateur.objects.create_user(
                email="doublon@lbs.com", password=MDP, nom="C", prenom="D",
                role=Role.PROFESSEUR)

    def test_email_normalise_en_minuscules(self):
        u = Utilisateur.objects.create_user(
            email="  Grande.CASSE@LBS.com ", password=MDP, nom="A", prenom="B",
            role=Role.ETUDIANT)
        self.assertEqual(u.email, "grande.casse@lbs.com")

    def test_mot_de_passe_est_hache(self):
        u = Utilisateur.objects.create_user(
            email="hach@lbs.com", password=MDP, nom="A", prenom="B", role=Role.ETUDIANT)
        self.assertNotEqual(u.password, MDP)
        self.assertTrue(u.password.startswith("pbkdf2_"))
        self.assertTrue(u.check_password(MDP))

    def test_proprietes_de_role(self):
        u = creer_admin("r@lbs.com")
        self.assertTrue(u.est_administrateur)
        self.assertFalse(u.est_etudiant)

    def test_profil_absent_ne_leve_pas_d_erreur(self):
        u = Utilisateur.objects.create_user(
            email="sansprofil@lbs.com", password=MDP, nom="A", prenom="B",
            role=Role.ETUDIANT)
        self.assertIsNone(u.profil)

    def test_dates_renseignees_a_la_creation(self):
        u = creer_admin("dates@lbs.com")
        self.assertIsNotNone(u.date_creation)
        self.assertIsNone(u.dernier_acces)


class ProfilProfesseurTest(TestCase):
    """Le point le plus structurant du cahier des charges : un professeur,
    un seul compte, quelles que soient ses responsabilités."""

    def setUp(self):
        self.prof = Utilisateur.objects.create_user(
            email="prof@lbs.com", password=MDP, nom="MENSAH", prenom="Yao",
            role=Role.PROFESSEUR)

    def _profil(self, statut):
        return ProfilProfesseur.objects.create(
            utilisateur=self.prof, grade=Grade.DOCTEUR,
            specialite="Finance", statut=statut)

    def test_encadreur_seul(self):
        p = self._profil(StatutProfesseur.ENCADREUR)
        self.assertTrue(p.est_encadreur)
        self.assertFalse(p.est_jury)

    def test_jury_seul(self):
        p = self._profil(StatutProfesseur.JURY)
        self.assertFalse(p.est_encadreur)
        self.assertTrue(p.est_jury)

    def test_cumul_des_deux_responsabilites_sur_un_seul_compte(self):
        p = self._profil(StatutProfesseur.ENCADREUR_JURY)
        self.assertTrue(p.est_encadreur)
        self.assertTrue(p.est_jury)
        self.assertEqual(Utilisateur.objects.filter(email="prof@lbs.com").count(), 1)

    def test_changement_de_statut_sans_nouveau_compte(self):
        p = self._profil(StatutProfesseur.ENCADREUR)
        p.statut = StatutProfesseur.ENCADREUR_JURY
        p.save()
        self.assertEqual(Utilisateur.objects.filter(role=Role.PROFESSEUR).count(), 1)
        self.assertTrue(p.est_jury)

    def test_profil_accessible_depuis_l_utilisateur(self):
        self._profil(StatutProfesseur.JURY)
        self.assertEqual(self.prof.profil.specialite, "Finance")


class AdminInitialTest(TestCase):
    """Le compte d'amorçage doit exister après le premier migrate."""

    def test_compte_admin_initial_present(self):
        admin = Utilisateur.objects.filter(email="admin@lbs.com").first()
        self.assertIsNotNone(admin, "Le compte administrateur initial est absent.")
        self.assertEqual(admin.role, Role.ADMINISTRATEUR)
        self.assertTrue(admin.is_active)

    def test_mot_de_passe_initial_valide_et_hache(self):
        admin = Utilisateur.objects.get(email="admin@lbs.com")
        self.assertNotIn("admin1234567890", admin.password)
        self.assertTrue(admin.check_password("admin1234567890"))


class ConnexionTest(TestCase):

    def setUp(self):
        self.utilisateur = creer_admin()

    def test_page_de_connexion_accessible(self):
        reponse = self.client.get(reverse("comptes:connexion"))
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "Mot de passe oublié")

    def test_aucune_page_d_inscription_publique(self):
        for chemin in ["/inscription/", "/signup/", "/register/", "/comptes/inscription/"]:
            self.assertEqual(self.client.get(chemin).status_code, 404, chemin)

    def test_connexion_reussie(self):
        reponse = self.client.post(reverse("comptes:connexion"), {
            "email": "admin.test@lbs.com", "mot_de_passe": MDP}, follow=True)
        self.assertEqual(reponse.status_code, 200)
        self.assertTrue(reponse.context["user"].is_authenticated)

    def test_connexion_insensible_a_la_casse_de_l_email(self):
        reponse = self.client.post(reverse("comptes:connexion"), {
            "email": "ADMIN.TEST@LBS.COM", "mot_de_passe": MDP}, follow=True)
        self.assertTrue(reponse.context["user"].is_authenticated)

    def test_mauvais_mot_de_passe_refuse(self):
        reponse = self.client.post(reverse("comptes:connexion"), {
            "email": "admin.test@lbs.com", "mot_de_passe": "faux"})
        self.assertFalse(reponse.context["user"].is_authenticated)
        self.assertContains(reponse, "incorrect")

    def test_message_identique_si_le_compte_n_existe_pas(self):
        """Le message ne doit pas révéler l'existence d'un compte."""
        inconnu = self.client.post(reverse("comptes:connexion"), {
            "email": "personne@lbs.com", "mot_de_passe": "faux"})
        connu = self.client.post(reverse("comptes:connexion"), {
            "email": "admin.test@lbs.com", "mot_de_passe": "faux"})
        self.assertContains(inconnu, "incorrect")
        self.assertContains(connu, "incorrect")

    def test_compte_desactive_ne_peut_pas_se_connecter(self):
        self.utilisateur.is_active = False
        self.utilisateur.save()
        reponse = self.client.post(reverse("comptes:connexion"), {
            "email": "admin.test@lbs.com", "mot_de_passe": MDP})
        self.assertFalse(reponse.context["user"].is_authenticated)

    def test_connexion_journalisee(self):
        self.client.post(reverse("comptes:connexion"), {
            "email": "admin.test@lbs.com", "mot_de_passe": MDP})
        self.assertTrue(JournalActivite.objects.filter(
            type_activite=Activite.CONNEXION).exists())

    def test_deconnexion(self):
        self.client.force_login(self.utilisateur)
        reponse = self.client.post(reverse("comptes:deconnexion"), follow=True)
        self.assertFalse(reponse.context["user"].is_authenticated)

    def test_dernier_acces_mis_a_jour(self):
        self.client.force_login(self.utilisateur)
        self.client.get(reverse("comptes:redirection"))
        self.utilisateur.refresh_from_db()
        self.assertIsNotNone(self.utilisateur.dernier_acces)


class ProtectionDesRoutesTest(TestCase):

    def setUp(self):
        self.admin = creer_admin()
        self.etudiant = Utilisateur.objects.create_user(
            email="etu@lbs.com", password=MDP, nom="KOSSI", prenom="Ama",
            role=Role.ETUDIANT)
        ProfilEtudiant.objects.create(
            utilisateur=self.etudiant, filiere=Filiere.MANAGEMENT)

    def test_visiteur_anonyme_redirige_vers_la_connexion(self):
        reponse = self.client.get(reverse("administration:tableau_de_bord"))
        self.assertEqual(reponse.status_code, 302)
        self.assertIn("connexion", reponse.url)

    def test_etudiant_ne_peut_pas_entrer_dans_l_administration(self):
        self.client.force_login(self.etudiant)
        reponse = self.client.get(reverse("administration:tableau_de_bord"), follow=True)
        # L'étudiant est renvoyé vers son propre espace, pas vers l'administration.
        self.assertEqual(reponse.status_code, 200)
        self.assertTrue(reponse.redirect_chain[-1][0].startswith("/etudiant/"))

    def test_administrateur_accede_au_tableau_de_bord(self):
        self.client.force_login(self.admin)
        self.assertEqual(
            self.client.get(reverse("administration:tableau_de_bord")).status_code, 200)

    def test_aiguillage_apres_connexion(self):
        self.client.force_login(self.admin)
        self.assertIn("/administration/",
                      self.client.get(reverse("comptes:redirection")).url)
        self.client.force_login(self.etudiant)
        self.assertIn("/etudiant/",
                      self.client.get(reverse("comptes:redirection")).url)


class MotDePasseOublieTest(TestCase):

    def setUp(self):
        self.utilisateur = creer_admin("oubli@lbs.com")

    def test_formulaire_accessible(self):
        self.assertEqual(
            self.client.get(reverse("comptes:mot_de_passe_oublie")).status_code, 200)

    def test_email_envoye_pour_un_compte_existant(self):
        self.client.post(reverse("comptes:mot_de_passe_oublie"), {"email": "oubli@lbs.com"})
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("mot-de-passe-oublie", mail.outbox[0].body)

    def test_aucun_email_pour_une_adresse_inconnue_mais_meme_reponse(self):
        reponse = self.client.post(reverse("comptes:mot_de_passe_oublie"),
                                   {"email": "inconnu@lbs.com"}, follow=True)
        self.assertEqual(len(mail.outbox), 0)
        self.assertEqual(reponse.status_code, 200)

    def test_aucun_email_pour_un_compte_desactive(self):
        self.utilisateur.is_active = False
        self.utilisateur.save()
        self.client.post(reverse("comptes:mot_de_passe_oublie"), {"email": "oubli@lbs.com"})
        self.assertEqual(len(mail.outbox), 0)

    def test_parcours_complet(self):
        import re
        self.client.post(reverse("comptes:mot_de_passe_oublie"), {"email": "oubli@lbs.com"})
        lien = re.search(r"(/mot-de-passe-oublie/[^/\s]+/[^/\s]+/)",
                         mail.outbox[0].body.replace("=\n", "")).group(1)
        reponse = self.client.get(lien, follow=True)
        self.client.post(reponse.redirect_chain[-1][0] if reponse.redirect_chain else lien,
                         {"new_password1": "NouveauMdp@2026",
                          "new_password2": "NouveauMdp@2026"}, follow=True)
        self.utilisateur.refresh_from_db()
        self.assertTrue(self.utilisateur.check_password("NouveauMdp@2026"))


class EspacePersonnelTest(TestCase):

    def setUp(self):
        self.utilisateur = creer_admin()
        self.client.force_login(self.utilisateur)

    def test_profil_accessible(self):
        self.assertEqual(self.client.get(reverse("comptes:mon_profil")).status_code, 200)

    def test_modification_du_profil(self):
        self.client.post(reverse("comptes:mon_profil"), {
            "nom": "ADMIN", "prenom": "Modifié", "date_naissance": "", "telephone": "90000000"})
        self.utilisateur.refresh_from_db()
        self.assertEqual(self.utilisateur.prenom, "Modifié")

    def test_changement_de_mot_de_passe(self):
        reponse = self.client.post(reverse("comptes:changer_mot_de_passe"), {
            "mot_de_passe_actuel": MDP,
            "nouveau": "AutreMdp@2026", "confirmation": "AutreMdp@2026"}, follow=True)
        self.utilisateur.refresh_from_db()
        self.assertTrue(self.utilisateur.check_password("AutreMdp@2026"))
        # La session reste ouverte après le changement.
        self.assertTrue(reponse.context["user"].is_authenticated)

    def test_mauvais_mot_de_passe_actuel_refuse(self):
        self.client.post(reverse("comptes:changer_mot_de_passe"), {
            "mot_de_passe_actuel": "faux",
            "nouveau": "AutreMdp@2026", "confirmation": "AutreMdp@2026"})
        self.utilisateur.refresh_from_db()
        self.assertTrue(self.utilisateur.check_password(MDP))

    def test_confirmation_differente_refusee(self):
        self.client.post(reverse("comptes:changer_mot_de_passe"), {
            "mot_de_passe_actuel": MDP,
            "nouveau": "AutreMdp@2026", "confirmation": "PasPareil@2026"})
        self.utilisateur.refresh_from_db()
        self.assertTrue(self.utilisateur.check_password(MDP))
