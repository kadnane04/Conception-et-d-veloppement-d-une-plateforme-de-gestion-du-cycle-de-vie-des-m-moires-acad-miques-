"""
Envoi des emails en développement.

Le backend « console » de Django affiche le message brut, encodé en
quoted-printable : les accents deviennent `=C3=A9` et les longues URL sont
coupées par des `=` en fin de ligne. Le lien de réinitialisation devient alors
pénible à récupérer — exactement au moment où l'on veut le montrer.

Ce backend affiche en plus un bloc lisible : destinataire, objet, corps
décodé, et le lien isolé sur une seule ligne.
"""

import re

from django.core.mail.backends.console import EmailBackend as BackendConsole

MOTIF_LIEN = re.compile(r"https?://\S+")


class BackendConsoleLisible(BackendConsole):

    def write_message(self, message):
        resultat = super().write_message(message)

        corps = message.body or ""
        liens = MOTIF_LIEN.findall(corps)

        self.stream.write("\n" + "═" * 78 + "\n")
        self.stream.write("  EMAIL (mode développement — rien n'est envoyé sur internet)\n")
        self.stream.write("─" * 78 + "\n")
        self.stream.write(f"  Destinataire : {', '.join(message.to)}\n")
        self.stream.write(f"  Objet        : {message.subject}\n")
        self.stream.write("─" * 78 + "\n")
        for ligne in corps.splitlines():
            self.stream.write(f"  {ligne}\n")
        if liens:
            self.stream.write("─" * 78 + "\n")
            self.stream.write("  LIEN À OUVRIR (copiez-le dans votre navigateur) :\n")
            for lien in liens:
                self.stream.write(f"  {lien}\n")
        self.stream.write("═" * 78 + "\n\n")
        self.stream.flush()
        return resultat
