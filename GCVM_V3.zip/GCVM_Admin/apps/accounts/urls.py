"""Routes d'authentification et d'espace personnel."""

from django.urls import path
from django.views.generic import RedirectView

from . import views

app_name = "comptes"

urlpatterns = [
    # La racine mène à la connexion : il n'y a pas de page publique.
    path("", RedirectView.as_view(pattern_name="comptes:connexion", permanent=False),
         name="accueil"),

    path("connexion/", views.connexion, name="connexion"),
    path("deconnexion/", views.deconnexion, name="deconnexion"),
    path("redirection/", views.redirection, name="redirection"),
    path("espace/", views.espace_en_preparation, name="espace_en_preparation"),

    path("mon-profil/", views.mon_profil, name="mon_profil"),
    path("mon-profil/mot-de-passe/", views.changer_mot_de_passe, name="changer_mot_de_passe"),

    # Mot de passe oublié — les quatre étapes
    path("mot-de-passe-oublie/",
         views.DemandeReinitialisation.as_view(), name="mot_de_passe_oublie"),
    path("mot-de-passe-oublie/envoye/",
         views.ReinitialisationEnvoyee.as_view(), name="mot_de_passe_envoye"),
    path("mot-de-passe-oublie/<uidb64>/<token>/",
         views.ReinitialisationConfirmation.as_view(), name="password_reset_confirm"),
    path("mot-de-passe-oublie/termine/",
         views.ReinitialisationTerminee.as_view(), name="mot_de_passe_termine"),
]
