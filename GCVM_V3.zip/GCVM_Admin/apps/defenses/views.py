"""
Soutenance vue par l'étudiant.

La planification et la clôture relèvent du Responsable des Études
(`apps.etudes`) ; l'évaluation relève du jury (`apps.jury`). Ne reste ici que
la page où l'étudiant consulte sa propre soutenance.
"""

from django.shortcuts import render

from apps.accounts.gardes import etudiant_requis
from apps.defenses.models import StatutParticipation


@etudiant_requis
def ma_soutenance(requete):
    memoire = (requete.user.memoires
               .select_related("theme", "encadreur", "annee_academique")
               .order_by("-date_creation").first())
    soutenance = getattr(memoire, "soutenance", None) if memoire else None

    membres = []
    if soutenance is not None:
        # L'étudiant voit les membres qui ont accepté : un jury en cours de
        # composition ne lui est pas montré à moitié constitué.
        membres = soutenance.participations.filter(
            statut=StatutParticipation.ACCEPTE)

    return render(requete, "defenses/ma_soutenance.html", {
        "rubrique": "soutenance", "memoire": memoire, "soutenance": soutenance,
        "membres": membres,
    })
