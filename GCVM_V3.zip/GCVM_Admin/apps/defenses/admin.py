"""Administration Django du module « defenses » — phase ultérieure."""
