"""Tests du module « defenses » — phase ultérieure."""
