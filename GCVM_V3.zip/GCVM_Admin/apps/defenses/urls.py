"""Routes des soutenances — côté étudiant."""

from django.urls import path

from . import views

app_name = "soutenances"

urlpatterns = [
    path("ma-soutenance/", views.ma_soutenance, name="ma_soutenance"),
]
