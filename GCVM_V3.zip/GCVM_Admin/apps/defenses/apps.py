from django.apps import AppConfig


class DefensesConfig(AppConfig):
    """Soutenances : salles, séances, jurys et évaluations."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.defenses"
    verbose_name = "Soutenances"
