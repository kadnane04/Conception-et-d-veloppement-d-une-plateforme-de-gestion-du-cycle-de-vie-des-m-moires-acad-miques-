"""
Soutenances : salles, séances, jurys et évaluations.

Deux points de conception se défendent ici.

1. **Le jury n'est pas un rôle de compte.**
   Le cahier des charges est explicite : « Les jurys sont des enseignants
   existants. Ne jamais créer un rôle séparé Jury. Tout enseignant peut
   devenir jury. »

   `ParticipationJury` est donc une **association** entre une soutenance et un
   compte professeur, portant son propre statut. Un enseignant peut siéger au
   jury d'une soutenance, encadrer un autre mémoire, et n'avoir aucun rôle sur
   un troisième — avec un seul et même compte.

2. **Une salle ne peut pas accueillir deux soutenances qui se chevauchent.**
   Aucune contrainte `UNIQUE` n'exprime un recouvrement d'intervalles : deux
   créneaux différents peuvent parfaitement se chevaucher. Le contrôle est
   donc fait dans `clean()`, qui interroge les séances déjà programmées dans
   la même salle le même jour.
"""

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone


class Salle(models.Model):
    """Salle où se tiennent les soutenances."""

    nom = models.CharField("Nom", max_length=80, unique=True)
    batiment = models.CharField("Bâtiment", max_length=80, blank=True)
    capacite = models.PositiveSmallIntegerField("Capacité", default=30)
    est_active = models.BooleanField("Disponible", default=True)

    class Meta:
        verbose_name = "Salle"
        verbose_name_plural = "Salles"
        ordering = ["nom"]

    def __str__(self):
        return f"{self.nom}{f' ({self.batiment})' if self.batiment else ''}"


class StatutSoutenance(models.TextChoices):
    EN_COMPOSITION = "EN_COMPOSITION", "Jury en cours de composition"
    CONFIRMEE = "CONFIRMEE", "Confirmée"
    TENUE = "TENUE", "Tenue"
    ANNULEE = "ANNULEE", "Annulée"


class Soutenance(models.Model):
    """Une séance de soutenance, pour un mémoire."""

    memoire = models.OneToOneField(
        "memories.Memoire", verbose_name="Mémoire", on_delete=models.CASCADE,
        related_name="soutenance")

    date_soutenance = models.DateField("Date")
    heure_debut = models.TimeField("Heure de début")
    heure_fin = models.TimeField("Heure de fin")
    salle = models.ForeignKey(
        Salle, verbose_name="Salle", on_delete=models.PROTECT,
        related_name="soutenances")

    statut = models.CharField(
        "Statut", max_length=20, choices=StatutSoutenance.choices,
        default=StatutSoutenance.EN_COMPOSITION)

    planifiee_par = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Planifiée par",
        on_delete=models.SET_NULL, null=True, blank=True,
        related_name="soutenances_planifiees")
    date_planification = models.DateTimeField("Planifiée le", default=timezone.now)

    # Résultat, renseigné après la séance.
    note_finale = models.DecimalField(
        "Note finale / 20", max_digits=4, decimal_places=2, null=True, blank=True)
    mention = models.CharField("Mention", max_length=40, blank=True)
    deliberation = models.TextField("Délibération du jury", blank=True)
    date_tenue = models.DateTimeField("Tenue le", null=True, blank=True)

    class Meta:
        verbose_name = "Soutenance"
        verbose_name_plural = "Soutenances"
        ordering = ["date_soutenance", "heure_debut"]
        indexes = [models.Index(fields=["date_soutenance", "salle"])]

    def __str__(self):
        return f"{self.memoire.etudiant} — {self.date_soutenance:%d/%m/%Y} {self.heure_debut:%H:%M}"

    # -- Contrôles ---------------------------------------------------------
    def clean(self):
        erreurs = {}

        if self.heure_debut and self.heure_fin and self.heure_fin <= self.heure_debut:
            erreurs["heure_fin"] = "L'heure de fin doit suivre l'heure de début."

        if self.date_soutenance and self.date_soutenance < timezone.localdate():
            erreurs["date_soutenance"] = "La date de soutenance est déjà passée."

        # Recouvrement de créneau dans la même salle. Deux séances se
        # chevauchent si chacune commence avant que l'autre ne finisse.
        if self.date_soutenance and self.heure_debut and self.heure_fin and self.salle_id:
            conflits = (Soutenance.objects
                        .filter(salle_id=self.salle_id,
                                date_soutenance=self.date_soutenance,
                                statut__in=[StatutSoutenance.EN_COMPOSITION,
                                            StatutSoutenance.CONFIRMEE])
                        .exclude(pk=self.pk)
                        .filter(heure_debut__lt=self.heure_fin,
                                heure_fin__gt=self.heure_debut))
            if conflits.exists():
                autre = conflits.first()
                erreurs["salle"] = (
                    f"La salle est déjà occupée ce jour-là de "
                    f"{autre.heure_debut:%H:%M} à {autre.heure_fin:%H:%M} "
                    f"({autre.memoire.etudiant}).")

        if erreurs:
            raise ValidationError(erreurs)

    # -- Jury ---------------------------------------------------------------
    @property
    def participations(self):
        return self.membres.select_related("enseignant", "enseignant__profilprofesseur")

    @property
    def nb_acceptes(self):
        return self.membres.filter(statut=StatutParticipation.ACCEPTE).count()

    @property
    def nb_attendus(self):
        """Membres encore susceptibles de répondre (acceptés ou en attente)."""
        return self.membres.exclude(statut=StatutParticipation.REFUSE).count()

    @property
    def nb_refus(self):
        return self.membres.filter(statut=StatutParticipation.REFUSE).count()

    @property
    def minimum_requis(self):
        return settings.GCVM["NB_MIN_MEMBRES_JURY"]

    @property
    def jury_complet(self):
        """
        La soutenance n'est confirmée que lorsque tous les membres retenus ont
        accepté, et qu'ils sont au moins aussi nombreux que le minimum exigé.
        """
        en_attente = self.membres.filter(statut=StatutParticipation.EN_ATTENTE).count()
        return en_attente == 0 and self.nb_acceptes >= self.minimum_requis

    @property
    def manque_des_membres(self):
        return self.nb_acceptes + self.membres.filter(
            statut=StatutParticipation.EN_ATTENTE).count() < self.minimum_requis

    def rafraichir_statut(self):
        """
        Confirme la soutenance dès que le jury est au complet.

        Le mémoire suit : une soutenance confirmée le fait passer en
        « soutenance programmée ». Cet enchaînement est un invariant du
        modèle, pas une politique d'écran — le placer ici garantit qu'il vaut
        quel que soit le chemin emprunté (vue du jury, vue du Responsable des
        Études, commande de chargement).
        """
        if self.statut in {StatutSoutenance.TENUE, StatutSoutenance.ANNULEE}:
            return self.statut

        nouveau = (StatutSoutenance.CONFIRMEE if self.jury_complet
                   else StatutSoutenance.EN_COMPOSITION)
        if nouveau != self.statut:
            self.statut = nouveau
            self.save(update_fields=["statut"])

        if nouveau == StatutSoutenance.CONFIRMEE:
            from apps.memories.models import StatutMemoire

            memoire = self.memoire
            if memoire.statut == StatutMemoire.VALIDE_RESP_ACADEMIQUE:
                memoire.statut = StatutMemoire.SOUTENANCE_PLANIFIEE
                memoire.save(update_fields=["statut"])
        return self.statut

    @property
    def couleur_statut(self):
        return {StatutSoutenance.EN_COMPOSITION: "ambre",
                StatutSoutenance.CONFIRMEE: "vert",
                StatutSoutenance.TENUE: "bleu",
                StatutSoutenance.ANNULEE: "rouge"}.get(self.statut, "gris")

    @property
    def est_passee(self):
        return self.date_soutenance < timezone.localdate()

    # -- Résultat ----------------------------------------------------------
    @property
    def notes_du_jury(self):
        return [e.note for e in Evaluation.objects.filter(
            participation__soutenance=self, note__isnull=False)]

    @property
    def moyenne_du_jury(self):
        notes = self.notes_du_jury
        if not notes:
            return None
        return round(sum(notes) / len(notes), 2)


def mention_pour_note(note):
    """Barème des mentions. Une seule définition, utilisée partout."""
    if note is None:
        return ""
    note = float(note)
    if note >= 16:
        return "Très bien"
    if note >= 14:
        return "Bien"
    if note >= 12:
        return "Assez bien"
    if note >= 10:
        return "Passable"
    return "Insuffisant"


class RoleJury(models.TextChoices):
    PRESIDENT = "PRESIDENT", "Président du jury"
    RAPPORTEUR = "RAPPORTEUR", "Rapporteur"
    MEMBRE = "MEMBRE", "Membre"
    ENCADREUR = "ENCADREUR", "Encadreur (membre de droit)"


class StatutParticipation(models.TextChoices):
    EN_ATTENTE = "EN_ATTENTE", "En attente"
    ACCEPTE = "ACCEPTE", "Accepté"
    REFUSE = "REFUSE", "Refusé"
    REMPLACE = "REMPLACE", "Remplacé"


class ParticipationJury(models.Model):
    """
    Un enseignant siégeant au jury d'une soutenance.

    C'est une association, pas un rôle de compte : le même enseignant peut
    siéger ici, encadrer ailleurs, et n'avoir aucune fonction sur un troisième
    dossier — toujours avec le même compte.
    """

    soutenance = models.ForeignKey(
        Soutenance, verbose_name="Soutenance", on_delete=models.CASCADE,
        related_name="membres")
    enseignant = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Enseignant",
        on_delete=models.CASCADE, related_name="participations_jury",
        limit_choices_to={"role": "PROFESSEUR"})

    role = models.CharField("Rôle", max_length=15, choices=RoleJury.choices,
                            default=RoleJury.MEMBRE)
    statut = models.CharField("Statut", max_length=15,
                              choices=StatutParticipation.choices,
                              default=StatutParticipation.EN_ATTENTE)

    motif_refus = models.TextField("Motif du refus", blank=True)
    observations = models.TextField(
        "Observations avant la soutenance", blank=True,
        help_text="Notes de lecture, points à aborder le jour de la séance.")

    remplace = models.ForeignKey(
        "self", verbose_name="Remplace", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="remplacants")

    date_invitation = models.DateTimeField("Invité le", default=timezone.now)
    date_reponse = models.DateTimeField("A répondu le", null=True, blank=True)

    class Meta:
        verbose_name = "Membre du jury"
        verbose_name_plural = "Membres du jury"
        ordering = ["role", "enseignant__nom"]
        constraints = [
            # Un enseignant ne siège qu'une fois dans le même jury.
            models.UniqueConstraint(fields=["soutenance", "enseignant"],
                                    name="ux_jury_enseignant_unique"),
            # Un seul président par soutenance, parmi les membres encore actifs.
            models.UniqueConstraint(
                fields=["soutenance"],
                condition=models.Q(role="PRESIDENT") & ~models.Q(statut="REFUSE")
                          & ~models.Q(statut="REMPLACE"),
                name="ux_jury_un_seul_president"),
        ]

    def __str__(self):
        return f"{self.enseignant} — {self.get_role_display()}"

    @property
    def est_acceptee(self):
        return self.statut == StatutParticipation.ACCEPTE

    @property
    def couleur_statut(self):
        return {StatutParticipation.EN_ATTENTE: "ambre",
                StatutParticipation.ACCEPTE: "vert",
                StatutParticipation.REFUSE: "rouge",
                StatutParticipation.REMPLACE: "gris"}.get(self.statut, "gris")

    def accepter(self):
        self.statut = StatutParticipation.ACCEPTE
        self.date_reponse = timezone.now()
        self.motif_refus = ""
        self.save(update_fields=["statut", "date_reponse", "motif_refus"])
        return self.soutenance.rafraichir_statut()

    def refuser(self, motif=""):
        self.statut = StatutParticipation.REFUSE
        self.date_reponse = timezone.now()
        self.motif_refus = motif
        self.save(update_fields=["statut", "date_reponse", "motif_refus"])
        return self.soutenance.rafraichir_statut()


class Evaluation(models.Model):
    """Note et appréciation d'un membre du jury, après la soutenance."""

    participation = models.OneToOneField(
        ParticipationJury, verbose_name="Membre du jury",
        on_delete=models.CASCADE, related_name="evaluation")

    note = models.DecimalField(
        "Note / 20", max_digits=4, decimal_places=2, null=True, blank=True)
    commentaire = models.TextField("Appréciation", blank=True)
    recommandations = models.TextField(
        "Recommandations de correction", blank=True,
        help_text="Ce que l'étudiant doit reprendre avant sa version finale.")

    date_saisie = models.DateTimeField("Saisie le", default=timezone.now)

    class Meta:
        verbose_name = "Évaluation du jury"
        verbose_name_plural = "Évaluations du jury"
        ordering = ["-date_saisie"]

    def __str__(self):
        return f"{self.participation} — {self.note or '—'}/20"

    def clean(self):
        if self.note is not None and not (0 <= float(self.note) <= 20):
            raise ValidationError({"note": "La note doit être comprise entre 0 et 20."})

    @property
    def mention(self):
        return mention_pour_note(self.note)
