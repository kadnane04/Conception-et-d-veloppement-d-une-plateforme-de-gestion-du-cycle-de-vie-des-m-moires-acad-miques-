"""Compteur de notifications non lues, disponible dans tous les gabarits."""

from .models import Notification


def notifications(requete):
    utilisateur = getattr(requete, "user", None)
    if utilisateur is None or not utilisateur.is_authenticated:
        return {"nb_notifications": 0, "dernieres_notifications": []}
    return {
        "nb_notifications": Notification.compteur(utilisateur),
        "dernieres_notifications": Notification.objects.pour(utilisateur)[:6],
    }
