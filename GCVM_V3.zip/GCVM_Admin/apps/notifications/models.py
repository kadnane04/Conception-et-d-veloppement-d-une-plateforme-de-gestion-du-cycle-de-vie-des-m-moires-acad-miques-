"""
Notifications internes.

Une notification est écrite **en toutes lettres au moment où l'événement se
produit**, et non recalculée à l'affichage. Si le thème est supprimé six mois
plus tard, la phrase « Votre thème a été validé » reste lisible : elle raconte
ce qui s'est passé, pas l'état actuel de la base.
"""

from django.conf import settings
from django.db import models
from django.utils import timezone


class TypeNotification(models.TextChoices):
    THEME_VALIDE = "THEME_VALIDE", "Thème validé"
    THEME_REJETE = "THEME_REJETE", "Thème rejeté"
    THEME_SOUMIS = "THEME_SOUMIS", "Thème soumis"
    ENCADREUR_DEMANDE = "ENCADREUR_DEMANDE", "Demande d'encadrement"
    ENCADREUR_ACCEPTE = "ENCADREUR_ACCEPTE", "Encadrement accepté"
    ENCADREUR_REFUSE = "ENCADREUR_REFUSE", "Encadrement refusé"
    MEMOIRE_DEPOSE = "MEMOIRE_DEPOSE", "Mémoire déposé"
    MEMOIRE_VALIDE = "MEMOIRE_VALIDE", "Mémoire validé"
    MEMOIRE_REJETE = "MEMOIRE_REJETE", "Mémoire rejeté"
    JURY_INVITATION = "JURY_INVITATION", "Invitation au jury"
    JURY_REPONSE = "JURY_REPONSE", "Réponse d'un membre du jury"
    SOUTENANCE_PROGRAMMEE = "SOUTENANCE_PROGRAMMEE", "Soutenance programmée"
    INFORMATION = "INFORMATION", "Information"


# Chaque type porte son icône et sa couleur : le rouge reste réservé aux
# refus et aux rejets, conformément à la charte.
APPARENCE = {
    TypeNotification.THEME_VALIDE: ("bi-check-circle", "vert"),
    TypeNotification.THEME_REJETE: ("bi-x-circle", "rouge"),
    TypeNotification.THEME_SOUMIS: ("bi-lightbulb", "bleu"),
    TypeNotification.ENCADREUR_DEMANDE: ("bi-person-raised-hand", "bleu"),
    TypeNotification.ENCADREUR_ACCEPTE: ("bi-person-check", "vert"),
    TypeNotification.ENCADREUR_REFUSE: ("bi-person-x", "rouge"),
    TypeNotification.MEMOIRE_DEPOSE: ("bi-upload", "bleu"),
    TypeNotification.MEMOIRE_VALIDE: ("bi-patch-check", "vert"),
    TypeNotification.MEMOIRE_REJETE: ("bi-exclamation-octagon", "rouge"),
    TypeNotification.JURY_INVITATION: ("bi-people", "bleu"),
    TypeNotification.JURY_REPONSE: ("bi-reply", "bleu"),
    TypeNotification.SOUTENANCE_PROGRAMMEE: ("bi-calendar-check", "vert"),
    TypeNotification.INFORMATION: ("bi-info-circle", "bleu"),
}


class NotificationQuerySet(models.QuerySet):

    def non_lues(self):
        return self.filter(est_lue=False)

    def pour(self, utilisateur):
        return self.filter(destinataire=utilisateur)


class Notification(models.Model):

    destinataire = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Destinataire",
        on_delete=models.CASCADE, related_name="notifications")

    type_notification = models.CharField(
        "Type", max_length=25, choices=TypeNotification.choices,
        default=TypeNotification.INFORMATION)

    titre = models.CharField("Titre", max_length=140)
    message = models.TextField("Message")
    lien = models.CharField(
        "Lien", max_length=300, blank=True,
        help_text="Chemin interne vers la page concernée.")

    est_lue = models.BooleanField("Lue", default=False)
    date_creation = models.DateTimeField("Date", default=timezone.now)
    date_lecture = models.DateTimeField("Lue le", null=True, blank=True)

    objects = NotificationQuerySet.as_manager()

    class Meta:
        verbose_name = "Notification"
        verbose_name_plural = "Notifications"
        ordering = ["-date_creation"]
        indexes = [models.Index(fields=["destinataire", "est_lue", "-date_creation"])]

    def __str__(self):
        return self.titre

    @property
    def icone(self):
        return APPARENCE.get(self.type_notification, ("bi-bell", "bleu"))[0]

    @property
    def couleur(self):
        return APPARENCE.get(self.type_notification, ("bi-bell", "bleu"))[1]

    def marquer_lue(self):
        if not self.est_lue:
            self.est_lue = True
            self.date_lecture = timezone.now()
            self.save(update_fields=["est_lue", "date_lecture"])

    @classmethod
    def envoyer(cls, destinataire, type_notification, titre, message, lien=""):
        """Point d'entrée unique : tous les modules passent par ici."""
        if destinataire is None or not destinataire.pk:
            return None
        return cls.objects.create(
            destinataire=destinataire, type_notification=type_notification,
            titre=titre[:140], message=message, lien=lien)

    @classmethod
    def compteur(cls, utilisateur):
        if not getattr(utilisateur, "is_authenticated", False):
            return 0
        return cls.objects.pour(utilisateur).non_lues().count()
