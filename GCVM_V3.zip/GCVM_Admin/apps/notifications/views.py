"""Consultation des notifications."""

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.conf import settings
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .models import Notification


@login_required
def liste(requete):
    """Page « Mes notifications » : date, message, état lu / non lu."""
    notifications = Notification.objects.pour(requete.user)

    filtre = requete.GET.get("etat", "")
    if filtre == "non-lues":
        notifications = notifications.non_lues()
    elif filtre == "lues":
        notifications = notifications.filter(est_lue=True)

    paginateur = Paginator(notifications, settings.GCVM["ELEMENTS_PAR_PAGE"] * 2)

    return render(requete, "notifications/liste.html", {
        "rubrique": "notifications",
        "page": paginateur.get_page(requete.GET.get("page")),
        "filtre": filtre,
        "total": Notification.objects.pour(requete.user).count(),
        "non_lues": Notification.objects.pour(requete.user).non_lues().count(),
    })


@login_required
def ouvrir(requete, pk):
    """Marque la notification comme lue, puis suit son lien s'il y en a un."""
    notification = get_object_or_404(Notification, pk=pk, destinataire=requete.user)
    notification.marquer_lue()
    return redirect(notification.lien or "notifications:liste")


@login_required
def tout_marquer_lu(requete):
    if requete.method != "POST":
        return redirect("notifications:liste")
    nombre = Notification.objects.pour(requete.user).non_lues().update(
        est_lue=True, date_lecture=timezone.now())
    messages.success(requete, f"{nombre} notification(s) marquée(s) comme lue(s).")
    return redirect("notifications:liste")
