from django.apps import AppConfig


class NotificationsConfig(AppConfig):
    """Notifications internes adressées aux utilisateurs de la plateforme."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.notifications"
    verbose_name = "Notifications"
