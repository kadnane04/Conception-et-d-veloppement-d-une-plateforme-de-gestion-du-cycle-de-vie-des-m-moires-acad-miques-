from django.apps import AppConfig


class EncadreurConfig(AppConfig):
    """Espace Encadreur : demandes, suivi et validation des mémoires encadrés."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.encadreur"
    verbose_name = "Espace Encadreur"
