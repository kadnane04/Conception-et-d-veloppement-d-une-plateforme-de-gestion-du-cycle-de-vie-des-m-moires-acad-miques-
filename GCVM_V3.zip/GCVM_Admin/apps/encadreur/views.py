"""
Espace Encadreur.

Accessible à tout compte professeur. Ce qu'il y voit dépend de ce qu'il fait
réellement : les demandes qu'on lui adresse, les mémoires qu'il encadre, les
soutenances où il siège. Aucun second compte, aucun rôle supplémentaire.
"""

import os

from django.contrib import messages
from django.db.models import Count, Q
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from apps.accounts.gardes import enseignant_requis
from apps.defenses.models import ParticipationJury, StatutParticipation, StatutSoutenance
from apps.memories.models import Memoire, StatutMemoire, VersionMemoire
from apps.memories.services import (
    rejeter_par_encadreur, rejeter_version_finale, valider_par_encadreur,
    valider_version_finale,
)
from apps.notifications.models import Notification, TypeNotification
from apps.supervision.models import DemandeEncadrement, StatutDemande


def memoires_de(enseignant):
    return (Memoire.objects.filter(encadreur=enseignant)
            .select_related("etudiant", "theme", "annee_academique"))


@enseignant_requis
def tableau_de_bord(requete):
    enseignant = requete.user
    profil = enseignant.profil

    memoires = memoires_de(enseignant)
    demandes = (enseignant.demandes_recues
                .select_related("etudiant", "theme")
                .order_by("-date_demande"))

    a_valider = memoires.filter(statut__in=[StatutMemoire.DEPOSE,
                                            StatutMemoire.FINALE_DEPOSEE])

    soutenances = (ParticipationJury.objects
                   .filter(enseignant=enseignant,
                           statut__in=[StatutParticipation.EN_ATTENTE,
                                       StatutParticipation.ACCEPTE],
                           soutenance__date_soutenance__gte=timezone.localdate())
                   .select_related("soutenance", "soutenance__memoire",
                                   "soutenance__memoire__etudiant", "soutenance__salle")
                   .order_by("soutenance__date_soutenance"))

    cartes = [
        {"cle": "encadreur:memoires", "titre": "Étudiants encadrés",
         "valeur": memoires.exclude(statut=StatutMemoire.ARCHIVE).count(),
         "icone": "bi-people", "ton": "bleu"},
        {"cle": "encadreur:demandes", "titre": "Demandes en attente",
         "valeur": demandes.filter(statut=StatutDemande.EN_ATTENTE).count(),
         "icone": "bi-person-raised-hand", "ton": "bleu"},
        {"cle": "encadreur:memoires", "titre": "Mémoires à valider",
         "valeur": a_valider.count(), "icone": "bi-file-earmark-check", "ton": "bleu"},
        {"cle": "jury:mes_soutenances", "titre": "Soutenances à venir",
         "valeur": soutenances.count(), "icone": "bi-calendar-event", "ton": "fonce"},
    ]

    return render(requete, "encadreur/tableau_de_bord.html", {
        "rubrique": "tdb", "profil": profil, "cartes": cartes,
        "demandes_en_attente": demandes.filter(statut=StatutDemande.EN_ATTENTE)[:5],
        "a_valider": a_valider.select_related("etudiant")[:5],
        "soutenances": soutenances[:5],
        "memoires_recents": memoires.order_by("-date_dernier_depot")[:5],
        "places_restantes": profil.places_restantes if profil else 0,
        "quota": profil.quota_encadrement if profil else 0,
    })


# ==========================================================================
# Demandes d'encadrement
# ==========================================================================
@enseignant_requis
def demandes(requete):
    toutes = (requete.user.demandes_recues
              .select_related("etudiant", "etudiant__profiletudiant", "theme")
              .prefetch_related("theme__categories")
              .order_by("-date_demande"))

    filtre = requete.GET.get("statut", "")
    affichees = toutes.filter(statut=filtre) if filtre else toutes

    return render(requete, "encadreur/demandes.html", {
        "rubrique": "demandes", "demandes": affichees, "filtre": filtre,
        "en_attente": toutes.filter(statut=StatutDemande.EN_ATTENTE).count(),
        "statuts": StatutDemande.choices,
        "profil": requete.user.profil,
    })


@enseignant_requis
def repondre_demande(requete, pk, reponse):
    """Accepter ou refuser une demande. Toujours en POST, après confirmation."""
    demande = get_object_or_404(
        DemandeEncadrement.objects.select_related("etudiant", "theme"),
        pk=pk, encadreur=requete.user)

    if requete.method != "POST":
        return redirect("encadreur:demandes")

    if not demande.est_en_attente:
        messages.warning(requete, "Cette demande a déjà été traitée.")
        return redirect("encadreur:demandes")

    if reponse == "accepter":
        demande.accepter()
        Notification.envoyer(
            demande.etudiant, TypeNotification.ENCADREUR_ACCEPTE,
            "Votre encadreur a accepté votre demande",
            f"{requete.user.nom_complet} encadrera votre mémoire. Vous pouvez "
            f"maintenant déposer votre document.", "/memoire/")

        # Le Responsable des Études suit la constitution des binômes.
        from apps.memories.services import responsables_des_etudes
        for responsable in responsables_des_etudes():
            Notification.envoyer(
                responsable, TypeNotification.ENCADREUR_ACCEPTE,
                "Encadrement accepté",
                f"L'enseignant {requete.user.nom_complet} accepte d'encadrer "
                f"{demande.etudiant.nom_complet} sur le thème "
                f"« {demande.theme.titre} ».", "/etudes/encadrements/")

        messages.success(
            requete, f"Vous encadrez désormais {demande.etudiant.nom_complet}.")
    else:
        motif = requete.POST.get("motif", "").strip()
        if not motif:
            messages.error(requete, "Le motif est obligatoire pour refuser une demande.")
            return redirect("encadreur:demandes")
        demande.refuser(motif)
        Notification.envoyer(
            demande.etudiant, TypeNotification.ENCADREUR_REFUSE,
            "Votre demande d'encadrement a été refusée",
            f"{requete.user.nom_complet} n'a pas retenu votre demande. "
            f"Motif : {motif}. Vous pouvez solliciter un autre encadreur.",
            "/encadrement/encadreurs/")
        messages.info(requete, "La demande a été refusée et l'étudiant prévenu.")

    return redirect("encadreur:demandes")


# ==========================================================================
# Mémoires encadrés
# ==========================================================================
@enseignant_requis
def memoires(requete):
    liste = memoires_de(requete.user).order_by("-date_dernier_depot")

    filtre = requete.GET.get("statut", "")
    if filtre == "a-traiter":
        liste = liste.filter(statut__in=[StatutMemoire.DEPOSE,
                                         StatutMemoire.FINALE_DEPOSEE])
    elif filtre:
        liste = liste.filter(statut=filtre)

    return render(requete, "encadreur/memoires.html", {
        "rubrique": "memoires", "memoires": liste, "filtre": filtre,
        "statuts": StatutMemoire.choices,
        "a_traiter": memoires_de(requete.user).filter(
            statut__in=[StatutMemoire.DEPOSE, StatutMemoire.FINALE_DEPOSEE]).count(),
    })


@enseignant_requis
def detail_memoire(requete, pk):
    memoire = get_object_or_404(
        Memoire.objects.select_related("etudiant", "theme", "annee_academique")
        .prefetch_related("versions", "decisions"),
        pk=pk, encadreur=requete.user)

    return render(requete, "encadreur/detail_memoire.html", {
        "rubrique": "memoires", "memoire": memoire,
        "versions": memoire.versions.select_related("depose_par"),
        "decisions": memoire.decisions.select_related("auteur"),
        "soutenance": getattr(memoire, "soutenance", None),
    })


@enseignant_requis
def decider_memoire(requete, pk, decision):
    """Validation ou rejet, du premier dépôt comme de la version finale."""
    memoire = get_object_or_404(Memoire, pk=pk, encadreur=requete.user)

    if requete.method != "POST":
        return redirect("encadreur:detail_memoire", pk=pk)

    finale = memoire.statut == StatutMemoire.FINALE_DEPOSEE
    if not (memoire.attend_encadreur or finale):
        messages.warning(
            requete, "Ce mémoire n'est pas en attente de votre décision.")
        return redirect("encadreur:detail_memoire", pk=pk)

    commentaire = requete.POST.get("commentaire", "").strip()

    if decision == "valider":
        if finale:
            valider_version_finale(memoire, requete.user)
            messages.success(requete, "Version finale validée. Le Responsable des "
                                      "Études peut procéder à l'archivage.")
        else:
            valider_par_encadreur(memoire, requete.user, commentaire)
            messages.success(requete, "Mémoire validé et transmis au Responsable "
                                      "des Études.")
    else:
        if not commentaire:
            messages.error(requete, "Le motif est obligatoire pour rejeter un mémoire.")
            return redirect("encadreur:detail_memoire", pk=pk)
        if finale:
            rejeter_version_finale(memoire, requete.user, commentaire)
        else:
            rejeter_par_encadreur(memoire, requete.user, commentaire)
        messages.info(requete, "Le mémoire a été rejeté et l'étudiant prévenu.")

    return redirect("encadreur:detail_memoire", pk=pk)


@enseignant_requis
def telecharger_version(requete, pk):
    """
    Téléchargement réservé : l'encadreur du mémoire, ou un membre du jury de
    sa soutenance ayant accepté. Les autres obtiennent un 404.
    """
    version = get_object_or_404(
        VersionMemoire.objects.select_related("memoire"), pk=pk)
    memoire = version.memoire

    autorise = memoire.encadreur_id == requete.user.pk
    if not autorise:
        autorise = ParticipationJury.objects.filter(
            soutenance__memoire=memoire, enseignant=requete.user,
            statut=StatutParticipation.ACCEPTE).exists()
    if not autorise:
        raise Http404("Vous n'avez pas accès à ce document.")

    if not version.fichier or not version.fichier.storage.exists(version.fichier.name):
        raise Http404("Le fichier de cette version est introuvable.")

    return FileResponse(
        version.fichier.open("rb"), as_attachment=True,
        filename=version.nom_original or os.path.basename(version.fichier.name))
