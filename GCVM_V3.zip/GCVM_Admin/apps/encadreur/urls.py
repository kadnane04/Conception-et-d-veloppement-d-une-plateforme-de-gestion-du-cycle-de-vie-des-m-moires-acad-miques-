"""Routes de l'espace Encadreur."""

from django.urls import path

from . import views

app_name = "encadreur"

urlpatterns = [
    path("", views.tableau_de_bord, name="tableau_de_bord"),

    path("demandes/", views.demandes, name="demandes"),
    path("demandes/<int:pk>/<slug:reponse>/", views.repondre_demande,
         name="repondre_demande"),

    path("memoires/", views.memoires, name="memoires"),
    path("memoires/<int:pk>/", views.detail_memoire, name="detail_memoire"),
    path("memoires/<int:pk>/<slug:decision>/", views.decider_memoire,
         name="decider_memoire"),

    path("version/<int:pk>/telecharger/", views.telecharger_version,
         name="telecharger_version"),
]
