"""Routes du module Thèmes — côté étudiant."""

from django.urls import path

from . import views

app_name = "themes"

urlpatterns = [
    path("proposer/", views.proposer, name="proposer"),
    path("mes-themes/", views.mes_themes, name="mes_themes"),
    path("<int:pk>/", views.detail, name="detail"),
]
