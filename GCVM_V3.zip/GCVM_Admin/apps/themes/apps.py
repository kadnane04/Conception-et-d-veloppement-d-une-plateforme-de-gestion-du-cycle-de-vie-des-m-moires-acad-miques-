from django.apps import AppConfig


class ThemesConfig(AppConfig):
    """Thèmes de mémoire : catégories, propositions, détection des doublons."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.themes"
    verbose_name = "Thèmes"
