"""Administration Django du module « themes » — phase ultérieure."""
