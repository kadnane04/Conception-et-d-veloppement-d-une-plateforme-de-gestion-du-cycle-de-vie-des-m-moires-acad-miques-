"""
Catégories de thèmes livrées avec la plateforme.

Elles ne sont qu'un point de départ : l'administrateur les modifie, les
désactive ou en ajoute depuis « Référentiels → Catégories de thèmes ». Les
poser ici évite que le premier étudiant se retrouve devant un formulaire dont
la liste des catégories est vide.
"""

from django.db import migrations

CATEGORIES = [
    ("Data Science", "Analyse de données, statistiques appliquées, visualisation.", 10),
    ("Intelligence Artificielle", "Apprentissage automatique, traitement du langage.", 20),
    ("Développement Web", "Applications et services web, front-end et back-end.", 30),
    ("Génie Logiciel", "Méthodes, qualité, architecture et tests logiciels.", 40),
    ("Réseaux", "Infrastructures, protocoles, administration réseau.", 50),
    ("Cybersécurité", "Sécurité des systèmes, audit technique, protection des données.", 60),
    ("Business Intelligence", "Entrepôts de données, tableaux de bord décisionnels.", 70),
    ("Systèmes d'Information", "Urbanisation, ERP, gouvernance du SI.", 80),
    ("Gestion", "Management, organisation, ressources humaines, stratégie.", 90),
    ("Finance", "Finance d'entreprise, comptabilité, contrôle de gestion, audit.", 100),
]


def creer(apps, schema_editor):
    CategorieTheme = apps.get_model("themes", "CategorieTheme")
    for nom, description, ordre in CATEGORIES:
        CategorieTheme.objects.get_or_create(
            nom=nom, defaults={"description": description, "ordre": ordre,
                               "est_active": True})


def supprimer(apps, schema_editor):
    CategorieTheme = apps.get_model("themes", "CategorieTheme")
    CategorieTheme.objects.filter(nom__in=[c[0] for c in CATEGORIES]).delete()


class Migration(migrations.Migration):

    dependencies = [("themes", "0001_initial")]

    operations = [migrations.RunPython(creer, supprimer)]
