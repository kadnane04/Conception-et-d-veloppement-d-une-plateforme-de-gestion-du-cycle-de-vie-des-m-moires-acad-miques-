"""
Thèmes de mémoire.

Deux points méritent d'être défendus en soutenance.

1. **La détection des doublons se fait sur un titre normalisé.**
   « L'Impact du Digital sur la Performance » et « impact du digital sur la
   performance » sont le même sujet. Comparer les titres bruts ne le voit pas.
   Le titre est donc réduit à une forme canonique — minuscules, sans accent,
   sans ponctuation, sans mots vides — avant toute comparaison.

2. **La comparaison est un avertissement, pas un blocage.**
   Deux mémoires peuvent légitimement porter des titres proches sur des
   terrains différents. La plateforme signale, montre les sujets voisins avec
   leur pourcentage de ressemblance, et laisse l'étudiant corriger ou
   confirmer. C'est la décision du Responsable des Études qui tranche.
"""

import re
import unicodedata
from difflib import SequenceMatcher

from django.conf import settings
from django.db import models
from django.utils import timezone

# Mots trop fréquents dans un titre de mémoire pour porter du sens : les
# retirer évite que deux sujets sans rapport se ressemblent artificiellement.
MOTS_VIDES = {
    "le", "la", "les", "un", "une", "des", "du", "de", "d", "l", "au", "aux",
    "et", "ou", "en", "dans", "sur", "sous", "pour", "par", "avec", "sans",
    "cas", "etude", "analyse", "impact", "role", "place", "cadre", "sein",
    "a", "the", "of", "on", "in", "case", "study",
}


def normaliser_titre(titre):
    """Réduit un titre à sa forme canonique, comparable à une autre."""
    texte = unicodedata.normalize("NFD", (titre or "").lower())
    texte = "".join(c for c in texte if unicodedata.category(c) != "Mn")
    texte = re.sub(r"[^a-z0-9\s]", " ", texte)
    mots = [m for m in texte.split() if m and m not in MOTS_VIDES]
    return " ".join(mots)


def score_similarite(titre_a, titre_b):
    """
    Ressemblance entre deux titres, entre 0 et 1.

    Deux mesures combinées : la proportion de mots communs (qui voit les
    reformulations) et la ressemblance caractère par caractère (qui voit les
    variantes d'orthographe). On garde la plus élevée.
    """
    a, b = normaliser_titre(titre_a), normaliser_titre(titre_b)
    if not a or not b:
        return 0.0

    mots_a, mots_b = set(a.split()), set(b.split())
    jaccard = len(mots_a & mots_b) / len(mots_a | mots_b) if (mots_a | mots_b) else 0.0
    sequence = SequenceMatcher(None, a, b).ratio()
    return max(jaccard, sequence)


class CategorieTheme(models.Model):
    """
    Domaine auquel un thème se rattache.

    Les catégories sont créées par l'administration : l'étudiant choisit
    dans une liste, il n'en invente pas. C'est ce qui rend les statistiques
    par domaine exploitables.
    """

    nom = models.CharField("Nom", max_length=80, unique=True)
    description = models.CharField("Description", max_length=255, blank=True)
    est_active = models.BooleanField(
        "Proposée aux étudiants", default=True,
        help_text="Une catégorie désactivée disparaît du formulaire mais "
                  "reste attachée aux thèmes existants.")
    ordre = models.PositiveSmallIntegerField("Ordre d'affichage", default=100)

    class Meta:
        verbose_name = "Catégorie de thème"
        verbose_name_plural = "Catégories de thèmes"
        ordering = ["ordre", "nom"]

    def __str__(self):
        return self.nom

    @property
    def nb_themes(self):
        return self.themes.count()


class StatutTheme(models.TextChoices):
    EN_ATTENTE = "EN_ATTENTE", "En attente"
    VALIDE = "VALIDE", "Validé"
    REJETE = "REJETE", "Rejeté"


class ThemeQuerySet(models.QuerySet):

    def comparables(self):
        """
        Le corpus contre lequel un nouveau thème est comparé : les thèmes
        validés et les thèmes archivés. Un thème rejeté ou en attente n'est
        pas un sujet pris, il n'a pas à bloquer quelqu'un d'autre.
        """
        return self.filter(models.Q(statut=StatutTheme.VALIDE) | models.Q(est_archive=True))


class Theme(models.Model):
    """Proposition de sujet déposée par un étudiant."""

    etudiant = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Étudiant",
        on_delete=models.CASCADE, related_name="themes",
        limit_choices_to={"role": "ETUDIANT"},
    )

    titre = models.CharField("Titre du thème", max_length=250)
    # Forme canonique, recalculée à chaque enregistrement. Stockée plutôt que
    # recalculée à la lecture : c'est ce qui permet l'index et la contrainte.
    titre_normalise = models.CharField(max_length=250, editable=False, db_index=True)

    description = models.TextField("Description du thème")
    contexte = models.TextField("Contexte")
    problematique = models.TextField("Problématique")
    objectifs = models.TextField("Objectifs")
    mots_cles = models.CharField(
        "Mots-clés", max_length=250,
        help_text="Séparés par des virgules. Exemple : gouvernance, PME, Togo")

    categories = models.ManyToManyField(
        CategorieTheme, verbose_name="Catégories", related_name="themes",
        help_text="Une ou plusieurs.")

    statut = models.CharField(
        "Statut", max_length=15, choices=StatutTheme.choices,
        default=StatutTheme.EN_ATTENTE)

    date_soumission = models.DateTimeField("Date de soumission", default=timezone.now)
    date_decision = models.DateTimeField("Date de décision", null=True, blank=True)
    decide_par = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Décision rendue par",
        on_delete=models.SET_NULL, null=True, blank=True,
        related_name="themes_decides")
    motif_rejet = models.TextField("Motif du rejet", blank=True)

    est_archive = models.BooleanField(
        "Archivé", default=False,
        help_text="Thème d'une promotion antérieure, conservé pour la "
                  "détection des doublons.")

    # Trace de l'avertissement de doublon : ce que l'étudiant a vu, et le fait
    # qu'il ait confirmé malgré tout. Utile au Responsable des Études.
    doublon_signale = models.BooleanField("Similitude signalée", default=False)
    doublon_detail = models.CharField("Thème le plus proche", max_length=300, blank=True)

    objects = ThemeQuerySet.as_manager()

    class Meta:
        verbose_name = "Thème"
        verbose_name_plural = "Thèmes"
        ordering = ["-date_soumission"]
        indexes = [models.Index(fields=["statut", "-date_soumission"])]
        constraints = [
            # Un même titre normalisé ne peut pas être validé deux fois.
            # Les thèmes en attente et rejetés échappent à la contrainte :
            # un sujet refusé doit pouvoir être reproposé par quelqu'un.
            models.UniqueConstraint(
                fields=["titre_normalise"],
                condition=models.Q(statut="VALIDE"),
                name="ux_theme_titre_valide"),
        ]

    def __str__(self):
        return self.titre

    def save(self, *args, **kwargs):
        self.titre_normalise = normaliser_titre(self.titre)
        super().save(*args, **kwargs)

    # -- État ---------------------------------------------------------------
    @property
    def est_en_attente(self):
        return self.statut == StatutTheme.EN_ATTENTE

    @property
    def est_valide(self):
        return self.statut == StatutTheme.VALIDE

    @property
    def est_rejete(self):
        return self.statut == StatutTheme.REJETE

    @property
    def modifiable(self):
        """
        Un thème n'est plus modifiable dès qu'il est soumis : la décision du
        Responsable des Études doit porter sur le texte qu'il a lu.
        """
        return False

    @property
    def liste_mots_cles(self):
        return [m.strip() for m in (self.mots_cles or "").split(",") if m.strip()]

    @property
    def couleur_statut(self):
        return {StatutTheme.EN_ATTENTE: "ambre",
                StatutTheme.VALIDE: "vert",
                StatutTheme.REJETE: "rouge"}.get(self.statut, "gris")

    # -- Détection des doublons --------------------------------------------
    @classmethod
    def similaires(cls, titre, seuil=None, exclure_pk=None, limite=5):
        """
        Les thèmes déjà pris qui ressemblent le plus à ce titre.

        Retourne une liste de (thème, score) au-dessus du seuil, du plus
        proche au moins proche.
        """
        if seuil is None:
            seuil = settings.GCVM["SEUIL_SIMILARITE_THEME"]

        normalise = normaliser_titre(titre)
        if not normalise:
            return []

        corpus = cls.objects.comparables().select_related("etudiant")
        if exclure_pk:
            corpus = corpus.exclude(pk=exclure_pk)

        resultats = []
        for theme in corpus:
            score = score_similarite(titre, theme.titre)
            if score >= seuil:
                resultats.append((theme, round(score * 100)))
        resultats.sort(key=lambda couple: couple[1], reverse=True)
        return resultats[:limite]

    # -- Décision (rendue par le Responsable des Études, module à venir) ----
    def valider(self, par=None):
        self.statut = StatutTheme.VALIDE
        self.date_decision = timezone.now()
        self.decide_par = par
        self.motif_rejet = ""
        self.save()

    def rejeter(self, motif, par=None):
        self.statut = StatutTheme.REJETE
        self.date_decision = timezone.now()
        self.decide_par = par
        self.motif_rejet = motif
        self.save()
