"""Tests du module « themes » — phase ultérieure."""
