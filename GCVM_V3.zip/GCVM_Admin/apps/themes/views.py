"""
Choix du thème — côté étudiant.

Enchaînement :
    proposer  →  (avertissement de doublon)  →  confirmation  →  en attente
"""

from django.contrib import messages
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render

from apps.accounts.models import Role
from apps.etudiant.decorators import etudiant_requis
from apps.notifications.models import Notification, TypeNotification

from .forms import PropositionThemeForm
from .models import StatutTheme, Theme


def theme_en_cours(etudiant):
    """
    Le thème qui occupe l'étudiant : celui en attente, sinon celui validé.
    Un thème rejeté ne bloque rien — l'étudiant peut reproposer.
    """
    return (etudiant.themes.filter(statut=StatutTheme.EN_ATTENTE).first()
            or etudiant.themes.filter(statut=StatutTheme.VALIDE).first())


@etudiant_requis
def proposer(requete):
    """Soumission d'une proposition de thème."""
    en_cours = theme_en_cours(requete.user)

    # Une seule proposition à la fois : tant qu'aucune décision n'est rendue,
    # le thème n'est ni modifiable ni remplaçable.
    if en_cours is not None:
        return render(requete, "themes/proposition_bloquee.html", {
            "rubrique": "theme", "theme": en_cours,
        })

    formulaire = PropositionThemeForm(requete.POST or None)
    similaires = []

    if requete.method == "POST" and formulaire.is_valid():
        titre = formulaire.cleaned_data["titre"]
        similaires = Theme.similaires(titre)

        if similaires and not formulaire.doublon_confirme:
            # Premier passage : on montre les sujets proches et on attend une
            # décision explicite. Rien n'est enregistré.
            messages.warning(
                requete, "Un thème similaire existe déjà dans la base de données.")
        else:
            with transaction.atomic():
                theme = formulaire.save(commit=False)
                theme.etudiant = requete.user
                theme.statut = StatutTheme.EN_ATTENTE
                if similaires:
                    theme.doublon_signale = True
                    voisin, score = similaires[0]
                    theme.doublon_detail = f"{voisin.titre} ({score} %)"
                theme.save()
                formulaire.save_m2m()

                Notification.envoyer(
                    requete.user, TypeNotification.THEME_SOUMIS,
                    "Votre thème a été soumis",
                    f"« {theme.titre} » est en attente de validation par le "
                    f"Responsable des Études.",
                    lien="/themes/mes-themes/")

            messages.success(
                requete,
                "Votre thème a été soumis. Il est en attente de validation par "
                "le Responsable des Études.")
            return redirect("themes:mes_themes")

    return render(requete, "themes/proposer.html", {
        "rubrique": "theme",
        "formulaire": formulaire,
        "similaires": similaires,
        "attente_confirmation": bool(similaires) and not formulaire.doublon_confirme,
    })


@etudiant_requis
def mes_themes(requete):
    """Historique : thèmes en attente, validés, rejetés."""
    themes = (requete.user.themes
              .prefetch_related("categories")
              .select_related("decide_par")
              .order_by("-date_soumission"))

    return render(requete, "themes/mes_themes.html", {
        "rubrique": "theme",
        "themes": themes,
        "en_attente": themes.filter(statut=StatutTheme.EN_ATTENTE).count(),
        "valides": themes.filter(statut=StatutTheme.VALIDE).count(),
        "rejetes": themes.filter(statut=StatutTheme.REJETE).count(),
        "peut_proposer": theme_en_cours(requete.user) is None,
    })


@etudiant_requis
def detail(requete, pk):
    """Fiche d'un thème. Un étudiant ne voit que les siens."""
    theme = get_object_or_404(
        Theme.objects.prefetch_related("categories").select_related("decide_par"),
        pk=pk, etudiant=requete.user)
    return render(requete, "themes/detail.html", {
        "rubrique": "theme", "theme": theme,
    })
