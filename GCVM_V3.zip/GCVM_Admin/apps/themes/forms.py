"""Formulaire de proposition de thème."""

from django import forms

from apps.accounts.forms import styliser

from .models import CategorieTheme, Theme


class PropositionThemeForm(forms.ModelForm):
    """
    Saisie d'une proposition de sujet.

    La confirmation de doublon est un champ caché du formulaire lui-même :
    l'étudiant renvoie le même formulaire, avec `confirme_doublon` à 1, après
    avoir vu les sujets proches. Cela évite de stocker un état intermédiaire
    en session, qui se perdrait au rafraîchissement de la page.
    """

    confirme_doublon = forms.BooleanField(required=False, widget=forms.HiddenInput())

    class Meta:
        model = Theme
        fields = ["titre", "description", "contexte", "problematique",
                  "objectifs", "mots_cles", "categories"]
        widgets = {
            "titre": forms.TextInput(attrs={
                "placeholder": "Intitulé complet de votre sujet"}),
            "description": forms.Textarea(attrs={
                "rows": 4, "placeholder": "En quelques lignes, de quoi traite ce sujet ?"}),
            "contexte": forms.Textarea(attrs={
                "rows": 4, "placeholder": "Dans quel cadre ce sujet se pose-t-il ?"}),
            "problematique": forms.Textarea(attrs={
                "rows": 3, "placeholder": "La question à laquelle le mémoire répondra."}),
            "objectifs": forms.Textarea(attrs={
                "rows": 4, "placeholder": "Objectif général, puis objectifs spécifiques."}),
            "mots_cles": forms.TextInput(attrs={
                "placeholder": "gouvernance, PME, Togo"}),
            "categories": forms.CheckboxSelectMultiple(),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["categories"].queryset = CategorieTheme.objects.filter(est_active=True)
        self.fields["categories"].help_text = "Cochez une ou plusieurs catégories."
        styliser(self)
        # Les cases à cocher n'ont pas à porter la classe form-control.
        self.fields["categories"].widget.attrs.pop("class", None)
        self.fields["categories"].widget.attrs.pop("required", None)

    def clean_titre(self):
        titre = " ".join(self.cleaned_data["titre"].split())
        if len(titre) < 15:
            raise forms.ValidationError(
                "Le titre est trop court pour identifier un sujet de mémoire "
                "(15 caractères minimum).")
        return titre

    def clean_categories(self):
        categories = self.cleaned_data["categories"]
        if not categories:
            raise forms.ValidationError("Choisissez au moins une catégorie.")
        return categories

    @property
    def doublon_confirme(self):
        return bool(self.data.get("confirme_doublon"))
