from django.apps import AppConfig


class JuryConfig(AppConfig):
    """Espace Jury : invitations, lecture des mémoires, évaluation des soutenances.

    Pas de rôle de compte séparé : un membre de jury est un enseignant, et il
    accède à cet espace avec son compte habituel.
    """

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.jury"
    verbose_name = "Espace Jury"
