"""
Espace Jury.

**Il n'existe aucun rôle « Jury ».** Un membre de jury est un enseignant, et il
entre ici avec son compte habituel. L'accès est conditionné non par le rôle du
compte mais par le fait de siéger dans au moins un jury — c'est le garde
`jury_requis` qui l'applique.

Conséquence directe : le même compte peut, le même jour, encadrer un mémoire et
siéger au jury d'un autre. Les deux espaces cohabitent dans le menu, sans
duplication de compte.
"""

import os

from django.contrib import messages
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from apps.accounts.gardes import enseignant_requis
from apps.defenses.models import (
    Evaluation, ParticipationJury, StatutParticipation, StatutSoutenance,
)
from apps.memories.services import responsables_des_etudes
from apps.notifications.models import Notification, TypeNotification


def participations_de(enseignant):
    return (ParticipationJury.objects
            .filter(enseignant=enseignant)
            .exclude(statut=StatutParticipation.REMPLACE)
            .select_related("soutenance", "soutenance__memoire",
                            "soutenance__memoire__etudiant",
                            "soutenance__memoire__theme", "soutenance__salle")
            .order_by("soutenance__date_soutenance", "soutenance__heure_debut"))


@enseignant_requis
def mes_soutenances(requete):
    toutes = participations_de(requete.user)
    aujourdhui = timezone.localdate()

    return render(requete, "jury/mes_soutenances.html", {
        "rubrique": "jury",
        "invitations": toutes.filter(statut=StatutParticipation.EN_ATTENTE),
        "a_venir": toutes.filter(statut=StatutParticipation.ACCEPTE,
                                 soutenance__date_soutenance__gte=aujourdhui),
        "passees": toutes.filter(statut=StatutParticipation.ACCEPTE,
                                 soutenance__date_soutenance__lt=aujourdhui),
        "refusees": toutes.filter(statut=StatutParticipation.REFUSE),
    })


@enseignant_requis
def detail(requete, pk):
    """
    Fiche d'une soutenance.

    Tant que l'invitation n'est pas acceptée, seuls l'étudiant, le thème et le
    résumé sont visibles — assez pour décider, pas plus. Le document complet ne
    s'ouvre qu'après acceptation.
    """
    participation = get_object_or_404(
        participations_de(requete.user).select_related(
            "soutenance__memoire__encadreur"), pk=pk)
    soutenance = participation.soutenance
    memoire = soutenance.memoire

    return render(requete, "jury/detail.html", {
        "rubrique": "jury",
        "participation": participation, "soutenance": soutenance, "memoire": memoire,
        "acces_complet": participation.est_acceptee,
        "versions": (memoire.versions.select_related("depose_par")
                     if participation.est_acceptee else []),
        "autres_membres": soutenance.participations.exclude(pk=participation.pk),
        "evaluation": getattr(participation, "evaluation", None),
        "soutenance_passee": soutenance.statut == StatutSoutenance.TENUE
                             or soutenance.est_passee,
    })


@enseignant_requis
def repondre(requete, pk, reponse):
    """Acceptation ou refus de l'invitation."""
    participation = get_object_or_404(
        ParticipationJury.objects.select_related("soutenance", "soutenance__memoire"),
        pk=pk, enseignant=requete.user)

    if requete.method != "POST":
        return redirect("jury:detail", pk=pk)

    if participation.statut != StatutParticipation.EN_ATTENTE:
        messages.warning(requete, "Vous avez déjà répondu à cette invitation.")
        return redirect("jury:detail", pk=pk)

    soutenance = participation.soutenance
    etudiant = soutenance.memoire.etudiant

    if reponse == "accepter":
        participation.accepter()
        for responsable in responsables_des_etudes():
            Notification.envoyer(
                responsable, TypeNotification.JURY_REPONSE,
                "Un membre du jury a accepté",
                f"{requete.user.nom_complet} siégera au jury de "
                f"{etudiant.nom_complet}.",
                f"/etudes/soutenances/{soutenance.pk}/")
        messages.success(
            requete,
            "Invitation acceptée. Vous avez maintenant accès au mémoire complet.")
        # La confirmation éventuelle de la soutenance prévient étudiant et encadreur.
        from apps.etudes.views import _prevenir_si_confirmee
        _prevenir_si_confirmee(soutenance)
    else:
        motif = requete.POST.get("motif", "").strip()
        if not motif:
            messages.error(requete, "Merci d'indiquer un motif de refus.")
            return redirect("jury:detail", pk=pk)
        participation.refuser(motif)
        for responsable in responsables_des_etudes():
            Notification.envoyer(
                responsable, TypeNotification.JURY_REPONSE,
                "Un membre du jury a refusé",
                f"{requete.user.nom_complet} ne peut pas siéger au jury de "
                f"{etudiant.nom_complet}. Motif : {motif}. Un remplaçant doit "
                f"être désigné.", f"/etudes/soutenances/{soutenance.pk}/")
        messages.info(requete, "Refus enregistré. Le Responsable des Études a été prévenu.")

    return redirect("jury:mes_soutenances")


@enseignant_requis
def observations(requete, pk):
    """Notes de lecture préparatoires, privées au membre du jury."""
    participation = get_object_or_404(
        ParticipationJury.objects.select_related("soutenance"),
        pk=pk, enseignant=requete.user)

    if requete.method != "POST":
        return redirect("jury:detail", pk=pk)
    if not participation.est_acceptee:
        messages.warning(requete, "Acceptez d'abord l'invitation.")
        return redirect("jury:detail", pk=pk)

    participation.observations = requete.POST.get("observations", "").strip()[:5000]
    participation.save(update_fields=["observations"])
    messages.success(requete, "Vos observations ont été enregistrées.")
    return redirect("jury:detail", pk=pk)


@enseignant_requis
def evaluer(requete, pk):
    """Note, appréciation et recommandations, après la séance."""
    participation = get_object_or_404(
        ParticipationJury.objects.select_related("soutenance", "soutenance__memoire"),
        pk=pk, enseignant=requete.user)

    if requete.method != "POST":
        return redirect("jury:detail", pk=pk)
    if not participation.est_acceptee:
        messages.warning(requete, "Seuls les membres ayant accepté peuvent évaluer.")
        return redirect("jury:detail", pk=pk)

    note_brute = requete.POST.get("note", "").replace(",", ".").strip()
    try:
        note = float(note_brute)
    except ValueError:
        messages.error(requete, "La note doit être un nombre entre 0 et 20.")
        return redirect("jury:detail", pk=pk)
    if not 0 <= note <= 20:
        messages.error(requete, "La note doit être comprise entre 0 et 20.")
        return redirect("jury:detail", pk=pk)

    Evaluation.objects.update_or_create(
        participation=participation,
        defaults={
            "note": note,
            "commentaire": requete.POST.get("commentaire", "").strip()[:5000],
            "recommandations": requete.POST.get("recommandations", "").strip()[:5000],
            "date_saisie": timezone.now(),
        })

    for responsable in responsables_des_etudes():
        Notification.envoyer(
            responsable, TypeNotification.JURY_REPONSE,
            "Évaluation saisie par un membre du jury",
            f"{requete.user.nom_complet} a évalué la soutenance de "
            f"{participation.soutenance.memoire.etudiant.nom_complet} : {note}/20.",
            f"/etudes/soutenances/{participation.soutenance.pk}/")

    messages.success(requete, f"Évaluation enregistrée : {note}/20.")
    return redirect("jury:detail", pk=pk)


@enseignant_requis
def telecharger(requete, pk):
    """
    Téléchargement du mémoire par un membre du jury.

    Réservé aux membres ayant **accepté** : avant cela, le document complet
    n'a pas à être accessible.
    """
    from apps.memories.models import VersionMemoire

    version = get_object_or_404(
        VersionMemoire.objects.select_related("memoire"), pk=pk)

    autorise = ParticipationJury.objects.filter(
        soutenance__memoire=version.memoire, enseignant=requete.user,
        statut=StatutParticipation.ACCEPTE).exists()
    if not autorise:
        raise Http404("Vous n'avez pas accès à ce document.")

    if not version.fichier or not version.fichier.storage.exists(version.fichier.name):
        raise Http404("Le fichier de cette version est introuvable.")

    return FileResponse(
        version.fichier.open("rb"), as_attachment=True,
        filename=version.nom_original or os.path.basename(version.fichier.name))
