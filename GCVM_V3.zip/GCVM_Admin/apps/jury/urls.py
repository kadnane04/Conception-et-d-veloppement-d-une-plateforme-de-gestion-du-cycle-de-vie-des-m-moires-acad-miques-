"""Routes de l'espace Jury.

Aucun rôle de compte « Jury » : ces pages sont servies au compte enseignant
qui siège dans un jury.
"""

from django.urls import path

from . import views

app_name = "jury"

urlpatterns = [
    path("", views.mes_soutenances, name="mes_soutenances"),
    path("<int:pk>/", views.detail, name="detail"),
    path("<int:pk>/reponse/<slug:reponse>/", views.repondre, name="repondre"),
    path("<int:pk>/observations/", views.observations, name="observations"),
    path("<int:pk>/evaluer/", views.evaluer, name="evaluer"),
    path("version/<int:pk>/telecharger/", views.telecharger, name="telecharger"),
]
