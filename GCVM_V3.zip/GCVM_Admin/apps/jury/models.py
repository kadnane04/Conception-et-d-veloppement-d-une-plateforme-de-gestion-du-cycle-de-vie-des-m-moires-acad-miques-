"""
L'espace « jury » n'a pas de modèle propre.

Il pilote ceux des modules métier : themes, supervision, memories, defenses,
archives et notifications. Le fichier existe pour que Django reconnaisse
l'application.
"""
