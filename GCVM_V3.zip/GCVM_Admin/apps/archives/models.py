"""
Bibliothèque numérique des mémoires soutenus.

Une décision structure ce module : **l'archive est une fiche autonome, pas un
simple pointeur vers le mémoire**.

Deux raisons.

1. La bibliothèque doit accueillir les mémoires des promotions antérieures,
   importés à la main par le Responsable des Études. Ceux-là n'ont ni compte
   étudiant ni dossier dans la plateforme : leur auteur et leur encadreur sont
   des noms, pas des clés étrangères.

2. Une fiche d'archive doit rester lisible même si le compte de l'auteur est
   supprimé des années plus tard. Le titre, l'auteur, l'année et la filière y
   sont donc recopiés au moment de l'archivage.

Le lien vers le mémoire d'origine existe quand il y en a un — il permet de
remonter au dossier complet — mais rien n'en dépend pour l'affichage.
"""

import os

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone


def valider_archive(fichier):
    extensions = settings.GCVM["EXTENSIONS_AUTORISEES"]
    taille_max = settings.GCVM["TAILLE_MAX_DEPOT_MO"]

    extension = os.path.splitext(fichier.name)[1].lower().lstrip(".")
    if extension not in extensions:
        raise ValidationError(
            f"Format « .{extension} » refusé. "
            f"Formats acceptés : {', '.join('.' + e for e in extensions)}.")
    if fichier.size > taille_max * 1024 * 1024:
        raise ValidationError(
            f"Fichier trop volumineux ({fichier.size / 1024 / 1024:.1f} Mo). "
            f"Maximum : {taille_max} Mo.")


class NiveauAcces(models.TextChoices):
    """Qui peut ouvrir le document."""

    INTERNE = "INTERNE", "Interne — tout compte de la plateforme"
    RESTREINT = "RESTREINT", "Restreint — enseignants et responsables"


class ArchiveQuerySet(models.QuerySet):

    def visibles_par(self, utilisateur):
        """
        Un mémoire restreint n'apparaît pas aux étudiants.

        La règle est appliquée dans la requête, pas dans le gabarit : une
        fiche masquée doit être absente des résultats, pas seulement de
        l'affichage.
        """
        if not getattr(utilisateur, "is_authenticated", False):
            return self.none()
        if utilisateur.est_etudiant:
            return self.filter(niveau_acces=NiveauAcces.INTERNE)
        return self

    def recherche(self, termes):
        if not termes:
            return self
        requete = models.Q()
        for mot in termes.split():
            requete &= (models.Q(titre__icontains=mot)
                        | models.Q(auteur_nom__icontains=mot)
                        | models.Q(resume__icontains=mot)
                        | models.Q(mots_cles__icontains=mot)
                        | models.Q(encadreur_nom__icontains=mot))
        return self.filter(requete)


class MemoireArchive(models.Model):
    """Fiche d'un mémoire consultable dans la bibliothèque."""

    class Origine(models.TextChoices):
        PLATEFORME = "PLATEFORME", "Soutenu sur la plateforme"
        IMPORT = "IMPORT", "Importé (promotion antérieure)"

    # -- Lien facultatif vers le dossier d'origine -------------------------
    memoire = models.OneToOneField(
        "memories.Memoire", verbose_name="Mémoire d'origine",
        on_delete=models.SET_NULL, null=True, blank=True, related_name="archive")
    etudiant = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Compte étudiant",
        on_delete=models.SET_NULL, null=True, blank=True,
        related_name="archives", limit_choices_to={"role": "ETUDIANT"})
    encadreur = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Compte encadreur",
        on_delete=models.SET_NULL, null=True, blank=True,
        related_name="archives_encadrees", limit_choices_to={"role": "PROFESSEUR"})

    # -- Fiche, recopiée pour rester autonome ------------------------------
    titre = models.CharField("Titre", max_length=250)
    auteur_nom = models.CharField("Auteur", max_length=140)
    encadreur_nom = models.CharField("Encadreur", max_length=140, blank=True)
    annee = models.CharField("Année", max_length=20,
                             help_text="Exemple : 2025-2026")
    filiere = models.CharField("Filière", max_length=60, blank=True)
    resume = models.TextField("Résumé")
    mots_cles = models.CharField("Mots-clés", max_length=250, blank=True,
                                 help_text="Séparés par des virgules.")

    fichier = models.FileField("Document", upload_to="archives/",
                               validators=[valider_archive])
    nom_original = models.CharField("Nom du fichier", max_length=255, blank=True)
    taille_octets = models.PositiveBigIntegerField("Taille", default=0)

    origine = models.CharField("Origine", max_length=15, choices=Origine.choices,
                               default=Origine.PLATEFORME)
    niveau_acces = models.CharField(
        "Niveau d'accès", max_length=15, choices=NiveauAcces.choices,
        default=NiveauAcces.INTERNE)

    note_finale = models.DecimalField("Note obtenue", max_digits=4, decimal_places=2,
                                      null=True, blank=True)
    mention = models.CharField("Mention", max_length=40, blank=True)

    archive_par = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Archivé par",
        on_delete=models.SET_NULL, null=True, blank=True,
        related_name="archivages")
    date_archivage = models.DateTimeField("Archivé le", default=timezone.now)

    # Compteur de consultations : c'est lui qui rend mesurable la valorisation
    # des mémoires, l'un des objectifs du projet.
    nb_consultations = models.PositiveIntegerField("Consultations", default=0)
    nb_telechargements = models.PositiveIntegerField("Téléchargements", default=0)

    objects = ArchiveQuerySet.as_manager()

    class Meta:
        verbose_name = "Mémoire archivé"
        verbose_name_plural = "Bibliothèque des mémoires"
        ordering = ["-annee", "titre"]
        indexes = [
            models.Index(fields=["-annee"]),
            models.Index(fields=["filiere"]),
        ]

    def __str__(self):
        return f"{self.titre} — {self.auteur_nom} ({self.annee})"

    @property
    def liste_mots_cles(self):
        return [m.strip() for m in (self.mots_cles or "").split(",") if m.strip()]

    @property
    def taille_lisible(self):
        octets = self.taille_octets or 0
        if octets < 1024:
            return f"{octets} o"
        if octets < 1024 * 1024:
            return f"{octets / 1024:.0f} Ko"
        return f"{octets / 1024 / 1024:.1f} Mo"

    def enregistrer_acces(self, utilisateur, action):
        """Trace une consultation ou un téléchargement, et incrémente le compteur."""
        Consultation.objects.create(
            archive=self, utilisateur=utilisateur if utilisateur.pk else None,
            action=action)
        champ = ("nb_consultations" if action == Consultation.Action.CONSULTATION
                 else "nb_telechargements")
        MemoireArchive.objects.filter(pk=self.pk).update(
            **{champ: models.F(champ) + 1})


class Consultation(models.Model):
    """Qui a ouvert quoi, et quand."""

    class Action(models.TextChoices):
        CONSULTATION = "CONSULTATION", "Consultation de la fiche"
        TELECHARGEMENT = "TELECHARGEMENT", "Téléchargement du document"

    archive = models.ForeignKey(
        MemoireArchive, verbose_name="Mémoire", on_delete=models.CASCADE,
        related_name="consultations")
    utilisateur = models.ForeignKey(
        settings.AUTH_USER_MODEL, verbose_name="Utilisateur",
        on_delete=models.SET_NULL, null=True, blank=True,
        related_name="consultations_archives")
    action = models.CharField("Action", max_length=20, choices=Action.choices,
                              default=Action.CONSULTATION)
    horodatage = models.DateTimeField("Date", default=timezone.now)

    class Meta:
        verbose_name = "Consultation"
        verbose_name_plural = "Consultations"
        ordering = ["-horodatage"]
        indexes = [models.Index(fields=["-horodatage"])]

    def __str__(self):
        return f"{self.horodatage:%d/%m/%Y %H:%M} — {self.archive.titre}"
