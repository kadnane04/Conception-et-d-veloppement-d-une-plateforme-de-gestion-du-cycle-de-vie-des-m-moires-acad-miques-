"""
Bibliothèque numérique.

Ouverte à **tous les comptes de la plateforme** — étudiants, enseignants,
responsables — conformément au cahier des charges. Seule nuance : un mémoire
classé « restreint » n'apparaît pas aux étudiants, et cette règle est appliquée
dans la requête, pas dans le gabarit : une fiche masquée doit être absente des
résultats, pas seulement invisible à l'écran.

Chaque consultation et chaque téléchargement sont comptés. C'est ce compteur
qui rend mesurable la valorisation des mémoires soutenus.
"""

import os

from django.core.paginator import Paginator
from django.db.models import Count, Q
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, render

from apps.accounts.gardes import connecte_requis

from .models import Consultation, MemoireArchive


@connecte_requis
def bibliotheque(requete):
    visibles = MemoireArchive.objects.visibles_par(requete.user).select_related("etudiant")

    recherche = requete.GET.get("q", "").strip()
    resultats = visibles.recherche(recherche)

    annee = requete.GET.get("annee", "")
    if annee:
        resultats = resultats.filter(annee=annee)
    filiere = requete.GET.get("filiere", "")
    if filiere:
        resultats = resultats.filter(filiere=filiere)

    tri = requete.GET.get("tri", "recent")
    resultats = resultats.order_by(
        {"recent": "-date_archivage", "ancien": "date_archivage",
         "titre": "titre", "consultes": "-nb_consultations"}.get(tri, "-date_archivage"))

    from django.conf import settings
    page = Paginator(resultats, settings.GCVM["ELEMENTS_PAR_PAGE"]).get_page(
        requete.GET.get("page"))

    parametres = requete.GET.copy()
    parametres.pop("page", None)

    return render(requete, "archives/bibliotheque.html", {
        "rubrique": "bibliotheque", "page": page,
        "recherche": recherche, "annee": annee, "filiere": filiere, "tri": tri,
        "annees": (visibles.exclude(annee="").values_list("annee", flat=True)
                   .distinct().order_by("-annee")),
        "filieres": (visibles.exclude(filiere="").values_list("filiere", flat=True)
                     .distinct().order_by("filiere")),
        "total": visibles.count(), "total_filtre": resultats.count(),
        "parametres": parametres.urlencode(),
        "consultations": Consultation.objects.count(),
    })


@connecte_requis
def detail(requete, pk):
    archive = get_object_or_404(
        MemoireArchive.objects.visibles_par(requete.user)
        .select_related("etudiant", "encadreur", "memoire"), pk=pk)

    archive.enregistrer_acces(requete.user, Consultation.Action.CONSULTATION)
    archive.refresh_from_db(fields=["nb_consultations"])

    # Mémoires voisins : même filière ou même année.
    voisins = (MemoireArchive.objects.visibles_par(requete.user)
               .filter(Q(filiere=archive.filiere) | Q(annee=archive.annee))
               .exclude(pk=archive.pk)[:4])

    return render(requete, "archives/detail.html", {
        "rubrique": "bibliotheque", "archive": archive, "voisins": voisins,
        "soutenance": getattr(getattr(archive, "memoire", None), "soutenance", None),
    })


@connecte_requis
def telecharger(requete, pk):
    """
    Téléchargement du document archivé.

    Le fichier n'est pas exposé par une URL publique : cette vue vérifie que
    le demandeur est connecté et que la fiche lui est visible.
    """
    archive = get_object_or_404(
        MemoireArchive.objects.visibles_par(requete.user), pk=pk)

    if not archive.fichier or not archive.fichier.storage.exists(archive.fichier.name):
        raise Http404("Le document de ce mémoire est introuvable.")

    archive.enregistrer_acces(requete.user, Consultation.Action.TELECHARGEMENT)

    return FileResponse(
        archive.fichier.open("rb"), as_attachment=True,
        filename=archive.nom_original or os.path.basename(archive.fichier.name))
