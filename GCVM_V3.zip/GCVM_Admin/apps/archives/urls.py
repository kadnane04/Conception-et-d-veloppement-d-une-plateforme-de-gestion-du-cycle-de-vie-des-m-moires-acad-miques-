"""Routes de la bibliothèque numérique — ouverte à tous les comptes."""

from django.urls import path

from . import views

app_name = "archives"

urlpatterns = [
    path("", views.bibliotheque, name="bibliotheque"),
    path("<int:pk>/", views.detail, name="detail"),
    path("<int:pk>/telecharger/", views.telecharger, name="telecharger"),
]
