"""Administration Django du module « archives » — phase ultérieure."""
