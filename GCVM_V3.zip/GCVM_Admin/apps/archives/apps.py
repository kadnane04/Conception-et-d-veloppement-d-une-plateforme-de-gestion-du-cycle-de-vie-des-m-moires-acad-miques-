from django.apps import AppConfig


class ArchivesConfig(AppConfig):
    """Bibliothèque numérique des mémoires soutenus."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.archives"
    verbose_name = "Bibliothèque des mémoires"
