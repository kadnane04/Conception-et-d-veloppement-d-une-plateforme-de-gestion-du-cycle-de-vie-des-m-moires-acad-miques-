"""Tests du module « archives » — phase ultérieure."""
