#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ -d venv ] || { echo "  Lancez d'abord ./installer.sh"; exit 1; }
echo
echo "  Plateforme GCVM — http://127.0.0.1:8000/"
echo "  Compte administrateur : admin@lbs.com / admin1234567890"
echo "  Arrêt : Ctrl + C"
echo
exec ./venv/bin/python manage.py runserver
