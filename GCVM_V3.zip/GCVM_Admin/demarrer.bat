@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist venv (
  echo   L'environnement n'est pas installe. Lancez d'abord installer.bat
  pause
  exit /b 1
)
call venv\Scripts\activate
echo.
echo   Plateforme GCVM - http://127.0.0.1:8000/
echo   Compte administrateur : admin@lbs.com / admin1234567890
echo   Arret : Ctrl + C
echo.
python manage.py runserver
pause
